#!/bin/sh

#Script for start in kali linux because of ssh problems
export NODE_OPTIONS=--openssl-legacy-provider
expo start --web