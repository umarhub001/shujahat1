import { View, Text, Button, TouchableOpacity } from 'react-native'
import React, { useContext } from 'react'
import { createNativeStackNavigator } from '@react-navigation/native-stack';


//context api
import AuthContext from '../services/account/auth.context';
import { GroceryContext } from '../services/grocery/grocery.context';
import { AccountContext } from '../services/account/account.context';
import { FlatList } from 'native-base';

import { Appbar } from 'react-native-paper';
import { Platform } from 'react-native';


//Screens
import Groceryy from '../features/grocery-management/grocery-items.screen';
import { WeeklyMenuContext } from '../services/weekly-menu/weekly.menu.context';

const Grocery = () => {
    const [active, setActive] = React.useState('');
    const { addGroceryItem, groceries, approveGroceryItem, deleteGroceryItem, completeGroceryItem } = useContext(GroceryContext);
    const filteredGroceries = groceries.filter(grocery => grocery.status === true);
    const approvedAndIncompleteGroceries = filteredGroceries.filter(grocery => grocery.completed === false);

    const MORE_ICON = Platform.OS === 'ios' ? 'dots-horizontal' : 'dots-vertical';
    const [visible, setVisible] = React.useState(false);

    const showModal = () => setVisible(true);
    const hideModal = () => setVisible(false);
    const containerStyle = { backgroundColor: 'white', padding: 20 };
    // addGroceryItem(familyId, userId, name, quantity);
    return (
        <View>

            <Appbar.Header>
                <Appbar.BackAction onPress={() => { console.log("go back") }} />
                <Appbar.Content title="Title" />
                <Appbar.Action icon="magnify" onPress={() => { console.log("search") }} />
                <Appbar.Action icon="dots-vertical" onPress={() => { console.log("dot") }} />
            </Appbar.Header>

            <Text>Grocery Screen {approvedAndIncompleteGroceries.length} items</Text>

            <Button title='delete grocery item' onPress={() => {
                deleteGroceryItem("l14OaTbWKvGPRvN9UZAe");
            }} />

            <Button title='approve grocery item' onPress={() => {
                approveGroceryItem("UhFFsJ5qJRGxh9CcF9Pe");
            }} />

            <Button
                title="add grocery" onPress={() => {
                    addGroceryItem("alu pyas", 5)
                        .then((success) => { console.log(success) })
                        .catch((error) => { console.log(error) });
                }} />

            <FlatList
                data={approvedAndIncompleteGroceries}
                renderItem={
                    ({ item }) => (
                        <TouchableOpacity
                            onPress={() => { completeGroceryItem("UhFFsJ5qJRGxh9CcF9Pe"); }}
                        >
                            <Text>name: {item.name} status: {item.quantity}</Text>
                        </TouchableOpacity>
                    )
                }
            />
        </View>
    )

}




const Family = () => {
    const { logout } = useContext(AuthContext);
    const { menu, addMenu, setMealPreference, createWeeklyMenu, getPreferencesCount } = useContext(WeeklyMenuContext)

    return (
        <View style={{ flex: 1, backgroundColor: "#F6F1F5" }}>
            <Button title='logout' onPress={() => { logout() }} />
            <Text>hello</Text>
            <Button
                title='Add Menu'
                onPress={() => {
                    addMenu("lunch", "alu pyas", "this is good for us", "abc123")
                        .then((success) => {
                            toast.show({
                                description: success,
                            })
                        })
                        .catch((error) => {
                            toast.show({
                                description: error,
                            })
                        });
                }}
            />

            <Button
                title='get prefrences count'
                onPress={() => {
                    getPreferencesCount("Tuesday");
                }}
            />


            <Button title='add prefrences' onPress={() => {

                setMealPreference("Monday", "breakfast", "kima mutton");
            }} />

            <Button title='add weekly menu'
                onPress={() => {
                    createWeeklyMenu();
                }}
            />
        </View>

    )
}

const Task = () => {
    return (
        <Text>task</Text>
    )
}


//Screen Stacks
export const MemberFamilyStack = () => {
    const Stack = createNativeStackNavigator();
    return (
        <Stack.Navigator
            screenOptions={{
                headerShown: false
            }}>
            <Stack.Screen name="family" component={Family} />
        </Stack.Navigator>
    )
}

export const MemberGroceryStack = () => {
    const Stack = createNativeStackNavigator();
    return (
        <Stack.Navigator
            screenOptions={{
                headerShown: false
            }}>
            <Stack.Screen name="grocery" component={Grocery} />
        </Stack.Navigator>
    )

}


export const MemberTaskStack = () => {
    const Stack = createNativeStackNavigator();
    return (
        <Stack.Navigator
            screenOptions={{
                headerShown: false
            }}
        >
            <Stack.Screen name="task" component={Groceryy} />
        </Stack.Navigator>
    )

}