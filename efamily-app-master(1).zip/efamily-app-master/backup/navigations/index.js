
import React, { useContext } from 'react'

import AuthNavigator from './auth.navigator.js';
import AppNavigator from './app.navigator';

//context api
import AuthContext from '../services/account/auth.context';
import { AccountContextProvider } from '../services/account/account.context.js';
import { GroceryServiceProvider } from '../services/grocery/grocery.context.js';
import { TaskContextProvider } from '../services/task/task.context.js';
import { WeeklyMenuContextProvider } from '../services/weekly-menu/weekly.menu.context.js';

const Navigations = () => {
    const { isAuthenticated } = useContext(AuthContext);
    //checkAuthStatus();
    if (isAuthenticated) {
        return (
            <AccountContextProvider>
                <GroceryServiceProvider>
                    <TaskContextProvider>
                        <WeeklyMenuContextProvider>
                            <AppNavigator />
                        </WeeklyMenuContextProvider>
                    </TaskContextProvider>
                </GroceryServiceProvider>
            </AccountContextProvider>
        )
    } else {
        return (<AuthNavigator />)
    }

}

export default Navigations