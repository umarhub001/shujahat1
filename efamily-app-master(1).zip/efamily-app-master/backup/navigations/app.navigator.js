import React, { useContext, useState, useEffect } from 'react'
import { ActivityIndicator, View, Text } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

//navigations content
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { NavigationContainer } from '@react-navigation/native';

//context apis
import AuthContext from '../services/account/auth.context';
import { UploadImageContextProvider } from '../services/firebase-storage/imageUpload.context';


//member module screens
import { MemberFamilyStack, MemberGroceryStack, MemberTaskStack } from './member.navigations.js';

//admin module screens
import { AdminFamilyStack, AdminGroceryStack, AdminTaskStack, AdminWeeklyMenuStack } from './admin.navigations.js.js';


const AppNavigation = () => {
    const { isAdmin, isStateLoading, } = useContext(AuthContext);
    const [isLoading, setIsLoading] = useState(true);

    const setTabOptions = (title, iconName, backgroundColor) => ({
        title,
        tabBarIcon: ({ color, size }) => (
            <Ionicons name={iconName} size={size} color={color} />
        ),
        tabBarStyle: { backgroundColor },
    });

    useEffect(() => {
        setTimeout(() => {
            setIsLoading(false);
        }, 3000);
    }, []);

    if (isLoading) {
        return (
            <View style={{ flex: 1, justifyContent: "center", alignItems: "center" }}>
                <Text>Loading...</Text>
                <ActivityIndicator size="large" color="black" />
            </View>
        );
    }

    if (isStateLoading) {
        console.log("admin loading");
        return (
            <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
                <ActivityIndicator size="large" color="black" />
            </View>
        );
    }

    if (isAdmin) {
        const Tab = createBottomTabNavigator();
        return (
            <UploadImageContextProvider>
                <NavigationContainer >
                    <Tab.Navigator>
                        <Tab.Screen name="Family" component={AdminFamilyStack}
                            options={setTabOptions('Family', 'ios-people', '#EFEFEF')} />
                        <Tab.Screen
                            name="Groceries" component={AdminGroceryStack}
                            options={setTabOptions('Groceries', 'ios-basket', '#F5F5F5')} />
                        <Tab.Screen name="Tasks" component={AdminTaskStack}
                            options={setTabOptions('Tasks', 'ios-list', '#EAEAEA')} />
                        <Tab.Screen name="Menu" component={AdminWeeklyMenuStack}
                            options={setTabOptions('Menu', 'ios-heart', '#EAEAEA')} />
                    </Tab.Navigator>
                </NavigationContainer >
            </UploadImageContextProvider>
        )
    }
    else {
        const Tab = createBottomTabNavigator();
        return (
            <NavigationContainer >
                <Tab.Navigator>
                    <Tab.Screen name="Member Home" component={MemberFamilyStack}
                        options={setTabOptions('Family', 'ios-people', '#EFEFEF')} />
                    <Tab.Screen name="Member Grocery" component={MemberGroceryStack}
                        options={setTabOptions('Groceries', 'ios-basket', '#F5F5F5')} />
                    <Tab.Screen name="Member Task" component={MemberTaskStack}
                        options={setTabOptions('Tasks', 'ios-list', '#EAEAEA')} />
                </Tab.Navigator>
            </NavigationContainer >
        )
    }
}

export default AppNavigation