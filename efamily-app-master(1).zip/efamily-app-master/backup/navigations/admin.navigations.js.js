import React from 'react'
import { Text } from 'react-native'
import { createNativeStackNavigator } from '@react-navigation/native-stack';

//Screen Stack of Family
import Family from '../features/account-management/Family.screen';
import AssignTask from '../features/task-management/Assign-task.screen';

const WeeklyMenu = () => {
    return null;
}


const Event = () => { return <Text>Admin Grocery Screen</Text> }
export const AdminFamilyStack = () => {
    const Stack = createNativeStackNavigator();
    return (
        <Stack.Navigator screenOptions={{ headerShown: false }}>
            <Stack.Screen name="family" component={Family} />
        </Stack.Navigator>
    )
}



export const AdminGroceryStack = () => {
    const Stack = createNativeStackNavigator();
    return (
        <Stack.Navigator screenOptions={{ headerShown: false }}>
            <Stack.Screen name="Event" component={Event} />
        </Stack.Navigator>
    )
}

export const AdminWeeklyMenuStack = () => {
    const Stack = createNativeStackNavigator();
    return (
        <Stack.Navigator screenOptions={{ headerShown: false }}>
            <Stack.Screen name='weeklyMenu' component={WeeklyMenu} />
        </Stack.Navigator>
    )
}



export const AdminTaskStack = () => {
    const Stack = createNativeStackNavigator();
    return (
        <Stack.Navigator screenOptions={{ headerShown: false }}>
            <Stack.Screen name="Task" component={AssignTask} />
        </Stack.Navigator>
    )

}
