import { Text, View, TextInput, Button } from 'react-native'
import { StyleSheet } from 'react-native'
import React, { useState } from 'react'
import { db } from '../firebase'
import { getAuth, signInWithEmailAndPassword } from 'firebase/auth';
import { getFirestore, doc, getDoc } from 'firebase/firestore';

const auth = getAuth();

const RoleBaseLogin = () => {


    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");

    const handleLogin = async () => {
        try {
            const userCredential = await signInWithEmailAndPassword(auth, email, password);
            const userDoc = await getDoc(doc(db, 'users', userCredential.user.uid));
            console.log(userCredential)
            const userData = userDoc.data();
            console.log(userData)


        } catch (error) {
            console.log(error);
        }
    }
    return (
        <View>
            <TextInput placeholder="Email" value={email} onChangeText={setEmail} />
            <TextInput placeholder="Password" value={password} onChangeText={setPassword} secureTextEntry />
            <Button title="login" onPress={handleLogin} />
        </View>
    )
}

export default RoleBaseLogin

const styles = StyleSheet.create({})