
import React, { createContext, useState, useEffect, useContext } from "react";
import { createUserWithEmailAndPassword, deleteUser, EmailAuthCredential, EmailAuthProvider, onAuthStateChanged, reauthenticateWithCredential, signInWithCredential, signInWithEmailAndPassword, updateCurrentUser, updateEmail, updatePassword } from "firebase/auth";
import { doc, getDoc, setDoc, onSnapshot, collection, updateDoc, arrayUnion, deleteDoc, query, where, getDocs, arrayRemove } from "firebase/firestore";
import { auth, db } from "../../../firebase";
import AuthContext from "./auth.context";
import AsyncStorage from "@react-native-async-storage/async-storage";


export const AccountContext = createContext();
export const AccountContextProvider = ({ children }) => {
    const { user, logout } = useContext(AuthContext);
    const [uid, setUid] = useState(null);
    const [members, setMembers] = useState([]);
    const [success, setSuccess] = useState(null);
    const [error, setError] = useState(null);

    useEffect(() => {

        console.log("Account context running");
        onAuthStateChanged(auth, (usr) => {
            {
                if (usr) {
                    console.log("yes onauthstateChanged");
                    setUid(auth.currentUser.uid);
                    console.log("current user id in firebase aut", auth.currentUser.uid);
                    // setUser(usr);
                    // setIsAuthenticated(true);
                }
            }
        })
    }, [])

    useEffect(() => {
        getFamilyMembersRealtime()
    }, [])

    const getFamilyMembersRealtime = async () => {
        try {
            const jsonCredentials = await AsyncStorage.getItem('credentials');
            console.log("jsoncredentials", jsonCredentials);
            if (jsonCredentials) {

                const credentials = JSON.parse(jsonCredentials)
                console.log("json parse", credentials);
                const currentUser = await getDoc(doc(db, "users", credentials.userId));
                const familyId = currentUser.get("familyId");
                console.log("family id ", familyId);
                const membersQuery = query(collection(db, 'users'), where('familyId', '==', familyId));
                const data = onSnapshot(membersQuery, (querySnapshot) => {
                    const newMembers = querySnapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() }));
                    setMembers(newMembers);
                    console.log("new memebers", newMembers);
                    console.log("now im running");
                });
            }
        } catch (error) {
            console.log(error);
        }
    }

    const addMemberToFamily = async (memberName, memberEmail, memberPassword, memberRole) => {
        try {
            console.log("is loading");
          //  const currentUserId = user.userId;
//new code 
           const jsonCredentials = await AsyncStorage.getItem('credentials');
if(jsonCredentials){
            const credentials = JSON.parse(jsonCredentials)
const currentUserId=credentials.userId;
            const currentFamily = await getDoc(doc(db, "users", currentUserId));
            console.log("current family", currentFamily);
            const currentFamilyId = currentFamily.get("familyId");
            console.log("current family id", currentFamilyId);
            if (currentFamilyId) {
                const userCredential = await createUserWithEmailAndPassword(
                    auth,
                    memberEmail,
                    memberPassword,
                );
                const memberId = userCredential.user.uid;
                console.log("id changed to memeber", memberId);
                const familyRef = doc(db, "families", currentFamilyId);
                await updateDoc(familyRef, { members: arrayUnion(memberId) });
                console.log("member added in family");
                const userRef = doc(collection(db, "users"), memberId);
                await setDoc(userRef, {
                    name: memberName,
                    email: memberEmail,
                    role: memberRole,
                    familyId: currentFamilyId,
                });
                await signInWithEmailAndPassword(auth, user.email, user.password).then(() => {
                    console.log("after", auth.currentUser);
                }).catch((err) => {
                    console.log(err)
                });

                console.log("user added in user doc");
                console.log("loading complite");
}
            
            }
        } catch (error) {
            console.log("catch error", error);
        }
    }

    const getFamilyMembers = async () => {
        try {
            console.log("is loading");
            const currentUserId = user.userId;
            console.log("current user id in the session", currentUserId);
            const currentFamily = await getDoc(doc(db, "users", currentUserId));
            console.log("current family", currentFamily);
            const familyId = currentFamily.get("familyId");
            console.log("current family id", familyId);
            const familyRef = doc(db, "families", familyId);
            const familySnapshot = await getDoc(familyRef);
            const memberIds = familySnapshot.get("members");
            const memberPromises = memberIds.map(async (memberId) => {
                const memberRef = doc(db, "users", memberId);
                const memberSnapshot = await getDoc(memberRef);
                return {
                    id: memberId,
                    name: memberSnapshot.get("name"),
                    email: memberSnapshot.get("email"),
                    role: memberSnapshot.get("role"),
                };
            });
            const members = await Promise.all(memberPromises);
            console.log(members)
            //member is a object
            members.forEach((item) => {
                console.log(item.id, item.name, item.role);
            })
            console.log("loading complete");
        } catch (error) {

            console.log("Error retrieving family members", error.message);
        }
    }

    const deleteAccount = async () => {
        try {
            auth.currentUser
                .delete()
                .then(() => console.log("User deleted"))
                .catch((error) => console.log(error));
        } catch (error) {
            console.log(error);
        }
    }


    const deleteMemberFromFamily = async (memberId) => {
        try {
            const currentUserId = auth.currentUser.uid;
            const currentFamily = await getDoc(doc(db, "users", currentUserId));
            const currentFamilyId = currentFamily.get("familyId");
            if (currentFamilyId) {
                const familyRef = doc(db, "families", currentFamilyId);
                await updateDoc(familyRef, { members: arrayRemove(memberId) });
                console.log("member removed from family");
                const userRef = doc(db, "users", memberId);
                await deleteDoc(userRef);
                console.log("user document deleted");
            }
        } catch (error) {
            console.log("catch error", error);
        }
    }

    const editMemberDetails = async (memberId, updatedMemberDetails) => {
        try {
            const userRef = doc(db, "users", memberId);
            await updateDoc(userRef, updatedMemberDetails);
            console.log("Member details updated");
        } catch (error) {
            console.log("Error updating member details:", error);
        }
    };

    const changeUserPassword = async (currenPassword, newPassword) => {
        try {
            const user = auth.currentUser;
            const currentEmail = user.email;
            const credential = EmailAuthProvider.credential(currentEmail, currenPassword);
            reauthenticateWithCredential(user, credential)
                .then(() => {
                    // User has been reauthenticated, can now update password or email
                    updatePassword(user, newPassword)
                    const userId = auth.currentUser.uid;
                    const password = newPassword;
                    const email = currentEmail;
                    const credentials = { userId, email, password };
                    AsyncStorage.setItem('credentials', JSON.stringify(credentials));
                    console.log("password changed");
                    // or user.updateEmail(newEmail);
                })
                .catch((error) => {
                    // Handle reauthentication error
                    console.log("Error reauthenticating user:", error);
                });
        } catch (error) {
            console.log(error);
        }
    };



    const changeUserEmail = async (currenPassword, newEmail) => {
        try {
            const user = auth.currentUser;
            const currentEmail = user.email;
            const credential = EmailAuthProvider.credential(currentEmail, currenPassword);
            reauthenticateWithCredential(user, credential)
                .then(() => {
                    // User has been reauthenticated, can now update password or email
                    updateEmail(user, newEmail)
                        .then(() => {
                            const userRef = doc(db, 'users', auth.currentUser.uid);
                            updateDoc(userRef, { email: newEmail });
                        })
                        .then(() => {
                            const userId = auth.currentUser.uid;
                            const password = currenPassword;
                            const email = newEmail;
                            const credentials = { userId, email, password };
                            AsyncStorage.setItem('credentials', JSON.stringify(credentials));
                            console.log("email changed");
                        })
                        .catch((error) => {
                            console.log(error)
                        })

                })
                .catch((error) => {
                    // Handle reauthentication error
                    console.log("Error reauthenticating user:", error);
                });
        } catch (error) {
            console.log(error);
        }
    };



    const assignRoles = async (familyId, memberId, oldRole, newRole) => {
        try {
            const adminQuerySnapshot = await getDocs(
                query(
                    collection(db, "users"),
                    where("familyId", "==", familyId),
                    where("role", "==", "admin")
                )
            );

            console.log("Query docs length", adminQuerySnapshot.docs.length);

            if (newRole === "member" && adminQuerySnapshot.docs.length === 1) {
                throw new Error("There must be at least one admin in the family");
            }

            // Update member role in user document
            const userRef = doc(db, "users", memberId);
            await updateDoc(userRef, { role: newRole }).then(() => {
                if (oldRole === "admin" && newRole === "member") {
                    logout()
                }
            });

            return "Member role updated successfully";
        } catch (error) {
            console.log("Error updating member role:", error.message);
            return error.message;
        }
    };






    const updateProfile = async (name, image) => {
        const userRef = doc(db, 'users', auth.currentUser.uid);
        await updateDoc(userRef, { name: newEmail, profileUrl });
    }


    return (
        <AccountContext.Provider
            value={{
                success,
                error,
                members,
                uid,
                addMemberToFamily,
                updateProfile,
                changeUserPassword,
                changeUserEmail,
                assignRoles,
                deleteMemberFromFamily,
            }}
        >
            {children}
        </AccountContext.Provider>
    )
}

