import React, { useState, createContext } from "react";
//image upload things
import * as ImagePicker from 'expo-image-picker';
import { getStorage, ref, uploadBytesResumable, getDownloadURL } from "firebase/storage";

export const UploadImageContext = createContext();

export const UploadImageContextProvider = ({ children }) => {

    const storage = getStorage();
    const [uploading, setUploading] = useState(true);
    const [progress, setProgress] = useState(null);
    const [uploadSucess, setUploadSuccess] = useState(null)
    const [uploadError, setUploadError] = useState(null)

    const selectImage = async () => {
        try {
            let result = await ImagePicker.launchImageLibraryAsync({
                mediaTypes: ImagePicker.MediaTypeOptions.Images,
                allowsEditing: true,
                aspect: [4, 3],
                quality: 1,
            });

            if (!result.canceled) {
                return result.assets[0].uri;
            }
        } catch (error) {
            alert(error);
        }
    }


    const uploadInFirebaseStorage = async (imageUri) => {
        try {
            setUploading(true);
            // Get a reference to the file in Firebase Storage
            const fileExtension = imageUri.split(".").pop();
            const filename = `${Date.now()}_${Math.floor(Math.random() * 1000000)}`;
            const storageRef = ref(storage, `profile_photos/${filename}.${fileExtension}`);
            // Upload the file using a resumable upload task
            const response = await fetch(imageUri);
            const blob = await response.blob();
            const uploadTask = uploadBytesResumable(storageRef, blob);

            // Listen to upload progress updates
            uploadTask.on("state_changed", (snapshot) => {
                const progress = Math.round((snapshot.bytesTransferred / snapshot.totalBytes) * 100);
                setProgress(progress);
            });
            // Wait for the upload to complete
            await uploadTask;
            // Get the download URL of the uploaded file
            const downloadURL = await getDownloadURL(storageRef);
            console.log("Profile photo uploaded successfully");
            setUploadSuccess("Profile photo uploaded successfully");
            return downloadURL;
        } catch (error) {
            console.log("Error uploading image:", error);
            setUploadError("Error uploading image:", error);
        } finally {
            setUploading(false);
        }
    }
    return (
        <UploadImageContext.Provider
            value={{
                uploading,
                setUploading,
                progress,
                setProgress,
                uploadSucess,
                setUploadSuccess,
                uploadError,
                setUploadError,
                selectImage,
                uploadInFirebaseStorage,
            }}
        >
            {children}
        </UploadImageContext.Provider>
    )
}


/*
usage 
import { UploadImageContext } from '../services/firebase-storage/imageUpload.context';
 const {
        uploading,
        setUploading,
        progress,
        setProgress,
        uploadSucess,
        setUploadSuccess,
        uploadError,
        setUploadError,
        selectImage,
        uploadInFirebaseStorage
    } = useContext(UploadImageContext);
    const [image, setImage] = useState(null);
    const [profileDownloadedUri, setProfileDownlaodedUri] = useState(null);

    const handleSelectImage = async () => {
        const uri = await selectImage()
        setImage(uri);
    }

    const handleUpload = async (image) => {
        const uri = await uploadInFirebaseStorage(image);
        if (uri) {
            setProfileDownlaodedUri(uri);
            setUploadError(null);
        }

    }
    const AddData = () => {
        setUploadError(null);
        setUploadSuccess(null);
        setProgress(null);
    }
            <View>
            <Button title='upload profile photo' onPress={() => { handleSelectImage() }} />
            {image && (
                <View>
                    <Image source={{ uri: image }}
                        alt={"logo"} width={200} height={200} alignContent={"center"} justifyContent={"center"}
                        borderRadius={7} margin={5} padding={5} />
                    <TouchableOpacity onPress={() => { setImage(null) }}><Text>Remove</Text></TouchableOpacity>
                    <Button title='upload' onPress={() => { handleUpload(image) }} />
                </View>
            )}
            {uploading && (<Text>{progress}%</Text>)}
            {uploadError && (<Text>{uploadError}</Text>)}
            {uploadSucess && (<Text>{uploadSucess}</Text>)}
            <Button title='submit' onPress={() => {
                AddData();
            }} />
        </View>

*/


