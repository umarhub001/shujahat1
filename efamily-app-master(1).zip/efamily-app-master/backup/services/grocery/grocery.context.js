import React, { createContext, useEffect, useState } from 'react'
import { doc, getDoc, setDoc, addDoc, onSnapshot, collection, updateDoc, arrayUnion, deleteDoc, query, where, getDocs } from "firebase/firestore";
import { auth, db } from '../../../firebase';
import AsyncStorage from '@react-native-async-storage/async-storage';



export const GroceryContext = createContext();

export const GroceryServiceProvider = ({ children }) => {
    const [success, setSuccess] = useState("done");
    const [groceries, setGroceries] = useState([]);
    const [realTimeLoading, setRealTimeLoading] = useState(null);



    useEffect(() => {
        console.log("grocery context running");
        getGroceryItemRealTime()
    }, [])


    const addGroceryItem = async (name, quantity) => {
        try {
            // Create a new document in "groceries" collection
            const userId = auth.currentUser.uid;
            console.log("current user id", userId);
            const currentFamily = await getDoc(doc(db, "users", userId));
            const familyId = currentFamily.get("familyId");
            const userName = currentFamily.get("name");
            const now = new Date();
            const options = {
                hour: 'numeric',
                minute: 'numeric',
                hour12: true,
                month: 'numeric',
                day: 'numeric',
                year: '2-digit'
            };
            const createdAt = now.toLocaleString('en-US', options);
            await addDoc(collection(db, `families/${familyId}/groceries`), {
                name,
                quantity,
                createdAt,
                addedBy: userName,
                completed: false,
                status: false
            });

            console.log("Grocery added successfully with ID: ");
            return "Grocery added successfully";
        } catch (error) {
            console.error("Error adding grocery item: ", error);
            return error.message;
        }

        /*prototype
             addGroceryItem("Milk", 3)
             .then((success)=>{console.log(success)})
             .catch((error)=>{console.log(error)});
        */
    };

    const getGroceryItemRealTime = async () => {
        try {
            setRealTimeLoading(true);
            const jsonCredentials = await AsyncStorage.getItem('credentials');
            console.log("jsoncredentials", jsonCredentials);
            if (jsonCredentials) {
                const credentials = JSON.parse(jsonCredentials)
                const currentUser = await getDoc(doc(db, "users", credentials.userId));
                const familyId = currentUser.get("familyId");
                const groceriesQuery = query(collection(db, "families", familyId, "groceries"));
                // const groceriesQuery = query(collection(db, `families/${familyId}/groceries`));
                const data = onSnapshot(groceriesQuery, (querySnapshot) => {
                    const newGroceries = querySnapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() }));
                    setGroceries(newGroceries);
                    console.log("new grocries", newGroceries);
                    console.log("now realtime groceries is running");
                });

            }
        } catch (error) {
            setRealTimeLoading(false);
            console.log(error);
        }

        /*
    const approvedGroceries = groceries.filter(grocery => grocery.status === true);
    const completeGroceries = groceries.filter(grocery => grocery.completed === true);
    const notApprovedGroceries = groceries.filter(grocery => grocery.status === false);
    const notCompletedGroceries = groceries.filter(grocery => grocery.completed === false);

    //which items are approved but not completed
       const filteredApprovedAndIncompleteGroceries = approvedGroceries.filter(grocery => grocery.completed === false);

        */

    }


    const approveGroceryItem = async (itemId) => {
        try {
            const jsonCredentials = await AsyncStorage.getItem('credentials');
            console.log("jsoncredentials", jsonCredentials);
            if (jsonCredentials) {
                const credentials = JSON.parse(jsonCredentials)
                const currentUser = await getDoc(doc(db, "users", credentials.userId));
                const familyId = currentUser.get("familyId");
                const groceryRef = doc(collection(db, 'families', familyId, 'groceries'), itemId);
                await updateDoc(groceryRef, { status: true });
                console.log(`Grocery item ${itemId} approved!`);
                return "Grocery item approved";
            }
        } catch (error) {
            console.error('Error approving grocery item:', error);
            return error.message;
        }
    }

    const deleteGroceryItem = async (itemId) => {
        try {
            const jsonCredentials = await AsyncStorage.getItem('credentials');
            if (jsonCredentials) {
                const credentials = JSON.parse(jsonCredentials);
                const currentUser = await getDoc(doc(db, "users", credentials.userId));
                const familyId = currentUser.get("familyId");
                await deleteDoc(doc(db, "families", familyId, "groceries", itemId));
                console.log("Grocery item deleted successfully.");
                return "Grocery item deleted successfully";
            }
        } catch (error) {
            console.log(error);
            return error.message;
        }
    }


    const completeGroceryItem = async (groceryItemId) => {
        try {
            const jsonCredentials = await AsyncStorage.getItem('credentials');
            console.log("jsoncredentials", jsonCredentials);
            if (jsonCredentials) {
                const credentials = JSON.parse(jsonCredentials)
                const currentUser = await getDoc(doc(db, "users", credentials.userId));
                const familyId = currentUser.get("familyId");
                const userName = currentUser.get("name");
                const groceryItemRef = doc(db, "families", familyId, "groceries", groceryItemId);
                const now = new Date();
                const options = {
                    hour: 'numeric',
                    minute: 'numeric',
                    hour12: true,
                    month: 'numeric',
                    day: 'numeric',
                    year: '2-digit'
                };
                const completedAt = now.toLocaleString('en-US', options);
                await updateDoc(groceryItemRef, {
                    completed: true,
                    completedBy: userName,
                    competedAt: completedAt,

                });
            }
        } catch (error) {
            console.log(error);
        }
    };



    return (
        <GroceryContext.Provider
            value={{
                realTimeLoading,
                groceries,
                addGroceryItem,
                approveGroceryItem,
                deleteGroceryItem,
                completeGroceryItem,
            }}
        >
            {children}
        </GroceryContext.Provider>
    )
}



