import { View, Text } from 'react-native'
import React, { createContext, useEffect, useState } from 'react'
import { doc, getDoc, setDoc, addDoc, onSnapshot, collection, updateDoc, arrayUnion, deleteDoc, query, where, getDocs } from "firebase/firestore";
import { auth, db } from '../../../firebase';
import AsyncStorage from '@react-native-async-storage/async-storage';

export const TaskContext = createContext();

export const TaskContextProvider = ({ children }) => {

    const [success, setsuccess] = useState("done");
    const [tasks, setTasks] = useState([])


    useEffect(() => {
        console.log("task context running");
        getAllTasksRealTime()
    }, [])



    const assignTask = async (taskName, startDate, endDate, userId) => {
        try {
            const member = await getDoc(doc(db, "users", userId));
            const familyId = member.get("familyId");
            const memberName = member.get("name");
            const taskRef = collection(db, `families/${familyId}/tasks`);
            const now = new Date();
            const options = {
                hour: 'numeric',
                minute: 'numeric',
                hour12: true,
                month: 'numeric',
                day: 'numeric',
                year: '2-digit'
            };
            const createdAt = now.toLocaleString('en-US', options);
            const newTask = {
                name: taskName,
                userId: userId,
                assignedTo: memberName,
                dueDate: startDate,
                endDate: endDate,
                createdAt: createdAt,
                completed: false,
            };
            await addDoc(taskRef, newTask);
            console.log('Task assigned with ID: ');
            return "task assigned success";

        } catch (error) {
            console.error('Error assigning task: ', error);
            return "Error assigning task: ", error.message;

        }
    };

    const completeTask = async (taskId) => {
        try {
            const jsonCredentials = await AsyncStorage.getItem('credentials');
            console.log("jsoncredentials", jsonCredentials);
            if (jsonCredentials) {
                const credentials = JSON.parse(jsonCredentials)
                const currentUser = await getDoc(doc(db, "users", credentials.userId));
                const familyId = currentUser.get("familyId");
                const taskRef = doc(db, "families", familyId, "tasks", taskId);
                const now = new Date();
                const options = {
                    hour: 'numeric',
                    minute: 'numeric',
                    hour12: true,
                    month: 'numeric',
                    day: 'numeric',
                    year: '2-digit'
                };
                const completedAt = now.toLocaleString('en-US', options);
                await updateDoc(taskRef, {
                    completed: true,
                    competedAt: completedAt,
                });
                return "task completed";
            }
        } catch (error) {
            console.log(error);
            return error.message;
        }
    };


    const rateTask = async (taskId, rate) => {
        try {
            const jsonCredentials = await AsyncStorage.getItem('credentials');
            console.log("jsoncredentials", jsonCredentials);
            if (jsonCredentials) {
                const credentials = JSON.parse(jsonCredentials)
                const currentUser = await getDoc(doc(db, "users", credentials.userId));
                const familyId = currentUser.get("familyId");
                const taskRef = doc(db, "families", familyId, "tasks", taskId);
                await updateDoc(taskRef, {
                    rate: rate
                });
                return "rating done";
            }
        } catch (error) {
            console.log(error);
            return error.message;
        }
    };


    const getAllTasksRealTime = async () => {
        try {

            const jsonCredentials = await AsyncStorage.getItem('credentials');
            if (jsonCredentials) {
                const credentials = JSON.parse(jsonCredentials)
                const currentUser = await getDoc(doc(db, "users", credentials.userId));
                const familyId = currentUser.get("familyId");
                const tasksQuery = query(collection(db, "families", familyId, "tasks"));
                const data = onSnapshot(tasksQuery, (querySnapshot) => {
                    const newTasks = querySnapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() }));
                    setTasks(newTasks);
                    console.log("new tasks", newTasks);
                    console.log("now realtime all tasks is running");
                });
            }
        } catch (error) {
            console.log(error);
        }

        //prototype  const assignTask = async (taskName, startDate, endDate, userId) 
        /*
    tasks //all tasks
   const completedTasks = tasks.filter(task => task.completed === true);
   const inCompleteTasks = tasks.filter(task => task.completed === false);

    const currentUserTasks = tasks.filter(task => task.userId === uid);
    const currentUserCompletedTasks = currentUserTasks.filter(task => task.completed === true);
    const currentUserInCompleteTasks = currentUserTasks.filter(task => task.completed === false);

      */
    };

    const deleteTask = async (taskId) => {
        try {
            const jsonCredentials = await AsyncStorage.getItem('credentials');
            if (jsonCredentials) {
                const credentials = JSON.parse(jsonCredentials);
                const currentUser = await getDoc(doc(db, "users", credentials.userId));
                const familyId = currentUser.get("familyId");
                await deleteDoc(doc(db, "families", familyId, "tasks", taskId));
                console.log("task deleted successfully.");
                return "task deleted successfully";
            }
        } catch (error) {
            console.log(error);
            return error.message;
        }
    };




    return (
        <TaskContext.Provider
            value={{
                success,
                tasks,
                assignTask,
                completeTask,
                rateTask,
                deleteTask,
            }}
        >
            {children}
        </TaskContext.Provider>
    )
}

