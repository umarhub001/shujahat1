import React, { createContext, useContext, useEffect, useState } from 'react'
import { doc, getDoc, setDoc, addDoc, onSnapshot, collection, updateDoc, arrayUnion, deleteDoc, query, where, getDocs } from "firebase/firestore";
import { auth, db } from '../../../firebase';
import AsyncStorage from '@react-native-async-storage/async-storage';
export const WeeklyMenuContext = createContext();
export const WeeklyMenuContextProvider = ({ children }) => {
    const [success, setSuccess] = useState("done");
    const [menu, setMenu] = useState([])
    const [meals, setMeals] = useState([])
    useEffect(() => {
        console.log("Weekly menu context running")
        getMenuRealTime()
        getMealsRealTime()
    }, [])

    const addMeal = async (mealFor, mealName, mealImage) => {
        try {
            const userId = auth.currentUser.uid;
            console.log("current user id", userId);
            const currentFamily = await getDoc(doc(db, "users", userId));
            const familyId = currentFamily.get("familyId");
            const userName = currentFamily.get("name");
            await addDoc(collection(db, `families/${familyId}/mealList`),
                {
                    mealFor: "",
                    mealName: "breakfast",
                    MealImage: "locla/imhe",
                }
            );
            console.log("meal added");
            return "meal added";
        } catch (error) {
            console.log(error);
            return error.message;
        }
    }


    const addMenu = async (mealFor, mealName, mealDescription, mealImage) => {
        try {
            const userId = auth.currentUser.uid;
            console.log("current user id", userId);
            const currentFamily = await getDoc(doc(db, "users", userId));
            const familyId = currentFamily.get("familyId");
            const userName = currentFamily.get("name");
            await addDoc(collection(db, `families/${familyId}/menuList`),
                {
                    mealFor,
                    mealName,
                    mealDescription,
                    mealImage,
                }
            );
            console.log("menu added");
            return "menu created";
        } catch (error) {
            console.log(error);
            return error.message;
        }
    }

    const getMenuRealTime = async () => {
        try {
            const jsonCredentials = await AsyncStorage.getItem('credentials');
            console.log("jsoncredentials", jsonCredentials);
            if (jsonCredentials) {
                const credentials = JSON.parse(jsonCredentials)
                const currentUser = await getDoc(doc(db, "users", credentials.userId));
                const familyId = currentUser.get("familyId");
                const menuQuery = query(collection(db, "families", familyId, "weeklyMenu"));
                const data = onSnapshot(menuQuery, (querySnapshot) => {
                    const newMenu = querySnapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() }));
                    setMenu(newMenu);
                    console.log("new menu", newMenu);
                    console.log("now realtime weekly menu is running");
                });

            }
        } catch (error) {
            console.log(error);
        }
    }

    const getMealsRealTime = async () => {
        try {
            const jsonCredentials = await AsyncStorage.getItem('credentials');
            console.log("jsoncredentials", jsonCredentials);
            if (jsonCredentials) {
                const credentials = JSON.parse(jsonCredentials)
                const currentUser = await getDoc(doc(db, "users", credentials.userId));
                const familyId = currentUser.get("familyId");
                const mealsQuery = query(collection(db, "families", familyId, "mealList"));
                const data = onSnapshot(mealsQuery, (querySnapshot) => {
                    const newMeals = querySnapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() }));
                    setMeals(newMeals);
                    console.log("new meals", newMeals);
                    console.log("now realtime meal list is running");
                });

            }
        } catch (error) {
            console.log(error);
        }
    }


    const updateMenu = async () => {
        try {
            console.log("menu updated");
            return "menu updated";
        } catch (error) {
            console.log(error);
            return error.message;
        }

    }

    const deleteMenu = async () => {
        try {
            console.log("menu added");
            return "menu deleted";
        } catch (error) {
            console.log(error);
            return error.message;
        }

    }

    const createWeeklyMenu = async () => {
        try {
            const userId = auth.currentUser.uid;
            const currentFamily = await getDoc(doc(db, "users", userId));
            const familyId = currentFamily.get("familyId");

            const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];

            for (const day of days) {
                const menuDocRef = doc(db, `families/${familyId}/weeklyMenu/${day}`);
                await setDoc(menuDocRef, {});
            }

            console.log("Weekly menu created successfully");
        } catch (error) {
            console.log(error)
        }
    }
    const getWeeklyMenu = async (week) => {
        try {
            const userId = auth.currentUser.uid;
            const currentFamily = await getDoc(doc(db, "users", userId));
            const familyId = currentFamily.get("familyId");

            const menuRef = collection(db, `families/${familyId}/weeklyMenu`);
            const querySnapshot = await getDocs(menuRef.where("week", "==", week));

            const weeklyMenu = {};
            querySnapshot.forEach((doc) => {
                const data = doc.data();
                weeklyMenu[data.day] = data;
            });

            const prefRef = collection(db, `families/${familyId}/users`);
            const prefSnapshot = await getDocs(prefRef);

            prefSnapshot.forEach((doc) => {
                const data = doc.data();
                const userName = data.name;
                const preferences = data.preferences;

                Object.entries(preferences).forEach(([day, pref]) => {
                    if (weeklyMenu[day]) {
                        if (!weeklyMenu[day].preferences) {
                            weeklyMenu[day].preferences = {};
                        }
                        weeklyMenu[day].preferences[userName] = pref;
                    }
                });
            });

            return weeklyMenu;
        } catch (error) {
            console.log(error);
        }
    };

    const getPreferencesCount = async (day) => {
        try {
            const userId = auth.currentUser.uid;
            console.log("current user id", userId);
            const currentFamily = await getDoc(doc(db, "users", userId));
            const familyId = currentFamily.get("familyId");

            const preferencesRef = collection(db, `families/${familyId}/${userId}/preferences/${day}`);
            const querySnapshot = await getDocs(query(preferencesRef, day));

            //const querySnapshot = await getDocs(db, `families/${familyId}/weeklyMenu`, day);

            console.log(querySnapshot.forEach((data) => {
                console.log(data)
            }));
            if (!querySnapshot.empty) {
                const doc = querySnapshot.docs[0];
                const breakfastCount = doc.get("breakfast") || 0;
                const lunchCount = doc.get("lunch") || 0;
                const dinnerCount = doc.get("dinner") || 0;
                const total = breakfastCount + lunchCount + dinnerCount;

                console.log(`Total preferences for ${day}: ${total}`);
                console.log(`Breakfast: ${breakfastCount}`);
                console.log(`Lunch: ${lunchCount}`);
                console.log(`Dinner: ${dinnerCount}`);
            }

            console.log("get preferences count is success");
        } catch (error) {
            console.log(error);
        }

    };

    const setMealPreference = async (day, mealType, preference) => {
        try {

            console.log("in setMealPreference method of Menu context");
            const userId = auth.currentUser.uid;
            console.log("current user id", userId);
            const currentFamily = await getDoc(doc(db, "users", userId));
            const familyId = currentFamily.get("familyId");
            const userName = currentFamily.get("name");

            const menuDocRef = doc(db, `families/${familyId}/weeklyMenu/${day}`);
            const menuDocSnapshot = await getDoc(menuDocRef);

            if (menuDocSnapshot.exists()) {
                const updatedMenu = { ...menuDocSnapshot.data() };
                updatedMenu[mealType] = preference;

                await setDoc(menuDocRef, updatedMenu);
                const userPrefRef = doc(db, `families/${familyId}/users/${userId}/preferences/${day}`);
                await setDoc(userPrefRef, { mealType, preference });
                console.log("prefrence is added ");
            }
        } catch (error) {
            console.log(error)
        }
    }



    return (
        <WeeklyMenuContext.Provider
            value={{
                success,
                menu,
                meals,
                addMenu,
                addMeal,
                createWeeklyMenu,
                setMealPreference,
                getPreferencesCount,
            }}
        >
            {children}
        </WeeklyMenuContext.Provider>
    )
}