
import React, { createContext, useState, useEffect } from "react";
import { createUserWithEmailAndPassword, signInWithEmailAndPassword, onAuthStateChanged, signOut } from 'firebase/auth';
import { doc, setDoc, getDoc, collection } from 'firebase/firestore';
import { db, auth } from "../../../firebase";
import AsyncStorage from "@react-native-async-storage/async-storage";

export const AuthContext = createContext();


export const AuthContextProvider = ({ children }) => {
    const [user, setUser] = useState([]);
    const [error, setError] = useState(null);
    const [isLoading, setIsLoading] = useState(false);
    const [isStateLoading, setStateLoading] = useState(false);
    const [isAuthenticated, setIsAuthenticated] = useState(false);
    const [isAdmin, setIsAdmin] = useState(false)

    useEffect(() => {
        const getAdminStatus = async () => {
            const newIsAdmin = await AsyncStorage.getItem('isAdmin');
            const currentIsAdmin = isAdmin;
            if (newIsAdmin === 'true' && currentIsAdmin !== true) {
                setIsAdmin(true);
            } else if (newIsAdmin === 'false' && currentIsAdmin !== false) {
                setIsAdmin(false);
            }
        }
        getAdminStatus();
    }, [isAdmin]);


    useEffect(() => {
        /*onAuthStateChanged(auth, (usr) => {
            {
                if (usr) {
                    console.log("yes loading start");
                    setUser(usr);
                    setIsAuthenticated(true);
                }
            }
        })*/


    }, [])


    const handleStatus = async (status) => {
        await AsyncStorage.setItem('isAdmin', status === 'admin' ? 'true' : 'false');

        const result = await AsyncStorage.getItem('isAdmin');
        if (result === 'true') {
            setIsAdmin(true);
        }
        setStateLoading(true);
        setTimeout(() => {
            setStateLoading(false)
        }, 2000);
    }

    const handleSignUpWithPromise = (name, family_name, email, password) => {
        return new Promise((resolve, reject) => {
            setIsLoading(true);
            createUserWithEmailAndPassword(auth, email, password)
                .then((userCredential) => {
                    // Set user document in firestore
                    const userRef = doc(db, 'users', userCredential.user.uid);
                    const familyRef = doc(collection(db, "families"));
                    const newFamily = {
                        name: family_name,
                        members: [userCredential.user.uid]
                    };
                    const data = {
                        name: name,
                        email: email,
                        familyName: family_name,
                        role: 'admin',
                        familyId: familyRef.id // add familyId here
                    };
                    return Promise.all([setDoc(userRef, data), setDoc(familyRef, newFamily)]);
                })
                .then(() => {
                    setIsLoading(false);
                    resolve('Promise resolved');
                })
                .catch((error) => {
                    setIsLoading(false);
                    reject(error);
                });
        });
    };


    const signUp = (name, family_name, email, password) => {
        handleSignUpWithPromise(name, family_name, email, password)
            .then((result) => {
                console.log(result); // Promise resolved
                handleStatus("admin");
                setIsAuthenticated(true);
                setError('');
            })
            .catch((error) => {
                console.error(error.code);
                setError(error.code);
            });
    }

    const signIn = (email, password) => {
        setIsLoading(true);
        signInWithEmailAndPassword(auth, email, password)
            .then((userCredential) => {
                return getDoc(doc(db, 'users', userCredential.user.uid));
            })
            .then((userDoc) => {
                setStateLoading(true);
                const userData = userDoc.data();
                //  console.log(userData);
                // Check if user is an admin and set isAdmin status accordingly
                handleStatus(userData.role);
                //   console.log("user status", userData.role);
                setTimeout(() => {
                    setIsAuthenticated(true);
                    setIsLoading(false);
                }, 1000);
            })
            .catch((error) => {
                console.error('Error:', error.code);
                setError(error.code);
                setIsLoading(false);
            });
    }


    const logout = () => {
        setIsLoading(true);
        signOut(auth).then(() => {
            // Sign-out successful.
            //   setUser(null);
            setIsAuthenticated(false);
            handleStatus("false");
            setIsAdmin(false);
            setIsLoading(false);
            console.log(" user logout");
        }).catch((error) => {
            setIsLoading(false);
            console.log("cannot logout");
            // An error happened.
        });

    }

    return (
        <AuthContext.Provider
            value={{
                user,
                error,
                isLoading,
                isStateLoading,
                isAuthenticated,
                isAdmin,
                signIn,
                signUp,
                logout,
            }}>
            {children}
        </AuthContext.Provider>
    )
}


export default AuthContext;