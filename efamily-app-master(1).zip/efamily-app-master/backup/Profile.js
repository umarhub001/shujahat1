import { View, Text, Button } from "native-base";
import { useContext } from "react";
import AuthContext from "../src/services/account/auth.context";

function Profile() {
    const { user, login } = useContext(AuthContext);

    return (
        <View>
            <Text>Profile</Text>
            {user ? (
                <>
                    <Text>Welcome, {user.displayName}</Text>

                </>
            ) : (
                <Button onPress={() => {
                    login("quaid Ahmed")
                }
                }>Sign in with Google</Button>
            )}
        </View>
    );
}

export default Profile;
