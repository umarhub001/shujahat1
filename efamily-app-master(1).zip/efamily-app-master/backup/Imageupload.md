
//image upload things
import * as ImagePicker from 'expo-image-picker';
import { getStorage, ref, uploadBytesResumable, getDownloadURL } from "firebase/storage";


const Home = () => {
    const { logout } = useContext(AuthContext);
    const { addMemberToFamily, members } = useContext(AccountContext);
    //console.log("am in home", members);
    members.forEach(element => {
        console.log(element)
    });
    //Prototype
    //addMemberToFamily=(memberName, memberEmail, memberPassword, memberRole);
    return (
        <AppThemeProvider>
            <View>
                <Text>Admin home screen</Text>
                <Button title='add family member' onPress={() => {
                    addMemberToFamily("quaid ali", "efamily5@gmail.com", "password", "member");
                }} />
                <Button title='logout' onPress={() => { logout() }} />

            </View>
            <HStack
                space={22}
                alignItems="center"
                m={4}
                p={2}
                // rounded="md"
                _light={{
                    bg: 'error.100',
                }}
                _dark={{
                    bg: 'error.400',
                }}
                w="90%"
            >
                <Box
                    // rounded="full"
                    rounded={2}
                    _light={{
                        bg: 'error.500',
                    }}
                    _dark={{
                        bg: 'error.200',
                    }}
                    size="50px"
                />
                <VStack space={1} flex={1}>
                    <Box
                        _light={{
                            bg: 'red.400',
                        }}
                        _dark={{
                            bg: 'gray.100',
                        }}
                        // rounded="sm"
                        h="11px"
                        w="50%"
                    />
                    <Box
                        _light={{
                            bg: 'red.300',
                        }}
                        _dark={{
                            bg: 'gray.100',
                        }}
                        h="8px"
                        // rounded="pill"
                        w="100"
                    />
                </VStack>
            </HStack>



        </AppThemeProvider>

    )
}
const Event = () => {
    const { auth, changeUserEmail, changeUserPassword, addMemberToFamily, members } = useContext(AccountContext);
    console.log("Iam in event", members);
    //start code of image uplaod
    const storage = getStorage();
    const [image, setImage] = useState(null);
    const [uploading, setUploading] = useState(false);
    const [progress, setProgress] = useState(0);
    const selectPhoto = async () => {
        let result = await ImagePicker.launchImageLibraryAsync({
            mediaTypes: ImagePicker.MediaTypeOptions.Images,
            allowsEditing: true,
            aspect: [4, 3],
            quality: 1,
        });

        if (!result.cancelled) {
            return result.assets[0].uri;
        }
    };

    const uploadPhoto = async (imageUri) => {
        try {
            setUploading(true);
            // Get a reference to the file in Firebase Storage
            const fileExtension = imageUri.split(".").pop();
            const filename = `${Date.now()}_${Math.floor(Math.random() * 1000000)}`;
            const storageRef = ref(storage, `profile_photos/${filename}.${fileExtension}`);

            // Upload the file using a resumable upload task
            const response = await fetch(imageUri);
            const blob = await response.blob();
            const uploadTask = uploadBytesResumable(storageRef, blob);

            // Listen to upload progress updates
            uploadTask.on("state_changed", (snapshot) => {
                const progress = Math.round((snapshot.bytesTransferred / snapshot.totalBytes) * 100);
                setProgress(progress);
            });
            // Wait for the upload to complete
            await uploadTask;
            // Get the download URL of the uploaded file
            const downloadURL = await getDownloadURL(storageRef);
            console.log("Profile photo uploaded successfully");
            return downloadURL;
        } catch (error) {
            console.log("Error uploading profile photo:", error);
        } finally {
            setUploading(false);
        }
    };

    const promisee = async () => {
        try {
            const uri = await selectPhoto();
            if (uri) {
                const imageLink = await uploadPhoto(uri);
                alert(imageLink);
            }
        } catch (error) {
            console.log(error);
        }
    };



    return (
        <View>
            <Button title='upload profile photo' onPress={selectPhoto} />
            {image && (
                <View>
                    <Image source={{ uri: image }}
                        alt={"logo"} width={200} height={200} alignContent={"center"} justifyContent={"center"}
                        borderRadius={7} margin={5} padding={5} />
                    <TouchableOpacity onPress={() => { setImage(null) }}><Text>Remove</Text></TouchableOpacity>
                    <Text>{progress}</Text>
                    <Button title='upload' onPress={() => { uploadPhoto(image) }} />
                    <Button title='upload' onPress={() => { promisee(image) }} />
                </View>
            )}
        </View>
    )

