import React, { useState } from 'react';
import { StyleSheet, Text, View, TextInput, Button } from 'react-native';
import moment from 'moment';
import { Calendar, CalendarList, Agenda } from 'react-native-calendars';
import * as AddCalendarEvent from 'react-native-add-calendar-event';

const utcDateToString = (momentInUTC: moment): string => {
    let s = moment.utc(momentInUTC).format('YYYY-MM-DDTHH:mm:ss.SSS[Z]');
    return s;
};

const App = () => {
    const [title, setTitle] = useState('');
    const [startDate, setStartDate] = useState('');
    const [endDate, setEndDate] = useState('');
    const [description, setDescription] = useState('');
    const [markedDates, setMarkedDates] = useState({});

    const handleCreateEvent = () => {
        const eventConfig = {
            title,
            startDate: utcDateToString(moment(startDate)),
            endDate: utcDateToString(moment(endDate)),
            notes: description,
            navigationBarIOS: {
                tintColor: 'orange',
                backgroundColor: 'green',
                titleColor: 'blue',
            },
        };

        AddCalendarEvent.presentEventCreatingDialog(eventConfig)
            .then((eventInfo: { calendarItemIdentifier: string, eventIdentifier: string }) => {
                // handle success - receives an object with `calendarItemIdentifier` and `eventIdentifier` keys, both of type string.
                // These are two different identifiers on iOS.
                // On Android, where they are both equal and represent the event id, also strings.
                // when { action: 'CANCELED' } is returned, the dialog was dismissed
                console.warn(JSON.stringify(eventInfo));
                setMarkedDates({
                    ...markedDates,
                    [moment(startDate).format('YYYY-MM-DD')]: {
                        selected: true,
                        marked: true,
                        dotColor: 'red',
                    }
                });
                setTitle('');
                setStartDate('');
                setEndDate('');
                setDescription('');
            })
            .catch((error: string) => {
                // handle error such as when user rejected permissions
                console.warn(error);
            });
    };

    return (
        <View style={styles.container}>
            <Text style={styles.label}>Event Title:</Text>
            <TextInput
                style={styles.input}
                value={title}
                onChangeText={setTitle}
                placeholder="Enter title"
            />
            <Text style={styles.label}>Start Date:</Text>
            <TextInput
                style={styles.input}
                value={startDate}
                onChangeText={setStartDate}
                placeholder="YYYY-MM-DD HH:mm:ss"
            />
            <Text style={styles.label}>End Date:</Text>
            <TextInput
                style={styles.input}
                value={endDate}
                onChangeText={setEndDate}
                placeholder="YYYY-MM-DD HH:mm:ss"
            />
            <Text style={styles.label}>Description:</Text>
            <TextInput
                style={styles.input}
                value={description}
                onChangeText={setDescription}
                placeholder="Enter description"
            />
            <Button title="Create Event" onPress={handleCreateEvent} />
            <View style={{ marginTop: 20 }}>
                <Calendar
                    markedDates={markedDates}
                />
            </View>
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        padding: 20,
        backgroundColor: '#fff',
        alignItems: 'center',
        justifyContent: 'center',
    },
    label: {
        fontSize: 18,
        fontWeight: 'bold',
        marginTop: 10,
    },
    input: {
        borderWidth: 1,
        borderColor: '#ccc',
        borderRadius: 4,
        padding: 10,
        width: '100%',
        marginTop: 5,
        marginBottom: 10,
        fontSize: 18,
    },

});
export default App;



//without style large
import React, { useState } from 'react';
import { StyleSheet, Text, View, TextInput, Button } from 'react-native';
import moment from 'moment';
import { Calendar, CalendarList, Agenda } from 'react-native-calendars';
import * as AddCalendarEvent from 'react-native-add-calendar-event';

const utcDateToString = (momentInUTC: moment): string => {
    let s = moment.utc(momentInUTC).format('YYYY-MM-DDTHH:mm:ss.SSS[Z]');
    return s;
};

const App = () => {
    const [title, setTitle] = useState('');
    const [startDate, setStartDate] = useState('');
    const [endDate, setEndDate] = useState('');
    const [description, setDescription] = useState('');
    const [markedDates, setMarkedDates] = useState({});

    const handleCreateEvent = () => {
        const eventConfig = {
            title,
            startDate: utcDateToString(moment(startDate)),
            endDate: utcDateToString(moment(endDate)),
            notes: description,
            navigationBarIOS: {
                tintColor: 'orange',
                backgroundColor: 'green',
                titleColor: 'blue',
            },
        };

        AddCalendarEvent.presentEventCreatingDialog(eventConfig)
            .then((eventInfo: { calendarItemIdentifier: string, eventIdentifier: string }) => {
                // handle success - receives an object with `calendarItemIdentifier` and `eventIdentifier` keys, both of type string.
                // These are two different identifiers on iOS.
                // On Android, where they are both equal and represent the event id, also strings.
                // when { action: 'CANCELED' } is returned, the dialog was dismissed
                console.warn(JSON.stringify(eventInfo));
                setMarkedDates({
                    ...markedDates,
                    [moment(startDate).format('YYYY-MM-DD')]: {
                        selected: true,
                        marked: true,
                        dotColor: 'red',
                    }
                });
                setTitle('');
                setStartDate('');
                setEndDate('');
                setDescription('');
            })
            .catch((error: string) => {
                // handle error such as when user rejected permissions
                console.warn(error);
            });
    };

    return (
        <View style={styles.container}>
            <Text style={styles.label}>Event Title:</Text>
            <TextInput
                style={styles.input}
                value={title}
                onChangeText={setTitle}
                placeholder="Enter title"
            />
            <Text style={styles.label}>Start Date:</Text>
            <TextInput
                style={styles.input}
                value={startDate}
                onChangeText={setStartDate}
                placeholder="YYYY-MM-DD HH:mm:ss"
            />
            <Text style={styles.label}>End Date:</Text>
            <TextInput
                style={styles.input}
                value={endDate}
                onChangeText={setEndDate}
                placeholder="YYYY-MM-DD HH:mm:ss"
            />
            <Text style={styles.label}>Description:</Text>
            <TextInput
                style={styles.input}
                value={description}
                onChangeText={setDescription}
                placeholder="Enter description"
            />
            <Button title="Create Event" onPress={handleCreateEvent} />
            <View style={{ marginTop: 20 }}>
                <Calendar
                    markedDates={markedDates}
                />
            </View>
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#FFF',
        marginTop: 20,
    },
    header: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        paddingHorizontal: 20,
        borderBottomWidth: 1,
        borderBottomColor: '#CCC',
    },
    monthYearText: {
        fontSize: 20,
        fontWeight: 'bold',
    },
    monthArrowButton: {
        padding: 10,
    },
    monthArrowIcon: {
        fontSize: 20,
    },
    daysOfWeekContainer: {
        flexDirection: 'row',
        justifyContent: 'space-evenly',
        alignItems: 'center',
        borderBottomWidth: 1,
        borderBottomColor: '#CCC',
    },
    dayOfWeekText: {
        fontSize: 16,
        fontWeight: 'bold',
        paddingVertical: 10,
    },
    daysContainer: {
        flexDirection: 'row',
        flexWrap: 'wrap',
        justifyContent: 'flex-start',
    },
    dayContainer: {
        width: '14.28%',
        height: 50,
        justifyContent: 'center',
        alignItems: 'center',
    },
    dayText: {
        fontSize: 16,
    },
    selectedDayContainer: {
        backgroundColor: '#00C',
    },
    selectedDayText: {
        color: '#FFF',
    },
    eventIndicatorContainer: {
        position: 'absolute',
        bottom: 0,
        left: 0,
        right: 0,
        paddingVertical: 5,
        paddingHorizontal: 10,
        backgroundColor: '#EEE',
    },
    eventIndicatorText: {
        fontSize: 12,
        color: '#333',
    },

});
export default App;