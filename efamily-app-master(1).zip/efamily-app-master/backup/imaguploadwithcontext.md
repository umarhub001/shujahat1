import { View, Text, Button, TouchableOpacity, } from 'react-native'
import React, { useContext, useEffect, useState } from 'react'
import { createNativeStackNavigator } from '@react-navigation/native-stack';

import AuthContext from '../services/account/auth.context';
import { AppThemeProvider } from '../components/ThemeProvider';
import { Alert, HStack, Divider, VStack, Skeleton, Box, NativeBaseProvider, FlatList, Image } from 'native-base';
import { AccountContext } from '../services/account/account.context';
//Screens



//image upload things

import { UploadImageContext } from '../services/firebase-storage/imageUpload.context';
const Home = () => {
    const { logout } = useContext(AuthContext);
    const { addMemberToFamily, members } = useContext(AccountContext);
    //console.log("am in home", members);
    members.forEach(element => {
        console.log(element)
    });
    //Prototype
    //addMemberToFamily=(memberName, memberEmail, memberPassword, memberRole);
    return (
        <AppThemeProvider>
            <View>
                <Text>Admin home screen</Text>
                <Button title='add family member' onPress={() => {
                    addMemberToFamily("quaid ali", "efamily5@gmail.com", "password", "member");
                }} />
                <Button title='logout' onPress={() => { logout() }} />

            </View>
            <HStack
                space={22}
                alignItems="center"
                m={4}
                p={2}
                // rounded="md"
                _light={{
                    bg: 'error.100',
                }}
                _dark={{
                    bg: 'error.400',
                }}
                w="90%"
            >
                <Box
                    // rounded="full"
                    rounded={2}
                    _light={{
                        bg: 'error.500',
                    }}
                    _dark={{
                        bg: 'error.200',
                    }}
                    size="50px"
                />
                <VStack space={1} flex={1}>
                    <Box
                        _light={{
                            bg: 'red.400',
                        }}
                        _dark={{
                            bg: 'gray.100',
                        }}
                        // rounded="sm"
                        h="11px"
                        w="50%"
                    />
                    <Box
                        _light={{
                            bg: 'red.300',
                        }}
                        _dark={{
                            bg: 'gray.100',
                        }}
                        h="8px"
                        // rounded="pill"
                        w="100"
                    />
                </VStack>
            </HStack>



        </AppThemeProvider>

    )
}
const Event = () => {
    const { auth, changeUserEmail, changeUserPassword, addMemberToFamily, members, checkAdminCount } = useContext(AccountContext);
    const {
        uploading,
        setUploading,
        progress,
        setProgress,
        uploadSucess,
        setUploadSuccess,
        uploadError,
        setUploadError,
        selectImage,
        uploadInFirebaseStorage
    } = useContext(UploadImageContext);


    //console.log("Iam in event", members);
    //start code of image uplaod
    const [image, setImage] = useState(null);
    const [profileDownloadedUri, setProfileDownlaodedUri] = useState(null);

    const handleSelectImage = async () => {
        const uri = await selectImage()
        setImage(uri);
    }

    const handleUpload = async (image) => {
        const uri = await uploadInFirebaseStorage(image);
        if (uri) {
            setProfileDownlaodedUri(uri);
            setUploadError(null);
        }

    }
    const AddData = () => {
        setUploadError(null);
        setUploadSuccess(null);
        setProgress(null);
    }


    return (

        <View>
            <Button title='upload profile photo' onPress={() => { handleSelectImage() }} />
            {image && (
                <View>
                    <Image source={{ uri: image }}
                        alt={"logo"} width={200} height={200} alignContent={"center"} justifyContent={"center"}
                        borderRadius={7} margin={5} padding={5} />
                    <TouchableOpacity onPress={() => { setImage(null) }}><Text>Remove</Text></TouchableOpacity>
                    <Button title='upload' onPress={() => { handleUpload(image) }} />
                </View>
            )}
            {uploading && (<Text>{progress}%</Text>)}
            {uploadError && (<Text>{uploadError}</Text>)}
            {uploadSucess && (<Text>{uploadSucess}</Text>)}
            <Button title='submit' onPress={() => {
                AddData();
            }} />
            {/* PROTOTYPE (FAMILYID,USERID,NEWROLE) */}
            <Button title='assign roles' onPress={() => {
                checkAdminCount("KMGA5QtDWyHF0RRtYeB3", "UpEo1Cg7MbeBPX0YT1mw4wmwhKj1", "member");
            }} />
        </View>

    )







    /*
        // return <Button title='change email' onPress={() => {
        //     changeUserEmail("1234567", "efamily@gmail.com");
        // }} />
    
    
        // return <Button title='change password' onPress={() => {
        //     changeUserPassword("123456", "1234567");
        // }} />
    
    
        // return <Button title='add family member' onPress={() => {
        //     addMemberToFamily("quaid ali", "efamily6@gmail.com", "password", "member");
        // }} />
    
       */
}










const Task = () => { return <Text>Admin Task Screen</Text> }

//Screen Stacks
//family stack
import AddMember from '../features/administration/account-management/add-member.screen';
import { setUserId, setUserProperties } from 'firebase/analytics';




export const AdminFamilyStack = () => {
    const Stack = createNativeStackNavigator();
    return (
        <Stack.Navigator screenOptions={{ headerShown: false }}>
            <Stack.Screen name="Home" component={Home} />
        </Stack.Navigator>
    )
}

export const AdminEventStack = () => {
    const Stack = createNativeStackNavigator();
    return (
        <Stack.Navigator screenOptions={{ headerShown: false }}>
            <Stack.Screen name="Event" component={Event} />

        </Stack.Navigator>
    )

}


export const AdminTaskStack = () => {
    const Stack = createNativeStackNavigator();
    return (
        <Stack.Navigator screenOptions={{ headerShown: false }}>
            <Stack.Screen name="Task" component={Task} />
        </Stack.Navigator>
    )

}
