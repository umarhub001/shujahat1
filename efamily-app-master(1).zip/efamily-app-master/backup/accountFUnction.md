import { View, Text, Button, } from 'react-native'
import React, { useContext, useEffect, useState } from 'react'
import { createNativeStackNavigator } from '@react-navigation/native-stack';

import AuthContext from '../services/account/auth.context';
import { AppThemeProvider } from '../components/ThemeProvider';
import { Alert, HStack, Divider, VStack, Skeleton, Box, NativeBaseProvider } from 'native-base';
//Screens



//testing modee
import { auth, db } from '../../firebase';
import { createUserWithEmailAndPassword, deleteUser, signInWithCredential, signInWithEmailAndPassword, updateCurrentUser } from "firebase/auth";
import { getFirestore, doc, getDoc, setDoc, collection, updateDoc, arrayUnion, deleteDoc, query, where, getDocs } from "firebase/firestore";
import { AccountContext } from '../services/account/account.context';
const Home = () => {
    const { logout, user } = useContext(AuthContext);
    const [familyId, setFamilyId] = useState();
    // const adminId = user.uid;
    const adminId = 0;
    const familyName = "Efamily";
    async function createFamily(name, adminId) {
        const familyRef = doc(collection(db, "families"));
        const newFamily = {
            name: name,
            members: [adminId]
        };
        await setDoc(familyRef, newFamily);
        setFamilyId(familyRef.id);
    }

    async function addMemberToFamily(memberName, memberEmail, role) {
        try {
            console.log("is loading");
            const currentUserId = user.userId;
            console.log("current user id in the session", currentUserId);
            // console.log("current user", auth.currentUser.uid);
            const currentFamily = await getDoc(doc(db, "users", currentUserId));
            console.log("current family", currentFamily);
            const currentFamilyId = currentFamily.get("familyId");
            console.log("current family id", currentFamilyId);
            if (currentFamilyId) {
                const userCredential = await createUserWithEmailAndPassword(
                    auth,
                    memberEmail,
                    "password"
                );
                const memberId = userCredential.user.uid;
                console.log("id changed to memeber", memberId);
                const familyRef = doc(db, "families", currentFamilyId);
                await updateDoc(familyRef, { members: arrayUnion(memberId) });
                console.log("member added in family");
                const userRef = doc(collection(db, "users"), memberId);
                await setDoc(userRef, {
                    name: memberName,
                    email: memberEmail,
                    role: role,
                    familyId: currentFamilyId,
                });
                await signInWithEmailAndPassword(auth, user.email, user.password).then(() => {
                    console.log("after", auth.currentUser);
                }).catch((err) => {
                    console.log(err)
                });

                console.log("user added in user doc");
                console.log("loading complite");
            }
        } catch (error) {
            console.log("catch error", error);
            // if (memberId) {
            //     await deleteUser(memberId);
            // }
        }
    }

    async function deleteMemberAll(memberId) {
        try {
            // Delete user from Firebase Authentication

            /*    console.log("Member deleted from Authentication");
    
                // Remove member's information from Firestore
                const userRef = doc(collection(db, "users"), memberId);
                await deleteDoc(userRef);
                console.log("Member's document deleted from Firestore");
    
                // Remove member's ID from family members array
                const currentUserId = auth.currentUser.uid;
                const currentFamily = await getDoc(doc(db, "users", currentUserId));
                const currentFamilyId = currentFamily.get("familyId");
                const familyRef = doc(db, "families", currentFamilyId);
                await updateDoc(familyRef, { members: arrayRemove(memberId) });
                console.log("Member's ID removed from family members array");
    
                */
        } catch (error) {
            console.log("Error deleting member", error);
        }
    }

    const deleteMember = async (user) => {
        console.log(user);
        auth.currentUser
            .delete()
            .then(() => console.log("User deleted"))
            .catch((error) => console.log(error));
    }


    async function deleteMemberFromFamily(memberId) {
        try {
            const currentUserId = auth.currentUser.uid;
            const currentFamily = await getDoc(doc(db, "users", currentUserId));
            const currentFamilyId = currentFamily.get("familyId");
            if (currentFamilyId) {
                const familyRef = doc(db, "families", currentFamilyId);
                await updateDoc(familyRef, { members: arrayRemove(memberId) });
                console.log("member removed from family");
                const userRef = doc(db, "users", memberId);
                await deleteDoc(userRef);
                console.log("user document deleted");
            }
        } catch (error) {
            console.log("catch error", error);
        }
    }


    async function getFamilyMembers() {
        try {
            console.log("is loading");
            const currentUserId = user.userId;
            console.log("current user id in the session", currentUserId);
            const currentFamily = await getDoc(doc(db, "users", currentUserId));
            console.log("current family", currentFamily);
            const familyId = currentFamily.get("familyId");
            console.log("current family id", familyId);
            const familyRef = doc(db, "families", familyId);
            const familySnapshot = await getDoc(familyRef);
            const memberIds = familySnapshot.get("members");
            const memberPromises = memberIds.map(async (memberId) => {
                const memberRef = doc(db, "users", memberId);
                const memberSnapshot = await getDoc(memberRef);
                return {
                    id: memberId,
                    name: memberSnapshot.get("name"),
                    email: memberSnapshot.get("email"),
                    role: memberSnapshot.get("role"),
                };
            });
            const members = await Promise.all(memberPromises);
            console.log(members)
            //member is a object
            members.forEach((item) => {
                console.log(item.id, item.name, item.role);
            })
            console.log("loading complete");
        } catch (error) {

            console.log("Error retrieving family members", error.message);
        }
    }



    return (
        <AppThemeProvider>
            <View>
                <Text>Admin home screen</Text>
                {/* <Text>{user.email}</Text> */}
                <Button title='logout' onPress={() => { logout() }} />
                <Button title="create family" onPress={() => {
                    createFamily(familyName, adminId)
                }} />
                <Button title="Add members" onPress={() => {
                    addMemberToFamily("Quaid", "efamily4@gmail.com", "member");
                }} />
                <Button
                    title='delete member'
                    onPress={() => {
                        deleteMember('WFxtRsEAKVaxpJk7yXilGox9zX63')
                    }}
                />

                <Button
                    title='get Members of family'
                    onPress={() => {
                        getFamilyMembers()
                    }}
                />
            </View>
        </AppThemeProvider>

    )
}


//end of testing mode










// const Home = () => {
//     const { logout } = useContext(AuthContext);

//     return (
//         <AppThemeProvider>
//             <View>
//                 <Text>Admin home screen</Text>
//                 <Button title='logout' onPress={() => { logout() }} />
//             </View>
//             <HStack
//                 space={22}
//                 alignItems="center"
//                 m={4}
//                 p={2}
//                 // rounded="md"
//                 _light={{
//                     bg: 'error.100',
//                 }}
//                 _dark={{
//                     bg: 'error.400',
//                 }}
//                 w="90%"
//             >
//                 <Box
//                     // rounded="full"
//                     rounded={2}
//                     _light={{
//                         bg: 'error.500',
//                     }}
//                     _dark={{
//                         bg: 'error.200',
//                     }}
//                     size="50px"
//                 />
//                 <VStack space={1} flex={1}>
//                     <Box
//                         _light={{
//                             bg: 'red.400',
//                         }}
//                         _dark={{
//                             bg: 'gray.100',
//                         }}
//                         // rounded="sm"
//                         h="11px"
//                         w="50%"
//                     />
//                     <Box
//                         _light={{
//                             bg: 'red.300',
//                         }}
//                         _dark={{
//                             bg: 'gray.100',
//                         }}
//                         h="8px"
//                         // rounded="pill"
//                         w="100"
//                     />
//                 </VStack>
//             </HStack>



//         </AppThemeProvider>

//     )
// }


























const Event = () => { return <Text>Admin Event Screen</Text> }
const Task = () => { return <Text>Admin Task Screen</Text> }


//Screen Stacks


export const AdminFamilyStack = () => {
    const Stack = createNativeStackNavigator();
    return (
        <Stack.Navigator screenOptions={{ headerShown: false }}>
            <Stack.Screen name="Home" component={Home} />
        </Stack.Navigator>
    )
}

export const AdminEventStack = () => {
    const Stack = createNativeStackNavigator();
    return (
        <Stack.Navigator screenOptions={{ headerShown: false }}>
            <Stack.Screen name="Event" component={Event} />
        </Stack.Navigator>
    )

}


export const AdminTaskStack = () => {
    const Stack = createNativeStackNavigator();
    return (
        <Stack.Navigator screenOptions={{ headerShown: false }}>
            <Stack.Screen name="Task" component={Task} />
        </Stack.Navigator>
    )

}
