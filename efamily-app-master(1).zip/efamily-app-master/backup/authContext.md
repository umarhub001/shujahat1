version 1
import React, { createContext, useState, useEffect, useMemo } from "react";

import { getAuth, createUserWithEmailAndPassword, signInWithEmailAndPassword, onAuthStateChanged, signOut } from 'firebase/auth';
import { getFirestore, doc, setDoc, getDoc } from 'firebase/firestore';
import { db, auth } from "../../../firebase";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { useNavigation } from '@react-navigation/native'


export const AuthContext = createContext();


export const AuthContextProvider = ({ children }) => {
    const [user, setUser] = useState([]);
    const [error, setError] = useState(null);
    const [isLoading, setIsLoading] = useState(false);
    const [isStateLoading, setStateLoading] = useState(false);
    const [isAuthenticated, setIsAuthenticated] = useState(false);
    const [isAdmin, setIsAdmin] = useState(false)

    useEffect(() => {
        const getAdminStatus = async () => {
            const newIsAdmin = await AsyncStorage.getItem('isAdmin');
            const currentIsAdmin = isAdmin;
            if (newIsAdmin === 'true' && currentIsAdmin !== true) {
                setIsAdmin(true);
            } else if (newIsAdmin === 'false' && currentIsAdmin !== false) {
                setIsAdmin(false);
            }
        }

        getAdminStatus();
    }, [isAdmin])

    /*
        onAuthStateChanged(auth, (usr) => {
            {
                if (usr) {
                    console.log("yes loading start");
                    setUser(usr);
                    setIsAuthenticated(true);
                }
            }
        })
    
    
    */

    const checkAuthStatus = () => {
        onAuthStateChanged(auth, (usr) => {
            {
                if (usr) {
                    console.log("yes loading start");
                    setUser(usr);
                    setIsAuthenticated(true);
                }
            }
        })
    }
    useEffect(() => {
        checkAuthStatus();
    }, [])




    const handleStatus = async (status) => {

        await AsyncStorage.setItem('isAdmin', status === 'admin' ? 'true' : 'false');

        const result = await AsyncStorage.getItem('isAdmin');
        if (result === 'true') {
            setIsAdmin(true);
        }
        setStateLoading(true);
        setTimeout(() => {
            setStateLoading(false)
        }, 2000);

    }


    /*
        const signUp = (email, password) => {
            setIsLoading(true);
            const flag = false;
            createUserWithEmailAndPassword(auth, email, password)
                .then((userCredential) => {
                    // Set user document in firestore
                    return setDoc(doc(db, 'users', userCredential.user.uid), {
                        email: email,
                        role: 'admin', // Set default role to 'admin'
                    });
                })
                // .then(() => {
                //     flag = true;
                //     console.log(user.role);
                //     // setIsLoading(false);
                //     // signIn(email, password);
                // })
                .catch((error) => {
                    setIsLoading(false);
                    setError(error.code);
                });
    
        }*/



    const signUpWithPromise = (email, password) => {
        return new Promise((resolve, reject) => {
            setIsLoading(true);
            createUserWithEmailAndPassword(auth, email, password)
                .then((userCredential) => {
                    // Set user document in firestore
                    return setDoc(doc(db, 'users', userCredential.user.uid), {
                        email: email,
                        role: 'admin', // Set default role to 'admin'
                    })
                        .then(() => {
                            setIsLoading(false);
                            resolve('Promise resolved');
                        })
                        .catch((error) => {
                            setIsLoading(false);
                            reject(error);
                        });
                })
                .catch((error) => {
                    setIsLoading(false);
                    reject(error);
                });
        });
    };

    const signUp = (email, password) => {
        // Example usage
        signUpWithPromise(email, password)
            .then((result) => {
                console.log(result); // Promise resolved
                handleStatus("admin");
                setIsAuthenticated(true);
            })
            .catch((error) => {
                console.error(error.code);
            });
    }

    const signIn = (email, password) => {
        setIsLoading(true);
        signInWithEmailAndPassword(auth, email, password)
            .then((userCredential) => {
                return getDoc(doc(db, 'users', userCredential.user.uid));
            })
            .then((userDoc) => {
                setStateLoading(true);
                const userData = userDoc.data();
                //  console.log(userData);
                // Check if user is an admin and set isAdmin status accordingly
                handleStatus(userData.role);
                //   console.log("user status", userData.role);
                setTimeout(() => {
                    setIsAuthenticated(true);
                    setIsLoading(false);
                }, 1000);
            })
            .catch((error) => {
                console.error('Error:', error.code);
                setError(error.code);
                setIsLoading(false);
            });
    }


    const logout = () => {
        setIsLoading(true);
        signOut(auth).then(() => {
            // Sign-out successful.
            //   setUser(null);
            setIsAuthenticated(false);
            handleStatus("false");
            setIsAdmin(false);
            setIsLoading(false);
            console.log(" user logout");
        }).catch((error) => {
            setIsLoading(false);
            console.log("cannot logout");
            // An error happened.
        });

    }


    return (
        <AuthContext.Provider
            value={{
                user,
                error,
                isLoading,
                isStateLoading,
                isAuthenticated,
                isAdmin,
                signIn,
                signUp,
                logout,
                checkAuthStatus,
            }}>
            {children}
        </AuthContext.Provider>
    )
}


export default AuthContext;