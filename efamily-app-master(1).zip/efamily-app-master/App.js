import { NativeBaseProvider, Box, StatusBar } from "native-base";
import React, { useEffect, useState } from "react";
import { View, Text, Platform, SafeAreaView, LogBox } from "react-native";
//context api
import { AuthContextProvider } from "./src/services/account/auth.context";
import Navigations from "./src/navigations";
import { AppThemeProvider } from "./src/components/ThemeProvider";
import { ActivityIndicator } from "react-native-paper";
export default function App() {
    useEffect(() => {
        LogBox.ignoreAllLogs(true);
    });
    const isAndroid = Platform.OS == "android";
    const [isLoading, setIsLoading] = useState(true);

    useEffect(() => {
        setTimeout(() => {
            setIsLoading(false);
        }, 1000);
    }, []);

    if (isLoading) {
        return (
            <NativeBaseProvider>
                <AppThemeProvider>
                    <View style={{ flex: 1, justifyContent: "center", alignItems: "center" }}>
                        <ActivityIndicator size="large" color="orange" />
                    </View>
                </AppThemeProvider>
            </NativeBaseProvider>
        );
    }


    return (
        <NativeBaseProvider>
            <Box flex={1} safeArea >
                <AuthContextProvider>
                    <Navigations />
                    <StatusBar backgroundColor="#1c1c1c" />
                </AuthContextProvider>
            </Box>
        </NativeBaseProvider >
    );


}
