import React, { createContext, useContext, useEffect, useState } from 'react'
import { doc, getDoc, setDoc, addDoc, onSnapshot, collection, updateDoc, arrayUnion, deleteDoc, query, where, getDocs } from "firebase/firestore";
import { auth, db } from '../../../firebase';
import AsyncStorage from '@react-native-async-storage/async-storage'

export const WeeklyMenuContext = createContext();
export const WeeklyMenuContextProvider = ({ children }) => {


    const [success, setSuccess] = useState("done");
    const [preferences, setPreferences] = useState([])
    const [meals, setMeals] = useState([])

    const [weeklyMenu, setWeeklyMenu] = useState([]);

    const getPreferencesRealTime = async () => {
        try {

            const jsonCredentials = await AsyncStorage.getItem('credentials');
            if (jsonCredentials) {
                const credentials = JSON.parse(jsonCredentials)
                const currentUser = await getDoc(doc(db, "users", credentials.userId));
                const familyId = currentUser.get("familyId");
                const Preferencesquery = query(collection(db, "families", familyId, "prefrences"));
                const unsubscribe = onSnapshot(Preferencesquery, (querySnapshot) => {
                    const newPreferences = querySnapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() }));
                    setPreferences(newPreferences);

                });

                return unsubscribe;
            }
        } catch (error) {
            console.log(error);
        }
    }


    useEffect(() => {
        const unsubscribe = getPreferencesRealTime();
        return () => unsubscribe;
    }, [])

    useEffect(() => {
        const unsubscribe = getWeekMenuData();
        return () => unsubscribe;
    }, [])




    const addPreference = async (mealType, mealName, mealImage) => {
        try {
            const jsonCredentials = await AsyncStorage.getItem('credentials');
            if (jsonCredentials) {
                const credentials = JSON.parse(jsonCredentials)
                const currentFamily = await getDoc(doc(db, "users", credentials.userId));
                const familyId = currentFamily.get("familyId");
                await addDoc(collection(db, `families/${familyId}/prefrences`),
                    {
                        name: mealName,
                        type: mealType,
                        image: mealImage,
                    }
                );
                console.log("prefrences added");
                return "prefrence added";
            }

        } catch (error) {
            console.log(error);
            return error.message;
        }
    }








    const setMealPreference = async (day, mealType, preference) => {
        try {

            //console.log("in setMealPreference method of Menu context");
            const userId = auth.currentUser.uid;
            //console.log("current user id", userId);
            const currentFamily = await getDoc(doc(db, "users", userId));
            const familyId = currentFamily.get("familyId");
            const userName = currentFamily.get("name");

            const menuDocRef = doc(db, `families/${familyId}/weeklyMenu/${day}`);
            const menuDocSnapshot = await getDoc(menuDocRef);

            if (menuDocSnapshot.exists()) {
                const updatedMenu = { ...menuDocSnapshot.data() };
                updatedMenu[mealType] = preference;
                await setDoc(menuDocRef, updatedMenu);
                const userPrefRef = doc(db, `families/${familyId}/users/${userId}/preferences/${day}`);
                await setDoc(userPrefRef, { mealType, preference });
                //console.log("prefrence is added ");
            }
        } catch (error) {
            //console.log(error)
        }
    }



    const addDailyMenuData = async (day, breakfastData, lunchData, dinnerData) => {
        try {

            const jsonCredentials = await AsyncStorage.getItem('credentials');
            if (jsonCredentials) {
                const credentials = JSON.parse(jsonCredentials)
                const currentFamily = await getDoc(doc(db, "users", credentials.userId));
                const familyId = currentFamily.get("familyId");
                const dailyMenuRef = doc(collection(db, `families/${familyId}/menu`), day);
                await setDoc(dailyMenuRef, {
                    breakfast: breakfastData,
                    lunch: lunchData,
                    dinner: dinnerData,
                });

                console.log(`Data added for ${day}`);
                return `Menu created for ${day}`
            }

        } catch (error) {
            console.error('Error adding daily menu data:', error);
            return error.message;
        }

        /*prototype
        addDailyMenuData(
            'Monday',
            {
              name: 'Omelette',
              description: 'A fluffy omelette filled with cheese, tomatoes, and spinach',
              extra:"eggs,bread",
              image:"img.url"
            },
            {
              name: 'Turkey sandwich',
              description: 'A classic turkey sandwich with lettuce, tomato, and mayo',
              extra:"eggs,bread",
              image:"img.url"
            },
            {
              name: 'Spaghetti Bolognese',
              description: 'A hearty spaghetti dish with a rich tomato-based sauce',
              extra:"eggs,bread",
              image:"img.url"
            }
            same for 7 days
          );
          */

    };

    const getWeekMenuData = async () => {
        try {
            const jsonCredentials = await AsyncStorage.getItem('credentials');
            if (jsonCredentials) {
                const credentials = JSON.parse(jsonCredentials);
                const currentFamily = await getDoc(doc(db, "users", credentials.userId));
                const familyId = currentFamily.get("familyId");
                const menuQuery = query(collection(db, "families", familyId, "menu"));
                // Listen to changes in the menu collection
                const unsubscribe = onSnapshot(menuQuery, (querySnapshot) => {
                    const weekMenuData = {};
                    querySnapshot.forEach((doc) => {
                        weekMenuData[doc.id] = doc.data();
                    });
                    setWeeklyMenu(weekMenuData);
                    // console.log('Week Menu Data:', weekMenuData);
                });

                // Return an unsubscribe function to stop listening to changes
                return unsubscribe;
            }
        } catch (error) {
            console.error('Error getting week menu data:', error);
            return error.message;
        }
    };




    return (
        <WeeklyMenuContext.Provider
            value={{
                success,
                preferences,
                meals,
                weeklyMenu,
                addPreference,
                setMealPreference,
                addDailyMenuData,
            }}
        >
            {children}
        </WeeklyMenuContext.Provider>
    )
}