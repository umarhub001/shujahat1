
import React, { createContext, useState, useEffect, useContext } from "react";
import { createUserWithEmailAndPassword, deleteUser, EmailAuthCredential, EmailAuthProvider, onAuthStateChanged, reauthenticateWithCredential, signInWithCredential, signInWithEmailAndPassword, updateCurrentUser, updateEmail, updatePassword } from "firebase/auth";
import { doc, getDoc, setDoc, onSnapshot, collection, updateDoc, arrayUnion, deleteDoc, query, where, getDocs, arrayRemove } from "firebase/firestore";
import { auth, db } from "../../../firebase";
import AuthContext from "./auth.context";
import AsyncStorage from "@react-native-async-storage/async-storage";


export const AccountContext = createContext();
export const AccountContextProvider = ({ children }) => {
    const { user, logout, userID } = useContext(AuthContext);
    const [uid, setUid] = useState(null);
    const [members, setMembers] = useState([]);

    const [family, setFamily] = useState([]);
    const [userDetails, setUserDetails] = useState([]);
    const [userDetailId, setUserIdDetail] = useState([]);



    const getFamilyDetailsRealtime = async () => {
        try {
            const jsonCredentials = await AsyncStorage.getItem('credentials');
            if (jsonCredentials) {
                const credentials = JSON.parse(jsonCredentials);
                const currentUser = await getDoc(doc(db, "users", credentials.userId));
                const familyId = currentUser.get("familyId");
                const familyRef = doc(db, 'families', familyId);

                const unsubscribe = onSnapshot(familyRef, (doc) => {
                    // setFamily({ id: doc.id, name: doc.data().name });
                    setFamily(doc.data());
                });

                // Call the unsubscribe function when the component unmounts
                return unsubscribe;
            }
        } catch (error) {
            console.error(error);
        }
    };

    const getUserDetailsRealtime = async () => {
        try {
            const jsonCredentials = await AsyncStorage.getItem('credentials');
            if (jsonCredentials) {
                const credentials = JSON.parse(jsonCredentials);
                const userRef = doc(db, 'users', credentials.userId);
                const unsubscribe = onSnapshot(userRef, (doc) => {
                    // console.log({ id: doc.id, data: doc.data() });
                    setUserDetails(doc.data())
                    setUserIdDetail({ id: doc.id });
                    //  setUserDetails();

                });

                // Call the unsubscribe function when the component unmounts
                return unsubscribe;
            }
        } catch (error) {
            console.error(error);
        }
    };

    const getFamilyMembersRealtime = async () => {
        try {
            const jsonCredentials = await AsyncStorage.getItem('credentials');
            if (jsonCredentials) {
                const credentials = JSON.parse(jsonCredentials);
                const currentUser = await getDoc(doc(db, "users", credentials.userId));
                const familyId = currentUser.get("familyId");
                const membersQuery = query(collection(db, 'users'), where('familyId', '==', familyId));
                const unsubscribe = onSnapshot(membersQuery, (querySnapshot) => {
                    const newMembers = querySnapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() }));
                    setMembers(newMembers);
                });
                // Call the unsubscribe function when the component unmounts
                return unsubscribe;
            }
        } catch (error) {
            console.error(error);
        }
    };

    useEffect(() => {
        const unsubscribeFamily = getFamilyDetailsRealtime();
        return () => unsubscribeFamily;
    }, []);

    useEffect(() => {
        const unsubscribeUser = getUserDetailsRealtime();
        return () => unsubscribeUser;
    }, []);


    useEffect(() => {
        const unsubscribeMembers = getFamilyMembersRealtime();
        return () => unsubscribeMembers;
    }, []);



    const addMemberToFamily = async (memberName, memberEmail, memberPassword, memberRole) => {
        try {
            const jsonCredentials = await AsyncStorage.getItem('credentials');
            if (jsonCredentials) {
                const credentials = JSON.parse(jsonCredentials)
                const currentUserId = credentials.userId;
                const currentFamily = await getDoc(doc(db, "users", currentUserId));
                const currentFamilyId = currentFamily.get("familyId");
                const userCredential = await createUserWithEmailAndPassword(auth, memberEmail, memberPassword);
                const memberId = userCredential.user.uid;
                const familyRef = doc(db, "families", currentFamilyId);
                await updateDoc(familyRef, { members: arrayUnion(memberId) });
                const userRef = doc(collection(db, "users"), memberId);
                await setDoc(userRef, {
                    name: memberName,
                    email: memberEmail,
                    role: memberRole,
                    familyId: currentFamilyId,
                });
                await signInWithEmailAndPassword(auth, credentials.email, credentials.password);
                console.log("user added in user doc");
                return "Member added";
            }
        } catch (error) {
            console.log("catch error", error);
            return error.message;
        }
    }

    const deleteAccount = async (role, familyId, email, password) => {
        try {
            await signInWithEmailAndPassword(auth, email, password);
            if (role === "admin") {
                const usersSnapshot = await getDocs(query(collection(db, "users"), where("familyId", "==", familyId)));
                if (usersSnapshot.size === 1) {
                    console.log("Success! Account is deleted");
                    const currentUserId = auth.currentUser.uid;
                    await deleteDoc(doc(db, "users", currentUserId));
                    await updateDoc(doc(db, "families", familyId), {
                        members: arrayRemove(currentUserId),
                    });
                    await auth.currentUser.delete();
                    await logout();
                    return "Account Deleted";
                }
                const adminsSnapshot = await getDocs(
                    query(
                        collection(db, "users"),
                        where("familyId", "==", familyId),
                        where("role", "==", "admin")
                    ));

                if (adminsSnapshot.size > 1) {
                    const currentUserId = auth.currentUser.uid;

                    await deleteDoc(doc(db, "users", currentUserId));
                    await updateDoc(doc(db, "families", familyId), { members: arrayRemove(currentUserId), });
                    await auth.currentUser.delete();
                    await logout();
                    return "Account Deleted";
                }

                return "This family contains members and at least one admin is required";
            }
        } catch (error) {
            console.log(error.message);
            return error.message;
        }
    };

    const deleteMemberFromFamily = async (memberId) => {
        try {
            const jsonCredentials = await AsyncStorage.getItem('credentials');
            if (jsonCredentials) {
                const credentials = JSON.parse(jsonCredentials)
                const currentUserId = credentials.userId;
                const currentFamily = await getDoc(doc(db, "users", currentUserId));
                const currentFamilyId = currentFamily.get("familyId");
                const familyRef = doc(db, "families", currentFamilyId);
                await updateDoc(familyRef, { members: arrayRemove(memberId) });
                const userRef = doc(db, "users", memberId);
                await deleteDoc(userRef);
                console.log("user  deleted");
                return "user deleted";
            }
        } catch (error) {
            console.log("catch error", error);
            return "Cannot deleted";
        }
    }

    const updateName = async (name) => {
        try {

            const jsonCredentials = await AsyncStorage.getItem('credentials');
            if (jsonCredentials) {

                const credentials = JSON.parse(jsonCredentials)
                const currentUserId = credentials.userId;
                const userRef = doc(db, "users", currentUserId);
                await updateDoc(userRef, {
                    name: name,
                });
                return "Updated Successfully";
            }
        } catch (error) {
            //console.log("Error updating member details:", error);
            return error.message;
        }
    };

    const updateFamilyName = async (name) => {
        try {
            const jsonCredentials = await AsyncStorage.getItem('credentials');
            if (jsonCredentials) {
                const credentials = JSON.parse(jsonCredentials)
                const currentUserId = credentials.userId;
                const currentFamily = await getDoc(doc(db, "users", currentUserId));
                const currentFamilyId = currentFamily.get("familyId");
                const familyRef = doc(db, "families", currentFamilyId);
                await updateDoc(familyRef, {
                    name: name,
                });
                return "Updated Successfully";
            }
        } catch (error) {
            //console.log("Error updating member details:", error);
            return error.message;
        }

    }

    const updateProfile = async (imageUri) => {
        try {

            const jsonCredentials = await AsyncStorage.getItem('credentials');
            if (jsonCredentials) {
                const credentials = JSON.parse(jsonCredentials)
                const currentUserId = credentials.userId;
                const userRef = doc(db, "users", currentUserId);

                await updateDoc(userRef, {
                    image: imageUri,
                });

                return "Updated Successfully";
            }
        } catch (error) {
            return error.message;
        }
    };

    const updateFamilyProfile = async (imageUri) => {
        try {

            const jsonCredentials = await AsyncStorage.getItem('credentials');
            if (jsonCredentials) {
                const credentials = JSON.parse(jsonCredentials)
                const currentUserId = credentials.userId;
                const currentFamily = await getDoc(doc(db, "users", currentUserId));
                const currentFamilyId = currentFamily.get("familyId");
                const familyRef = doc(db, "families", currentFamilyId);
                await updateDoc(familyRef, {
                    image: imageUri,
                });
                return "Updated Successfully";
            }
        } catch (error) {
            //console.log("Error updating member details:", error);
            return error.message;
        }
    };



    const changeUserEmail = async (currentEmail, currenPassword, newEmail) => {
        try {
            const jsonCredentials = await AsyncStorage.getItem('credentials');
            if (jsonCredentials) {
                const credentials = JSON.parse(jsonCredentials);
                const c_email = credentials.email;
                const c_password = credentials.password;
                console.log("before", credentials.userId, c_email, c_password);
                await signInWithEmailAndPassword(auth, c_email, c_password);
                const user = auth.currentUser;
                const credential = EmailAuthProvider.credential(currentEmail, currenPassword);
                await reauthenticateWithCredential(user, credential);
                await updateEmail(user, newEmail);
                const userRef = doc(db, 'users', auth.currentUser.uid);
                await updateDoc(userRef, { email: newEmail });
                const userId = auth.currentUser.uid;
                const password = currenPassword;
                const email = newEmail;
                const new_credentials = { userId, email, password };
                console.log("after", userId, email, password);
                await AsyncStorage.setItem('credentials', JSON.stringify(new_credentials));
                return "email changed";
            }
        } catch (error) {
            console.log(error);
            return error.message;
        }
    };


    const changeUserPassword = async (currentEmail, currenPassword, newPassword) => {
        try {
            const jsonCredentials = await AsyncStorage.getItem('credentials');
            if (jsonCredentials) {
                const credentials = JSON.parse(jsonCredentials);
                const c_email = credentials.email;
                const c_password = credentials.password;
                console.log("before", credentials.userId, c_email, c_password);
                await signInWithEmailAndPassword(auth, c_email, c_password);
                const user = auth.currentUser;
                const credential = EmailAuthProvider.credential(currentEmail, currenPassword);
                await reauthenticateWithCredential(user, credential);
                updatePassword(user, newPassword);
                const userId = auth.currentUser.uid;
                const password = newPassword;
                const email = currentEmail;
                const new_credentials = { userId, email, password };
                console.log("after", userId, email, password);
                await AsyncStorage.setItem('credentials', JSON.stringify(new_credentials));
                return "Password changed";
            }
        } catch (error) {
            console.log(error);
            return error.message;
        }
    };

    const assignRoles = async (familyId, memberId, oldRole, newRole) => {
        try {
            const adminQuerySnapshot = await getDocs(
                query(
                    collection(db, "users"),
                    where("familyId", "==", familyId),
                    where("role", "==", "admin")
                )
            );

            //console.log("Query docs length", adminQuerySnapshot.docs.length);
            if (newRole === "member" && adminQuerySnapshot.docs.length === 1) {
                throw new Error("There must be at least one admin in the family");
            }
            // Update member role in user document
            const userRef = doc(db, "users", memberId);
            await updateDoc(userRef, { role: newRole }).then(() => {
                if (oldRole === "admin" && newRole === "member") {
                    logout()
                }
            });
            return "Member role updated successfully";
        } catch (error) {
            //console.log("Error updating member role:", error.message);
            return error.message;
        }
    };


    return (
        <AccountContext.Provider
            value={{
                members,
                family,
                userDetails,
                userDetailId,
                uid,
                addMemberToFamily,
                updateProfile,
                updateFamilyProfile,
                changeUserPassword,
                changeUserEmail,
                assignRoles,
                deleteMemberFromFamily,
                updateName,
                deleteAccount,
                updateFamilyName,
            }}
        >
            {children}
        </AccountContext.Provider>
    )
}

