
import React, { createContext, useState, useEffect, useMemo } from "react";
import { createUserWithEmailAndPassword, signInWithEmailAndPassword, onAuthStateChanged, signOut, sendPasswordResetEmail } from 'firebase/auth';
import { doc, setDoc, getDoc, collection } from 'firebase/firestore';
import { db, auth } from "../../../firebase";
import AsyncStorage from "@react-native-async-storage/async-storage";
import * as SecureStore from 'expo-secure-store';



export const AuthContext = createContext();

export const AuthContextProvider = ({ children }) => {
    const [user, setUser] = useState(null);
    const [userID, setuId] = useState(null);
    const [error, setError] = useState(null);
    const [success, setSuccess] = useState(null);
    const [isAdmin, setIsAdmin] = useState(false)
    const [isLoading, setIsLoading] = useState(false);
    const [isStateLoading, setStateLoading] = useState(false);
    const [isAuthenticated, setIsAuthenticated] = useState(false);

    useEffect(() => {
        //console.log("Auth context running");
        const getAdminStatus = async () => {
            const newIsAdmin = await AsyncStorage.getItem('isAdmin');
            const currentIsAdmin = isAdmin;
            if (newIsAdmin === 'true' && currentIsAdmin !== true) {
                setIsAdmin(true);
            } else if (newIsAdmin === 'false' && currentIsAdmin !== false) {
                setIsAdmin(false);
            }
        }
        getAdminStatus();
    }, [isAdmin]);

    useEffect(() => {
        userCredential()
    }, [])



    useEffect(() => {

        onAuthStateChanged(auth, (usr) => {
            if (usr) {
                console.log("auth state running in Auth", usr.uid);
                setuId(usr.uid);
            }
        })
    }, [])

    const userCredential = async () => {
        const jsonCredentials = await AsyncStorage.getItem('credentials');
        if (jsonCredentials) {
            const credentials = JSON.parse(jsonCredentials);
            setUser(credentials);
            setIsAuthenticated(true);
            setIsLoading(false);
        }
        setIsLoading(false);
    }

    const handleStatus = async (userId, email, password, status) => {
        await AsyncStorage.setItem('isAdmin', status === 'admin' ? 'true' : 'false');
        //   await AsyncStorage.setItem('userId', userId);
        const credentials = { userId, email, password };
        const jsonCredentials = JSON.stringify(credentials);
        await AsyncStorage.setItem('credentials', jsonCredentials);
        const result = await AsyncStorage.getItem('isAdmin');
        if (result === 'true') {
            setIsAdmin(true);
        }
        setStateLoading(true);
        setTimeout(() => {
            setStateLoading(false)
        }, 2000);
    }

    const handleSignUpWithPromise = (name, family_name, email, password) => {
        return new Promise((resolve, reject) => {
            setIsLoading(true);
            createUserWithEmailAndPassword(auth, email, password)
                .then((userCredential) => {
                    // Set user document in firestore
                    const userRef = doc(db, 'users', userCredential.user.uid);
                    const familyRef = doc(collection(db, "families"));
                    const newFamily = {
                        name: family_name,
                        members: [userCredential.user.uid]
                    };
                    const data = {
                        name: name,
                        email: email,
                        familyName: family_name,
                        role: 'admin',
                        familyId: familyRef.id // add familyId here
                    };
                    return Promise.all([setDoc(userRef, data), setDoc(familyRef, newFamily)]);
                })
                .then(() => {
                    setIsLoading(false);
                    resolve('Promise resolved');
                })
                .catch((error) => {
                    setIsLoading(false);
                    reject(error);
                });
        });
    };

    const signUp = (name, family_name, email, password) => {
        handleSignUpWithPromise(name, family_name, email, password)
            .then((result) => {
                //console.log(result); // Promise resolved
                handleStatus(auth.currentUser.uid, email, password, "admin");
                //new change solve the session manegent problem of Async
                signInWithEmailAndPassword(auth, email, password);
                //old
                // setIsAuthenticated(true);
                setError('');
                setTimeout(() => {
                    userCredential()
                }, 2000);
            })
            .catch((error) => {
                console.error(error.code);
                setError(error.code);
            });
    }

    const signIn = (email, password) => {
        setIsLoading(true);
        signInWithEmailAndPassword(auth, email, password)
            .then((userCredential) => {
                return getDoc(doc(db, 'users', userCredential.user.uid));
            })
            .then((userDoc) => {
                setStateLoading(true);
                const userData = userDoc.data();
                const userid = userDoc.id;
                //  //console.log(userData);
                // Check if user is an admin and set isAdmin status accordingly
                handleStatus(userid, email, password, userData.role);
                userCredential()
                    .then(() => {
                        setTimeout(() => {
                            setIsAuthenticated(true);
                            setIsLoading(false);
                        }, 2000)
                    }).catch(() => {
                        setIsLoading(false);
                    });

            })
            .catch((error) => {
                console.error('Error:', error.code);
                //console.log(error.message);
                //console.log(error);
                if (error.message == "Cannot read properties of undefined (reading 'role')") {
                    setError("This account have no longer access of this family");
                } else {
                    setError(error.code);
                }
                setTimeout(() => {
                    setError(null)
                }, 3000);
                setIsLoading(false);
            });
    }

    const logout = () => {
        setIsLoading(true);
        signOut(auth).then(() => {
            // Sign-out successful.
            AsyncStorage.removeItem("isAdmin");
            AsyncStorage.removeItem("credentials");
            setUser({});
            setIsAuthenticated(false);
            setIsAdmin(false);
            setIsLoading(false);
            //console.log(" user logout");
        }).catch((error) => {
            setIsLoading(false);
            //console.log("cannot logout");
            // An error happened.
        });
    }

    const forgotPassword = async (email) => {
        try {
            sendPasswordResetEmail(auth, email)
                .then(() => {
                    // Password reset email sent!
                    // ..
                    //  setSuccess("Password Reset link is sent on Your Email");
                    //console.log("password sent");
                    alert("password reset link send")
                })
                .catch((error) => {
                    const errorCode = error.code;
                    const errorMessage = error.message;
                    alert(errorMessage)
                    //console.log(errorMessage);
                    // ..
                });
            //console.log("succeess");
        } catch (error) {
            //console.log(error);
            return error;
        }

    }


    //memo logic her
    const memoValues = useMemo(() => ({
        user,
        error,
        success,
        isLoading,
        isStateLoading,
        isAuthenticated,
        isAdmin,
        userCredential,
        handleStatus,
        signIn,
        signUp,
        logout,
        forgotPassword,
    }), [user, error, success, isLoading, isStateLoading, isAuthenticated, isAdmin,])

    return (
        <AuthContext.Provider
            value={{
                user,
                userID,
                error,
                success,
                isLoading,
                isStateLoading,
                isAuthenticated,
                isAdmin,
                userCredential,
                handleStatus,
                signIn,
                signUp,
                logout,
                forgotPassword,
            }}>
            {children}
        </AuthContext.Provider>
    )
}


export default AuthContext;