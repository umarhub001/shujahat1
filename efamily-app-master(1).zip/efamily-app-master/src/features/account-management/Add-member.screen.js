import React, { useContext, useState } from 'react';
import { Box, Stack, Heading, Icon, Text, HStack, Avatar, View, ScrollView, Center, VStack, FormControl, Input, Select, CheckIcon, Button, Spinner } from 'native-base';
import {
    MaterialCommunityIcons,
    SimpleLineIcons,
    MaterialIcons,
    Feather
} from '@expo/vector-icons';


import { AppThemeProvider } from '../../components/ThemeProvider';
import { TouchableOpacity } from 'react-native';
import { AccountContext } from '../../services/account/account.context';
const MemberDetail = () => {

    const [name, setName] = useState('');
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [role, setRole] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState(null);

    // services apis
    const { addMemberToFamily } = useContext(AccountContext)


    const handleAddMember = () => {
        const emailRegex = /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i;
        if (!email || !password || !name || !role) {
            setError("All fields are required");
            return
        }
        if (!emailRegex.test(email)) {
            setError("Invalid email");
            return;
        }
        if (password.length < 6) {
            setError("Password must be atleast 6 characters");
            return;
        }

        setIsLoading(true);
        addMemberToFamily(name, email, password, role).then((success) => {
            setName('');
            setEmail('');
            setRole('');
            alert(success);
        }).catch((error) => {
            alert(error);
        }).finally(() => {
            setPassword('');
            setError(null);
            setIsLoading(false);
        })
    }

    return (
        <AppThemeProvider>
            <View flex={1} padding={5} mt={10}>
                <HStack bg={"amber.300"} mt={1} borderRadius={15} h={20}
                    bottom={4} w="100%" px={4} alignItems="center" justifyContent="space-between">
                    <Stack>
                        <Center>
                            <Heading color={"white"} fontWeight={"bold"} fontFamily={"mono"} size="sm" >
                                Add member
                            </Heading>

                        </Center>
                    </Stack>

                    <TouchableOpacity >
                        <Icon as={<Feather name="user" />} color="white" size={25} />
                    </TouchableOpacity>
                </HStack>

                <VStack>
                    <FormControl mb="5">
                        <FormControl.Label>Member Name</FormControl.Label>
                        <Input value={name} placeholder='Name' onChangeText={(value) => {
                            setName(value)
                        }} />

                        <FormControl.Label>Member Email</FormControl.Label>
                        <Input value={email} placeholder='Email' onChangeText={(value) => {
                            setEmail(value)
                        }} />

                        <FormControl.Label>Default Password</FormControl.Label>
                        <Input value={password} placeholder='Password' type='password' onChangeText={(value) => {
                            setPassword(value);
                        }} />
                        <FormControl.Label>Select Role</FormControl.Label>
                        <Select
                            selectedValue={role}
                            mx={{ base: 0, md: 'auto' }}
                            onValueChange={(value) => setRole(value)}
                            _selectedItem={{
                                bg: 'coolGray.100',
                                endIcon: <CheckIcon size={4} />,
                            }}
                            accessibilityLabel="Select role">
                            <Select.Item label="member" value="member" />
                            <Select.Item label="admin" value="admin" />
                        </Select>
                        {error && (<Text color={"error.500"}>{error}</Text>)}
                        {isLoading ? (
                            <Button mt="2" colorScheme="indigo" disabled>
                                <Spinner color="white" size="sm" />
                            </Button>
                        ) : (
                            <Button mt="2" colorScheme="indigo" onPress={() => handleAddMember()}>
                                Add Family Member
                            </Button>
                        )}

                    </FormControl>
                </VStack>


            </View>
        </AppThemeProvider >
    );
};

export default MemberDetail;