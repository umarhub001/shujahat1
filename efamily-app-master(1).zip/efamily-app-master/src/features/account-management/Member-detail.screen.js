import React from 'react';
import { Box, Stack, Heading, Icon, Text, HStack, Avatar, View, ScrollView, Center } from 'native-base';
import {
    MaterialCommunityIcons,
    SimpleLineIcons,
    MaterialIcons,
    Feather
} from '@expo/vector-icons';
import { AppThemeProvider } from '../../components/ThemeProvider';
import { TouchableOpacity } from 'react-native';

const MemberDetail = ({ route }) => {
    const { name, email, image, role } = route.params;
    return (
        <AppThemeProvider>
            <View flex={1} padding={5} mt={10}>
                <HStack bg={"amber.300"} mt={1} borderRadius={15} h={20}
                    bottom={4} w="100%" px={4} alignItems="center" justifyContent="space-between">
                    <Stack>
                        <Center>
                            <Heading color={"white"} fontWeight={"bold"} fontFamily={"mono"} size="sm" >
                                Family member
                            </Heading>

                        </Center>
                    </Stack>

                    <TouchableOpacity >
                        <Icon as={<Feather name="user" />} color="white" size={25} />
                    </TouchableOpacity>
                </HStack>

                <Box
                    p={4}
                    shadow={3}
                    rounded={12}
                    bg={"light.100"}
                    _ios={{ shadow: 4 }}
                    _android={{ borderWidth: 1 }}
                    _light={{ borderColor: 'gray.300' }}
                    _dark={{ borderColor: 'gray.400' }}
                    w="100%">
                    <Stack space={6}>

                        <HStack justifyContent="center" alignItems="center">
                            {image ? (
                                <Avatar
                                    size={48}
                                    source={{
                                        uri: image,
                                    }}
                                />
                            ) : (
                                <Avatar
                                    size={48}
                                    source={require("../../../assets/images/user.jpg")}
                                />
                            )}


                        </HStack>

                        <HStack space={2} justifyContent={"center"}>

                            <Stack space={3}>
                                <Heading
                                    size="lg"
                                    _light={{ color: 'blueGray.700' }}
                                    _dark={{ color: 'blueGray.100' }}
                                >
                                    {name}
                                </Heading>

                            </Stack>

                        </HStack>


                        <HStack
                            justifyContent="space-between"
                            alignItems="flex-end"
                            flexShrink={1}
                        >
                            <Stack space={3}>
                                <HStack space={3} alignItems="center" flexShrink={1}>
                                    <Icon
                                        name="email"
                                        as={MaterialCommunityIcons}
                                        // color="blueGray.700"
                                        _light={{ color: 'blueGray.700' }}
                                        _dark={{ color: 'blueGray.400' }}
                                    />
                                    <Text
                                        flexShrink={1}
                                        fontWeight="medium"
                                        _light={{ color: 'blueGray.500' }}
                                        _dark={{ color: 'blueGray.200' }}
                                    >
                                        Email : {email}
                                    </Text>
                                </HStack>
                                <HStack space={3} alignItems="center">
                                    <Icon
                                        name="star"
                                        as={MaterialCommunityIcons}
                                        // color="blueGray.700"
                                        _light={{ color: 'blueGray.700' }}
                                        _dark={{ color: 'blueGray.400' }}
                                    />
                                    <Text
                                        _light={{ color: 'blueGray.500' }}
                                        _dark={{ color: 'blueGray.200' }}
                                        fontWeight="medium"
                                    >
                                        Role : {role}
                                    </Text>
                                </HStack>
                            </Stack>
                        </HStack>
                    </Stack>
                </Box>
            </View>
        </AppThemeProvider >
    );
};


export default MemberDetail;