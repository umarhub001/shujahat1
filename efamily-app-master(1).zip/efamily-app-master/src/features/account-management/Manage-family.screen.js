
import {
    Box,
    View,
    Heading,
    Text,
    Icon,
    HStack,
    Stack,
    Center,
    FormControl,
    Input,
    Divider,
    Spinner,
    Button, Accordion, ScrollView, Avatar, Progress, Image
} from 'native-base'
import React, { useState, useContext, useEffect } from 'react'
import { Feather, MaterialIcons } from '@expo/vector-icons';

import { AppThemeProvider } from '../../components/ThemeProvider'
import { TouchableOpacity } from 'react-native';
import { AccountContext } from '../../services/account/account.context'
import { UploadImageContext } from '../../services/firebase-storage/imageUpload.context';


const ManageFamily = ({ navigation }) => {
    const [name, setName] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    //context api
    const { members, family, updateFamilyName, userDetails, updateFamilyProfile } = useContext(AccountContext);
    ///Firestorage image service
    const {
        uploading,
        progress,
        setProgress,
        selectImage, setUploading,
        uploadInFirebaseStorage
    } = useContext(UploadImageContext);
    const [image, setImage] = useState(null);
    const [profileDownloadedUri, setProfileDownlaodedUri] = useState(null);





    const handleSelectImage = async () => {
        if (image) {
            setImage(null);
        } else {
            const uri = await selectImage()
            setImage(uri);
        }
    }

    const handleUpload = async (image) => {
        const uri = await uploadInFirebaseStorage(image);
        if (uri) {
            updateFamilyProfile(uri).then((success) => {
                alert(success)
                setImage(null);
                setProgress(null);
                setUploading(false);
            }).catch((error) => {
                alert(error);
                setUploading(false);
            });

        }
    }

    const handleUpdateName = async (name) => {

        if (!name) {
            alert("enter name please");
            return
        }

        if (userDetails) {
            setIsLoading(true);
            updateFamilyName(name)
                .then(
                    (success) => {
                        alert(success);
                        setIsLoading(false);
                        setName('');
                    }
                )
                .catch((error) => {
                    setIsLoading(false);
                    alert(error)
                });

        }
    }




    return (

        <AppThemeProvider>
            <ScrollView>
                <View flex={1}>
                    {image ? (
                        <>
                            <Center> <Image alt="family image" size={340} rounded={15} source={{ uri: image }} /></Center>
                        </>
                    ) : (<>
                        {family ? (
                            <>
                                {family.image ? (
                                    <Center> <Avatar size={240} source={{ uri: family.image }} /></Center>
                                ) : (

                                    <Center> <Image alt="family image" size={340} rounded={15} source={require("../../../assets/images/family.jpg")} /></Center>
                                )}
                            </>
                        ) : (<>
                        </>)}
                    </>)}
                    <Box mt={2}>
                        <HStack justifyContent="space-around">
                            <Stack>
                                {family && (
                                    <Heading mt="2" color="black" size="md">
                                        {family.name}
                                    </Heading>
                                )}

                            </Stack>
                            <HStack space={3}>


                                {image && (<TouchableOpacity onPress={() => { handleUpload(image) }}>
                                    <Icon as={<Feather name="upload" />} color="success.400" size={10} />
                                </TouchableOpacity>
                                )}

                                {family && (
                                    <TouchableOpacity onPress={() => handleSelectImage()}>
                                        {image ? (
                                            <Icon as={<Feather name="x" />} color="error.500" size={10} />
                                        ) : (
                                            <Icon as={<Feather name="camera" />} color="muted.900" size={10} />
                                        )}
                                    </TouchableOpacity>
                                )}
                            </HStack>
                        </HStack>
                        {progress && (<Stack padding={2}>
                            <Progress colorScheme={"success"} size="xl" mb="4" value={progress}>
                                <Text color="white" bold>
                                    {progress}%
                                </Text>
                            </Progress>
                        </Stack>)}

                    </Box>

                </View>

                <Box m={3}>
                    <Accordion >
                        <Accordion.Item>
                            <Accordion.Summary>
                                Edit Family Name
                                <Accordion.Icon />
                            </Accordion.Summary>
                            <Accordion.Details>
                                <Stack
                                    space={2.5}
                                    alignSelf="center"
                                    px="4"
                                    safeArea
                                    mt="4"
                                    w={{ base: '100%', md: '25%' }}>
                                    <Box>
                                        <FormControl isDisabled mb="5">
                                            <FormControl.Label
                                                _disabled={{
                                                    _text: {
                                                        color: 'gray.400',
                                                        fontWeight: 'bold',
                                                    },
                                                }}
                                            >
                                                Name
                                            </FormControl.Label>
                                            {family ? (<Input value={family.name} color={"muted.900"} _disabled={true} />) : (<Input placeholder={""} />)}
                                        </FormControl>
                                        <Divider />
                                    </Box>
                                    <Box>
                                        <FormControl mb="5">
                                            <FormControl.Label>Update family name</FormControl.Label>
                                            <Input value={name} onChangeText={(value) => {
                                                setName(value)
                                            }} />

                                        </FormControl>
                                    </Box>
                                    {isLoading ? (
                                        <Button colorScheme="indigo" disabled>
                                            <Spinner color="white" size="sm" />
                                        </Button>
                                    ) : (
                                        <Button colorScheme="indigo" onPress={() => {
                                            handleUpdateName(name);
                                        }}>
                                            <Text>Update Name</Text>
                                        </Button>
                                    )}
                                </Stack>
                            </Accordion.Details>
                        </Accordion.Item>

                        <Accordion.Item>
                            <Accordion.Summary>
                                Members
                                <Accordion.Icon />
                            </Accordion.Summary>
                            <Accordion.Details>
                                <Stack
                                    space={2.5}
                                    alignSelf="center"
                                    px="4"
                                    safeArea
                                    mt="4"
                                    w={{ base: '100%', md: '25%' }}>
                                    {members.map((member, index) => (
                                        <React.Fragment key={index}>
                                            <HStack justifyContent={"space-around"}>
                                                <Center>
                                                    <TouchableOpacity onPress={() => {
                                                        navigation.navigate("memberDetail", {
                                                            name: member.name,
                                                            email: member.email,
                                                            image: member.image,
                                                            role: member.role,
                                                        })
                                                    }}>

                                                        {/* source={require("../../../assets/images/family.jpg")} */}
                                                        {member.image ? (
                                                            <Avatar
                                                                marginLeft={3}
                                                                bg="lightBlue.400"
                                                                source={{ uri: member.image }}
                                                                size={24}
                                                            />
                                                        ) : (
                                                            <Avatar
                                                                marginLeft={3}
                                                                bg="lightBlue.400"
                                                                source={require("../../../assets/images/user.jpg")}
                                                                size={24}
                                                            />
                                                        )}

                                                    </TouchableOpacity>
                                                    <Stack flexDirection={"row"}>
                                                        <Text>{member.name}</Text>

                                                    </Stack>

                                                </Center>
                                                <Stack margin={5}>
                                                    <MaterialIcons name='edit' size={25} onPress={() => {
                                                        navigation.navigate("editMember", {
                                                            id: member.id,
                                                            familyId: member.familyId,
                                                            name: member.name,
                                                            email: member.email,
                                                            image: member.image,
                                                            role: member.role,
                                                        })
                                                    }} />
                                                </Stack>
                                            </HStack>

                                            <Divider />

                                        </React.Fragment>
                                    ))}
                                </Stack>
                            </Accordion.Details>
                        </Accordion.Item>

                    </Accordion>
                </Box>




            </ScrollView>
        </AppThemeProvider >
    )
}

export default ManageFamily

