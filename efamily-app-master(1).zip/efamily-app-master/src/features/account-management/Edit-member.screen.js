import React, { useContext, useState } from 'react';
import {
    Box, Stack, Heading, Icon, Text, HStack, Avatar, View, ScrollView, Center,
    FormControl,
    AlertDialog,
    VStack,
    Divider, Modal,
    Spinner,
    Button, Select,

} from 'native-base';
import { Menu, HamburgerIcon, Pressable } from 'native-base';

import {
    MaterialCommunityIcons,
    Feather
} from '@expo/vector-icons';
import { AppThemeProvider } from '../../components/ThemeProvider';
import { TouchableOpacity } from 'react-native';
import { AccountContext } from '../../services/account/account.context'

const EditMember = ({ navigation, route }) => {

    const { id, familyId, name, email, image, role } = route.params;
    const [isLoading, setIsLoading] = useState(false);
    const [isOpen, setIsOpen] = React.useState(false);
    const onClose = () => setIsOpen(false);
    const cancelRef = React.useRef(null);
    const [newrole, setNewRole] = useState(null);
    const [showModal, setShowModal] = useState(false);
    const { members, family, assignRoles, updateFamilyName, userDetails, updateFamilyProfile, deleteMemberFromFamily } = useContext(AccountContext);

    const handleDeleteMember = (memberEmail, memberId) => {
        if (userDetails && memberId) {
            if (userDetails.email === memberEmail) {
                console.log("Admin")
                navigation.navigate("profile");
                onClose();
                navigation.goBack();
            } else {
                setIsLoading(true);
                console.log("user")
                deleteMemberFromFamily(memberId).then((success) => {
                    setIsLoading(false);
                    onClose();
                    alert(success);
                }).catch((error) => {
                    setIsLoading(false);
                    onClose();
                    alert(error)
                });

            }
        }
    }

    const handleAssignRoles = (familyId, memberId, oldRole, newRole) => {
        if (newRole) {
            console.log(familyId, memberId, oldRole, newRole);
            setIsLoading(true);
            assignRoles(familyId, memberId, oldRole, newRole).then((success) => {
                alert(success)
                navigation.goBack();
            }).catch((error) => {
                alert(error);
            }).finally(() => {
                setIsLoading(false);
                setShowModal(false);
                setNewRole(null)
            });

        }
    }



    return (
        <AppThemeProvider>
            <View flex={1} padding={5} mt={10}>
                <HStack bg={"amber.300"} mt={1} borderRadius={15} h={20}
                    bottom={4} w="100%" px={4} alignItems="center" justifyContent="space-between">
                    <Stack>
                        <Center>
                            <Heading color={"white"} fontWeight={"bold"} fontFamily={"mono"} size="sm" >
                                Edit member
                            </Heading>

                        </Center>
                    </Stack>

                    <TouchableOpacity >
                        <Icon as={<Feather name="user" />} color="white" size={25} />
                    </TouchableOpacity>
                </HStack>

                <Box
                    p={4}
                    shadow={3}
                    rounded={12}
                    bg={"light.100"}
                    _ios={{ shadow: 4 }}
                    _android={{ borderWidth: 1 }}
                    _light={{ borderColor: 'gray.300' }}
                    _dark={{ borderColor: 'gray.400' }}
                    w="100%">
                    <Stack space={6}>
                        <Menu
                            trigger={(triggerProps) => {
                                return (
                                    <Pressable accessibilityLabel="More options menu" {...triggerProps}>
                                        <HamburgerIcon />
                                    </Pressable>
                                );
                            }}
                        >
                            <Menu.Item onPress={() => {
                                setShowModal(true)
                            }
                            } >Assign Role</Menu.Item>
                            <Menu.Item
                                onPress={() => {

                                    setIsOpen(!isOpen)
                                }
                                }
                            >Delete User</Menu.Item>
                        </Menu>
                        <HStack justifyContent="center" alignItems="center">
                            {image ? (
                                <Avatar
                                    size={48}
                                    bg="teal.500"
                                    source={{
                                        uri: image,
                                    }}
                                />
                            ) : (
                                <Avatar
                                    size={48}
                                    bg="teal.500"
                                    source={require("../../../assets/images/user.jpg")}
                                />

                            )}

                        </HStack>

                        <HStack space={2} justifyContent={"center"}>

                            <Stack space={3} >
                                <Heading
                                    size="lg"
                                    _light={{ color: 'blueGray.700' }}
                                    _dark={{ color: 'blueGray.100' }}
                                >
                                    {name}
                                </Heading>

                            </Stack>

                        </HStack>


                        <HStack
                            justifyContent="space-between"
                            alignItems="flex-end"
                            flexShrink={1}
                        >
                            <Stack space={3}>
                                <HStack space={3} alignItems="center" flexShrink={1}>
                                    <Icon
                                        name="email"
                                        as={MaterialCommunityIcons}
                                        // color="blueGray.700"
                                        _light={{ color: 'blueGray.700' }}
                                        _dark={{ color: 'blueGray.400' }}
                                    />
                                    <Text
                                        flexShrink={1}
                                        fontWeight="medium"
                                        _light={{ color: 'blueGray.500' }}
                                        _dark={{ color: 'blueGray.200' }}
                                    >
                                        Email : {email}
                                    </Text>
                                </HStack>
                                <HStack space={3} alignItems="center">
                                    <Icon
                                        name="star"
                                        as={MaterialCommunityIcons}
                                        // color="blueGray.700"
                                        _light={{ color: 'blueGray.700' }}
                                        _dark={{ color: 'blueGray.400' }}
                                    />
                                    <Text
                                        _light={{ color: 'blueGray.500' }}
                                        _dark={{ color: 'blueGray.200' }}
                                        fontWeight="medium"
                                    >
                                        Role : {role}
                                    </Text>

                                </HStack>
                            </Stack>
                        </HStack>
                    </Stack>
                </Box>
                <AlertDialog leastDestructiveRef={cancelRef} isOpen={isOpen} onClose={onClose}>
                    <AlertDialog.Content>
                        <AlertDialog.CloseButton />
                        <AlertDialog.Header>Delete Customer</AlertDialog.Header>
                        <AlertDialog.Body>
                            This will remove this user. This action cannot be
                            reversed. Deleted data can not be recovered.
                        </AlertDialog.Body>
                        <AlertDialog.Footer>
                            <Button.Group space={2}>
                                <Button variant="unstyled" colorScheme="coolGray" onPress={() => {
                                    onClose();
                                }} ref={cancelRef}>
                                    <Text>Cancel</Text>
                                </Button>

                                {isLoading ? (
                                    <Button colorScheme="danger" disabled>
                                        <Spinner color="white" size="sm" />
                                    </Button>
                                ) : (
                                    <Button colorScheme="danger" onPress={() => {

                                        handleDeleteMember(email, id);
                                    }}>
                                        <Text>Delete</Text>
                                    </Button>
                                )}
                            </Button.Group>
                        </AlertDialog.Footer>
                    </AlertDialog.Content>
                </AlertDialog>

                <Modal isOpen={showModal} onClose={() => setShowModal(false)}>
                    <Modal.Content maxWidth="400px">
                        <Modal.CloseButton />
                        <Modal.Header>{name}</Modal.Header>
                        <Modal.Body>
                            <FormControl>
                                <FormControl.Label> Assign role</FormControl.Label>

                                <VStack>
                                    <Select
                                        mx={{ base: 0, md: 'auto' }}
                                        selectedValue={newrole}
                                        onValueChange={(value) => setNewRole(value)}
                                        accessibilityLabel="Settings"
                                    >
                                        <Select.Item label="member" value='member' />
                                        <Select.Item label="admin" value='admin' />
                                    </Select>
                                </VStack>
                            </FormControl>
                        </Modal.Body>
                        <Modal.Footer>
                            <Button.Group space={2}>
                                <Button
                                    variant="ghost"
                                    colorScheme="blueGray"
                                    onPress={() => {
                                        setShowModal(false);
                                    }}
                                >
                                    Cancel
                                </Button>
                                {isLoading ? (
                                    <Button colorScheme="success" disabled>
                                        <Spinner color="white" size="sm" />
                                    </Button>
                                ) : (
                                    <Button colorScheme="success"
                                        onPress={() => {

                                            handleAssignRoles(familyId, id, role, newrole);
                                        }}
                                    >
                                        Save
                                    </Button>
                                )}



                            </Button.Group>
                        </Modal.Footer>
                    </Modal.Content>
                </Modal>
                <Divider />

            </View>
        </AppThemeProvider >
    );
};


export default EditMember;