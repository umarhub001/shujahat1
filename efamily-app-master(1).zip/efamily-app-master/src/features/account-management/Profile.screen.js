
import {
    Box, View,
    Heading,
    Image,
    Text,
    Icon,
    HStack,
    Stack,
    Center,
    FormControl,
    Input,
    WarningOutlineIcon,
    VStack,
    Divider,
    Spinner,
    Pressable, Collapse, Button, Accordion, ScrollView, Avatar, Progress, Skeleton
} from 'native-base'
import React, { useState, useContext, useEffect } from 'react'
import { Feather, AntDesign } from '@expo/vector-icons';

import { AppThemeProvider } from '../../components/ThemeProvider'
import { TouchableOpacity } from 'react-native';

import { AccountContext } from '../../services/account/account.context'
import AuthContext from '../../services/account/auth.context'
import { UploadImageContext } from '../../services/firebase-storage/imageUpload.context';


const Profile = () => {
    const [name, setName] = useState('');
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [newPassword, setNewPassword] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [isSplash, setIsSplash] = useState(true);
    const [error, setError] = useState(null);
    //context api
    const { updateName, userDetails, changeUserEmail, changeUserPassword, updateProfile, deleteAccount } = useContext(AccountContext);
    const { logout } = useContext(AuthContext);

    ///Firestorage image service
    const {
        uploading,
        progress,
        setProgress,
        selectImage, setUploading,
        uploadInFirebaseStorage
    } = useContext(UploadImageContext);
    const [image, setImage] = useState(null);

    useEffect(() => {
        setTimeout(() => {
            setIsSplash(false);
        }, 1000);
    }, [])


    const handleSelectImage = async () => {
        if (image) {
            setImage(null);
        } else {
            const uri = await selectImage()
            setImage(uri);
        }
    }

    const handleUpload = async (image) => {
        const uri = await uploadInFirebaseStorage(image);
        if (uri) {
            updateProfile(uri).then((success) => {
                alert(success)
                setImage(null);
                setProgress(null);
                setUploading(false);
            }).catch((error) => {
                alert(error);
                setUploading(false);
            });

        }
    }

    const handleUpdateName = async (name) => {

        if (!name) {
            alert("enter name please");
            return
        }

        try {
            setIsLoading(true)
            updateName(name).then((success) => {
                alert(success);
                setName('');
            });
        } catch (error) {
            alert(error);
        } finally {
            setIsLoading(false);
        }
    }
    const handleUpdateEmail = (password, email) => {
        const emailRegex = /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i;
        if (!email) {
            alert("enter email please");
            return
        }


        if (!password) {
            alert("enter password please");
            return
        }

        if (!emailRegex.test(email)) {
            alert("invalid email");
            return;
        }

        if (userDetails) {
            setIsLoading(true);
            changeUserEmail(userDetails.email, password, email).then((success) => {
                alert(success);
            }).catch((error) => {
                alert(error)
            }).finally(() => {
                setPassword('');
                setEmail('');
                setIsLoading(false);
            });
        }
    }

    const handleUpdatePassword = (currentPassword, newPassword) => {

        if (!currentPassword) {
            alert("enter current password please");
            return
        }

        if (!newPassword) {
            alert("enter new password please");
            return
        }

        if (userDetails) {
            setIsLoading(true);
            changeUserPassword(userDetails.email, currentPassword, newPassword).then((success) => {
                alert(success);
            }).catch((error) => {
                alert(error)
            }).finally(() => {
                setPassword('');
                setNewPassword('');
                setIsLoading(false);
            });
        }
    }
    const handleAccountDelete = (email, password) => {
        if (userDetails) {
            const emailRegex = /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i;
            if (!email) {
                alert("enter email please");
                return
            }


            if (!password) {
                alert("enter password please");
                return
            }

            if (!emailRegex.test(email)) {
                alert("invalid email");
                return;
            }
            setIsLoading(true);
            deleteAccount(userDetails.role, userDetails.familyId, email, password).then((success) => {
                alert(success);
                setIsLoading(false);
                //logout();
            }).catch((error) => {
                alert(error)
            }).finally(() => {
                setEmail('');
                setPassword('');
                setIsLoading(false);
            });
        }
    }

    if (isSplash) {
        return (
            <AppThemeProvider>
                <Center w="100%" mt={55}>
                    <VStack w="90%" maxW="400" borderWidth="1" space={6} rounded="md"
                        alignItems="center"
                        _dark={{ borderColor: 'coolGray.500' }}
                        _light={{ borderColor: 'coolGray.200' }}
                    >
                        <Skeleton h="40" />
                        <Skeleton
                            borderWidth={1}
                            borderColor="coolGray.200"
                            endColor="warmGray.50"
                            size="20"
                            rounded="full"
                            mt="-70"
                        />
                        <HStack space="2">
                            <Skeleton size="5" rounded="full" />
                            <Skeleton size="5" rounded="full" />
                            <Skeleton size="5" rounded="full" />
                            <Skeleton size="5" rounded="full" />
                            <Skeleton size="5" rounded="full" />
                        </HStack>
                        <Skeleton.Text lines={3} alignItems="center" px="12" />
                        <Skeleton mb="3" w="40" rounded="20" />
                    </VStack>
                </Center>
            </AppThemeProvider>
        )
    } else {
        return (
            <AppThemeProvider>
                <ScrollView>
                    <View flex={1}>
                        {image ? (
                            <Center> <Avatar size={240} source={{ uri: image }} /></Center>
                        ) : (
                            <>
                                {userDetails && (
                                    <>
                                        {userDetails.image ? (
                                            <Center> <Avatar size={240} source={{ uri: userDetails.image }} /></Center>
                                        ) : (
                                            <Center> <Avatar size={240} source={require("../../../assets/images/user.jpg")} /></Center>
                                        )}
                                    </>
                                )}
                            </>
                        )}
                        <Box mt={1}>
                            <HStack justifyContent="space-around">
                                <Stack>
                                    {userDetails && (
                                        <Heading color="black" size="md">
                                            {userDetails.name}
                                        </Heading>
                                    )}
                                    {userDetails && (<Text color="muted.900">{userDetails.role}</Text>)}
                                </Stack>

                                <HStack space={3}>
                                    {image && (<TouchableOpacity onPress={() => { handleUpload(image) }}>
                                        <Icon as={<Feather name="upload" />} color="success.400" size={10} />
                                    </TouchableOpacity>
                                    )}

                                    {userDetails && (
                                        <TouchableOpacity onPress={() => handleSelectImage()}>
                                            {image ? (
                                                <Icon as={<Feather name="x" />} color="error.500" size={10} />
                                            ) : (
                                                <Icon as={<Feather name="camera" />} color="muted.900" size={10} />
                                            )}
                                        </TouchableOpacity>
                                    )}
                                </HStack>
                            </HStack>
                            {progress && (<Stack padding={2}>
                                <Progress colorScheme={"success"} size="xl" mb="4" value={progress}>
                                    <Text color="white" bold>
                                        {progress}%
                                    </Text>
                                </Progress>
                            </Stack>)}

                        </Box>

                    </View>

                    <Box m={3}>
                        <Accordion >
                            <Accordion.Item>
                                <Accordion.Summary>
                                    Edit Name
                                    <Accordion.Icon />
                                </Accordion.Summary>
                                <Accordion.Details>
                                    <Stack
                                        space={2.5}
                                        alignSelf="center"
                                        px="4"
                                        safeArea
                                        mt="4"
                                        w={{ base: '100%', md: '25%' }}>
                                        <Box>
                                            <FormControl isDisabled mb="5">
                                                <FormControl.Label
                                                    _disabled={{
                                                        _text: {
                                                            color: 'gray.400',
                                                            fontWeight: 'bold',
                                                        },
                                                    }}
                                                >
                                                    Name
                                                </FormControl.Label>
                                                {userDetails ? (<Input value={userDetails.name} color={"muted.900"} _disabled={true} />) : (<Input placeholder={""} />)}
                                            </FormControl>
                                            <Divider />
                                        </Box>
                                        <Box>
                                            <FormControl mb="5">
                                                <FormControl.Label>Update name</FormControl.Label>
                                                <Input value={name} onChangeText={(value) => {
                                                    setName(value)
                                                }} />

                                            </FormControl>
                                        </Box>
                                        {isLoading ? (
                                            <Button colorScheme="indigo" disabled>
                                                <Spinner color="white" size="sm" />
                                            </Button>
                                        ) : (
                                            <Button colorScheme="indigo" onPress={() => {
                                                handleUpdateName(name);
                                            }}>
                                                Update Name
                                            </Button>
                                        )}
                                    </Stack>
                                </Accordion.Details>
                            </Accordion.Item>

                            <Accordion.Item>
                                <Accordion.Summary>
                                    Change Email
                                    <Accordion.Icon />
                                </Accordion.Summary>
                                <Accordion.Details>
                                    <Stack
                                        space={2.5}
                                        alignSelf="center"
                                        px="4"
                                        safeArea
                                        mt="4"
                                        w={{ base: '100%', md: '25%' }}>
                                        <Box>
                                            <FormControl isDisabled mb="5">
                                                <FormControl.Label
                                                    _disabled={{
                                                        _text: {
                                                            color: 'gray.400',
                                                            fontWeight: 'bold',
                                                        },
                                                    }}
                                                >
                                                    Email
                                                </FormControl.Label>
                                                {userDetails ? (<Input value={userDetails.email} color={"muted.900"} _disabled={true} />) : (<Input placeholder={""} />)}
                                            </FormControl>
                                            <Divider />
                                        </Box>
                                        <Box>
                                            <Text>Update Email</Text>
                                            <FormControl mb="5">
                                                <FormControl.Label>Enter Email</FormControl.Label>
                                                <Input value={email} onChangeText={(value) => {
                                                    setEmail(value)
                                                }} />

                                                <FormControl.Label>Enter Password</FormControl.Label>
                                                <Input type="password" value={password} onChangeText={(value) => {
                                                    setPassword(value)
                                                }} />
                                                <FormControl.HelperText>
                                                    Give your project a title.
                                                </FormControl.HelperText>
                                            </FormControl>
                                        </Box>
                                        {isLoading ? (
                                            <Button colorScheme="indigo" disabled>
                                                <Spinner color="white" size="sm" />
                                            </Button>
                                        ) : (
                                            <Button colorScheme="indigo" onPress={() => {
                                                handleUpdateEmail(password, email);
                                            }}>
                                                Update Email
                                            </Button>
                                        )}
                                    </Stack>
                                </Accordion.Details>
                            </Accordion.Item>

                            <Accordion.Item>
                                <Accordion.Summary>
                                    Change Password
                                    <Accordion.Icon />
                                </Accordion.Summary>
                                <Accordion.Details>
                                    <Stack
                                        space={2.5}
                                        alignSelf="center"
                                        px="4"
                                        safeArea
                                        mt="4"
                                        w={{ base: '100%', md: '25%' }}>
                                        <Box>
                                            <Text>Change Password</Text>
                                            <FormControl mb="5">
                                                <FormControl.Label>Enter current password</FormControl.Label>
                                                <Input type="password" value={password} onChangeText={(value) => {
                                                    setPassword(value)
                                                }} />

                                                <FormControl.Label>Enter Password</FormControl.Label>
                                                <Input type="password" value={newPassword} onChangeText={(value) => {
                                                    setNewPassword(value)
                                                }} />
                                                <FormControl.HelperText>
                                                    Give your project a title.
                                                </FormControl.HelperText>
                                            </FormControl>
                                        </Box>
                                        {isLoading ? (
                                            <Button colorScheme="indigo" disabled>
                                                <Spinner color="white" size="sm" />
                                            </Button>
                                        ) : (
                                            <Button colorScheme="indigo" onPress={() => {
                                                handleUpdatePassword(password, newPassword);
                                            }}>
                                                Update Password
                                            </Button>
                                        )}
                                    </Stack>
                                </Accordion.Details>
                            </Accordion.Item>

                            <Accordion.Item>
                                <Accordion.Summary>
                                    Delete account
                                    <Accordion.Icon />
                                </Accordion.Summary>
                                <Accordion.Details>
                                    <Stack
                                        space={2.5}
                                        alignSelf="center"
                                        px="4"
                                        safeArea
                                        mt="2"
                                        w={{ base: '100%', md: '25%' }}>
                                        <Box>
                                            <Text>For Account Deletion</Text>
                                            <FormControl mb="5">
                                                <FormControl.Label>Enter Email</FormControl.Label>
                                                <Input value={email} onChangeText={(value) => {
                                                    setEmail(value)
                                                }} />

                                                <FormControl.Label>Enter Password</FormControl.Label>
                                                <Input type="password" value={password} onChangeText={(value) => {
                                                    setPassword(value)
                                                }} />
                                                <FormControl.HelperText>
                                                    Account can't recover once it's Deleted
                                                </FormControl.HelperText>
                                            </FormControl>
                                        </Box>
                                        {isLoading ? (
                                            <Button colorScheme="indigo" disabled>
                                                <Spinner color="white" size="sm" />
                                            </Button>
                                        ) : (
                                            <Button colorScheme="indigo" onPress={() => {
                                                handleAccountDelete(email, password);
                                            }}>
                                                Delete Account
                                            </Button>
                                        )}
                                    </Stack>
                                </Accordion.Details>
                            </Accordion.Item>
                        </Accordion>
                        <Stack mt={4}>
                            <Button colorScheme="indigo" onPress={() => {
                                logout()
                            }}><Text color={"white"}>Logout</Text></Button>
                        </Stack>
                    </Box>

                </ScrollView>
            </AppThemeProvider >
        )
    }
}

export default Profile