import { View, Text, Button, TextInput, Box, Avatar, Icon, Image, Heading, VStack, HStack, Center, Stack, IconButton, ScrollView } from 'native-base'
import React, { useContext, useEffect, useState } from 'react'
import { AppThemeProvider } from '../../components/ThemeProvider'


//services api
import { AccountContext } from '../../services/account/account.context'
import AuthContext from '../../services/account/auth.context'
import { TouchableOpacity } from 'react-native'
import { MaterialIcons, Feather } from '@expo/vector-icons'
const Family = ({ navigation }) => {
    const { members, userDetails, family, } = useContext(AccountContext);
    const { isAdmin } = useContext(AuthContext);


    return (
        <AppThemeProvider>
            <View flex={1} padding={1}>
                <HStack space={4} justifyContent={"space-between"} padding={4} borderRadius={20} bg={"light.100"}>
                    <Stack>
                        {userDetails && (
                            <Text fontSize={"20"} fontWeight={"bold"} fontFamily={"mono"} color={"darkBlue.700"}>
                                {userDetails.name}
                            </Text>
                        )}
                        {userDetails && (
                            <Text marginLeft={2} color={"muted.500"}>{userDetails.role}</Text>
                        )}
                    </Stack>
                    <Stack direction={"row"} space={4}>
                        {isAdmin && (
                            <IconButton onPress={() => {
                                navigation.navigate("manageFamily")
                            }} size={"sm"} variant="light" _icon={{
                                as: MaterialIcons,
                                name: "list", size: "30"
                            }} />
                        )}
                        <TouchableOpacity onPress={() => {
                            navigation.navigate("profile");
                        }}>
                            {userDetails && (
                                <>
                                    {userDetails.image ? (
                                        <Avatar size={49} source={{ uri: userDetails.image }} />
                                    ) : (
                                        <Avatar size={49} source={require("../../../assets/images/user.jpg")} />
                                    )}</>
                            )}
                        </TouchableOpacity>
                    </Stack>
                </HStack>
                <ScrollView>
                    <View padding={5} borderRadius={15} >
                        <HStack bg={"amber.300"} mt={1} borderRadius={15} h={55}
                            bottom={4} w="100%" px={4} alignItems="center" justifyContent="space-between">
                            <Stack>
                                <Center>
                                    {family && (
                                        <Heading color={"white"} fontWeight={"bold"} fontFamily={"mono"} size="sm" >
                                            {family.name}
                                        </Heading>
                                    )}
                                </Center>
                            </Stack>
                            {isAdmin ? (
                                <TouchableOpacity onPress={() => navigation.navigate("manageFamily")}>
                                    <Icon as={<Feather name="edit" />} color="white" size={25} />
                                </TouchableOpacity>
                            ) : (
                                <Icon as={<Feather name="user" />} color="white" size={25} />
                            )}
                        </HStack>
                        <Box rounded="25" shadow={4} w="100%" _ios={{ shadow: 5 }} mx={{ base: 'auto', md: 0 }}>
                            {family ? (
                                <>
                                    {family.image ? (
                                        <Image h={64} w="100%" rounded="25"
                                            source={{ uri: family.image }} alt="Family Image" />
                                    ) : (
                                        <Image h={64} w="100%" rounded="25"
                                            source={require("../../../assets/images/family.jpg")} alt="Family Image" />
                                    )}
                                </>
                            ) : (
                                <Image h={64} w="100%" rounded="25"
                                    source={require("../../../assets/images/family.jpg")} alt="Family Image" />
                            )}
                        </Box>

                    </View>

                    <View padding={3}  >

                        <HStack bg={"amber.300"} mt={1} borderRadius={15} h={9}
                            bottom={4} w="100%" rounded={8} px={4} alignItems="center" justifyContent="space-between">
                            <Stack>
                                <Center>
                                    <Heading color={"white"} fontWeight={"bold"} fontFamily={"mono"} size="sm" >
                                        Family members
                                    </Heading>

                                </Center>
                            </Stack>
                            {isAdmin ? (
                                <TouchableOpacity onPress={() => navigation.navigate("addMember")}>
                                    <Icon as={<Feather name="plus" />} color="white" size={25} />
                                </TouchableOpacity>
                            ) : (
                                <TouchableOpacity>
                                    <Icon as={<Feather name="users" />} color="white" size={25} />
                                </TouchableOpacity>
                            )}
                        </HStack>

                        <Center>
                            <ScrollView horizontal>
                                <Box bg={"light.100"} borderRadius={10} >
                                    <HStack justifyContent={"space-between"} space={3} padding={5}>
                                        {members.map((member, index) => (
                                            <TouchableOpacity key={index} onPress={() => {
                                                navigation.navigate("memberDetail", {
                                                    name: member.name,
                                                    email: member.email,
                                                    image: member.image,
                                                    role: member.role,
                                                })
                                            }}>
                                                <Center>
                                                    {member.image ? (
                                                        <Avatar size={49} source={{ uri: member.image }} />
                                                    ) : (
                                                        <Avatar size={49} source={require("../../../assets/images/user.jpg")} />
                                                    )}

                                                    <Text>{member.name}</Text>
                                                </Center>
                                            </TouchableOpacity>
                                        ))}
                                    </HStack>
                                </Box>
                            </ScrollView>
                        </Center>
                    </View>
                </ScrollView>
            </View>
        </AppThemeProvider >
    )
}

export default Family