
import React, { useContext, useEffect, useState } from 'react';
import {
    Center, Stack, HStack, Heading, Icon, View, Spacer, VStack,
    Button,
    Actionsheet,
    useDisclose,
    Text,
    Box,

    Pressable, Avatar, Select, CheckIcon, Image,
} from 'native-base'
import { SwipeListView } from 'react-native-swipe-list-view';
import { FAB } from 'react-native-paper';

import { Path } from 'react-native-svg';
import { AntDesign, Ionicons, MaterialIcons, Entypo } from '@expo/vector-icons'
import { StyleSheet, TouchableOpacity } from 'react-native'
import { AppThemeProvider } from '../../components/ThemeProvider';
import { TaskContext } from '../../services/task/task.context'
import AuthContext from '../../services/account/auth.context';
import { AccountContext } from '../../services/account/account.context';

const ViewTasks = ({ navigation }) => {

    const [filter, setFilter] = useState("")
    const { tasks, completeTask, deleteTask } = useContext(TaskContext);
    const { userDetails, userDetailId } = useContext(AccountContext);
    const { isAdmin } = useContext(AuthContext);
    const [filteredTask, setFilterTasks] = useState([]);

    useEffect(() => {
        if (isAdmin) {
            setFilter("all");
        } else {
            setFilter("myInCompletedTasks");
        }
    }, [])

    useEffect(() => {
        if (isAdmin) {
            if (filter === "all") {
                setFilterTasks(tasks);
            } else if (filter === "completed") {
                const completedTasks = tasks.filter(task => task.completed === true);
                setFilterTasks(completedTasks);//done
            } else if (filter === "inComplete") {
                const incompleteTasks = tasks.filter(task => task.completed === false);
                setFilterTasks(incompleteTasks);//done
            } else if (filter === "myCompletedTasks") {
                if (userDetailId) {
                    const currentUserTasks = tasks.filter(task => task.userId === userDetailId.id);
                    const completedTasks = currentUserTasks.filter(task => task.completed === true);
                    setFilterTasks(completedTasks);//done
                }
            } else if (filter === "myInCompletedTasks") {
                if (userDetailId) {
                    const currentUserTasks = tasks.filter(task => task.userId === userDetailId.id);
                    const incompleteTasks = currentUserTasks.filter(task => task.completed === false);
                    setFilterTasks(incompleteTasks);
                    console.log(incompleteTasks);
                }
            }

        } else {
            if (userDetailId) {
                const currentUserTasks = tasks.filter(task => task.userId === userDetailId.id);
                if (filter === "myCompletedTasks") {
                    const completedTasks = currentUserTasks.filter(task => task.completed === true);
                    setFilterTasks(completedTasks);
                } else if (filter === "myInCompletedTasks") {
                    const incompleteTasks = currentUserTasks.filter(task => task.completed === false);
                    setFilterTasks(incompleteTasks);
                }
            }
        }
    }, [tasks, filter, userDetailId])


    const deleteAction = (id) => {
        deleteTask(id).then((success) => {
            alert(success)
        });
    };
    const completeAction = (id) => {
        completeTask(id).then((success) => {
            alert(success);
        })
    }

    const TaskLabel = () => {

        if (filter == "myInCompletedTasks") {
            return <Text fontSize={11} color={"gray.600"}>My incomplete taks</Text>;
        } else if (filter == "inComplete") {
            return <Text fontSize={11} color={"gray.600"}>Incomplete tasks</Text>
        } else if (filter == "completed") {
            return <Text fontSize={11} color={"gray.600"}>Completed tasks</Text>
        } else if (filter == "all") {
            return <Text fontSize={11} color={"gray.600"}>All tasks</Text>
        } else if (filter == "myCompletedTasks") {
            return <Text fontSize={11} color={"gray.600"}>My completed tasks</Text>
        }
    }

    const renderItem = ({ item }) => {

        return (
            <Box>
                <Pressable onPress={() => navigation.navigate("taskDetail", {
                    userId: item.userId,
                    taskId: item.id,
                    name: item.name,
                    details: item.details,
                    assignedTo: item.assignedTo,
                    assignedBy: item.assignedBy,
                    rating: item.rating,
                    dueDate: item.dueDate,
                    createdAt: item.createdAt,
                    completed: item.completed,
                    completedAt: item.completedAt,
                    image: item.image,
                })}
                    _light={{ bg: 'white' }}>
                    <Box pl="4" pr="5" py="2"   >
                        <HStack alignItems="center" space={5} padding={3} bgColor={"#F6F6F7"} borderRadius={8}>

                            {item.image ? (
                                <Image size="75px" rounded={4} alt="image" source={{ uri: item.image }} />
                            ) : (
                                <Image size="75px" rounded={4} alt="image" source={require("../../../assets/images/task.jpg")} />
                            )}

                            <VStack>
                                <Text color="coolGray.600" fontWeight={"bold"}>{item.name} </Text>
                                <Text fontSize={9} color="coolGray.600">Assigned to: {item.assignedTo}</Text>
                                <Text fontSize={9} color="coolGray.600">Assigned by: {item.assignedBy}</Text>
                                {filter == "completed" ? (
                                    <>
                                        <Text fontSize={9} color="coolGray.600">Due date: {item.completedAt}</Text>
                                        {item.rating && (
                                            <Text fontSize={9} color="yellow.500">Rating: {item.rating}/5</Text>
                                        )}
                                    </>
                                ) : (
                                    <Text fontSize={9} color="coolGray.600">Due date: {item.dueDate}</Text>
                                )}
                            </VStack>
                            <Spacer />
                            <Text fontSize="xs" color="coolGray.800" alignSelf="flex-start">{item.status}</Text>
                        </HStack>
                    </Box>
                </Pressable>
            </Box>
        );
    };

    const renderHiddenItem = (data) => {
        const item = data.item;

        const Action = () => {
            if (filter === "myInCompletedTasks") {
                return (
                    <Pressable w="50" cursor="pointer" bg="#FFD54F" justifyContent="center"
                        onPress={() => { completeAction(item.id) }} _pressed={{ opacity: 0.5 }}>
                        <VStack alignItems="center" space={2}>
                            <Icon as={<AntDesign name="checkcircle" />} color="white" size="xs" />
                            <Text color="white" fontSize="xs" fontWeight="medium">Complete</Text>
                        </VStack>
                    </Pressable>
                )
            } else if (filter === "myCompletedTasks") {
                return (
                    <Pressable w="50" cursor="pointer" bg="success.400" justifyContent="center"
                        onPress={() => {

                        }} _pressed={{ opacity: 0.5 }}>
                        <VStack alignItems="center" space={2}>

                            <Icon as={<AntDesign name="check" />} color="white" size="xs" />
                            <Text color="white" fontSize="xs" fontWeight="medium">Done</Text>
                        </VStack>
                    </Pressable>

                )
            } else {
                return (
                    <Pressable w="50" cursor="pointer" bg="error.400" justifyContent="center"
                        onPress={() => { deleteAction(item.id) }} _pressed={{ opacity: 0.5 }}>
                        <VStack alignItems="center" space={2}>
                            <Icon as={<MaterialIcons name="delete" />} color="white" size="xs" />
                            <Text color="white" fontSize="xs" fontWeight="medium">Delete</Text>
                        </VStack>
                    </Pressable>
                )
            }
        }

        return (
            <HStack flex="1" pl="2" marginTop={5} marginRight={5}>
                <Pressable w="50" ml="auto" cursor="pointer" bg="coolGray.200" justifyContent="center"
                    onPress={() => navigation.navigate("taskDetail", {
                        userId: item.userId,
                        taskId: item.id,
                        name: item.name,
                        details: item.details,
                        assignedTo: item.assignedTo,
                        assignedBy: item.assignedBy,
                        rating: item.rating,
                        dueDate: item.dueDate,
                        createdAt: item.createdAt,
                        completed: item.completed,
                        completedAt: item.completedAt,
                        image: item.image,
                    })} _pressed={{ opacity: 0.5 }}>
                    <VStack alignItems="center" space={2}>
                        <Icon as={<Entypo name="eye" />} size="xs" color="coolGray.800" />
                        <Text fontSize="xs" fontWeight="medium" color="coolGray.800">View</Text>
                    </VStack>
                </Pressable>
                <Action />
            </HStack>
        );
    };

    return (
        <AppThemeProvider>

            <View flex={1} padding={1}>
                <HStack bg={"amber.300"} mt={1} borderRadius={15} h={20}
                    bottom={1} w="100%" px={4} alignItems="center" justifyContent="space-between">
                    <Stack>
                        <Center>
                            <Heading color={"white"} fontWeight={"bold"} fontFamily={"mono"} size="sm" >
                                Tasks
                            </Heading>
                        </Center>
                        <TaskLabel />
                    </Stack>

                    <Stack>
                        <HStack space={3}>
                            {isAdmin ? (
                                <Select
                                    selectedValue={filter}
                                    mx={{ base: 0, md: 'auto' }}
                                    onValueChange={(value) => setFilter(value)}
                                    _selectedItem={{ bg: 'coolGray.100', endIcon: <CheckIcon color="black" size={4} />, }}
                                    accessibilityLabel="filteredTask" >
                                    <Select.Item label="All Tasks" value="all" onPress={() => { setFilter("all") }} />
                                    <Select.Item label="Completed Tasks" value="completed" onPress={() => { setFilter("completed") }} />
                                    <Select.Item label="Not Completed Tasks" value="inComplete" onPress={() => { setFilter("inComplete") }} />
                                    <Select.Item label="My Incomplete Tasks" value="myInCompletedTasks" onPress={() => { setFilter("myInCompletedTasks") }} />
                                    <Select.Item label="My Completed Tasks" value="myCompletedTasks" onPress={() => { setFilter("myCompletedTasks") }} />


                                </Select>
                            ) : (
                                <Select
                                    selectedValue={filter}
                                    mx={{ base: 0, md: 'auto' }}
                                    onValueChange={(value) => setFilter(value)}
                                    _selectedItem={{ bg: 'coolGray.100', endIcon: <CheckIcon color="black" size={4} />, }}
                                    accessibilityLabel="Filter task">
                                    <Select.Item label="My Incomplete Tasks" value="myInCompletedTasks" onPress={() => { setFilter("myInCompletedTasks") }} />
                                    <Select.Item label="My Completed Tasks" value="myCompletedTasks" onPress={() => { setFilter("myCompletedTasks") }} />
                                </Select>
                            )}
                        </HStack>
                    </Stack>
                </HStack>
                <View flex={1}>
                    <SwipeListView data={filteredTask}
                        renderItem={renderItem}
                        renderHiddenItem={
                            (data) => renderHiddenItem(data)
                        }
                        rightOpenValue={-130}
                        previewRowKey={'0'}
                        previewOpenValue={-40}
                        previewOpenDelay={3000} />
                </View>
                {isAdmin && (
                    <FAB
                        style={styles.fab}
                        small
                        icon="plus"
                        onPress={() => navigation.navigate("assignTask")}
                    />
                )

                }


            </View>

        </AppThemeProvider>
    )
}
// padding={1} bgColor={"#F6F6F7"}



const styles = StyleSheet.create({
    fab: {
        position: 'absolute',
        margin: 16,
        right: 0,
        bottom: 0,
        borderRadius: 35,
        backgroundColor: "#FFD54F"
    },
})

export default ViewTasks
