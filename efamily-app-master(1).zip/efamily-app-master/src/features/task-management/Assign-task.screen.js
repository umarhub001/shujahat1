import React, { useContext, useState } from 'react';
import { Box, Stack, Heading, Icon, Text, HStack, Avatar, View, ScrollView, Center, VStack, FormControl, Input, Select, CheckIcon, Button, Spinner, Progress, Image } from 'native-base';
import {
    MaterialCommunityIcons,
    SimpleLineIcons,
    MaterialIcons,
    Feather
} from '@expo/vector-icons';
import DateTimePicker from '@react-native-community/datetimepicker';


//start working on next from there
import { AppThemeProvider } from '../../components/ThemeProvider';
import { TouchableOpacity } from 'react-native';
import { AccountContext } from '../../services/account/account.context';
import { UploadImageContext } from '../../services/firebase-storage/imageUpload.context';
import { TaskContext } from '../../services/task/task.context';
const AssignTask = () => {

    const [name, setName] = useState('');
    const [details, setDetails] = useState('');
    const [memberId, setMemberId] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState(null);


    //data picker api 
    const [visible, setVisible] = React.useState(false);
    const [date, setDate] = useState(new Date());



    const onChange = React.useCallback((event, selectedDate) => {
        const currentDate = selectedDate || date;
        setVisible(false);
        setDate(currentDate);
        console.log(currentDate.toLocaleString());
    }, [date]);
    const onDismiss = React.useCallback(() => {
        setVisible(false);
    }, []);

    // services apis
    const { members, userDetails } = useContext(AccountContext)
    const { assignTask } = useContext(TaskContext);

    ///Firestorage image service
    const {
        uploading,
        progress,
        setProgress,
        selectImage, setUploading,
        uploadInFirebaseStorage
    } = useContext(UploadImageContext);
    const [image, setImage] = useState(null);
    const [imageUri, setImageUri] = useState(null);

    const handleSelectImage = async () => {
        if (image) {
            setImage(null);
            setImageUri(null)
        } else {
            const uri = await selectImage()
            setImage(uri);
        }
    }

    const handleUpload = async (image) => {
        const uri = await uploadInFirebaseStorage(image);

        if (uri) {
            setImageUri(uri);
        }
    }



    const handleAssignTask = () => {
        if (!details || !name || !memberId || !date) {
            setError("All fields are required");
            return
        }
        const dueDate = date

        const options = {
            day: 'numeric',
            month: 'long',
            year: 'numeric'
        };

        const formatter = new Intl.DateTimeFormat('en-US', options);
        const DueDate = formatter.format(dueDate);
        console.log(DueDate);
        if (userDetails) {
            const assignedBy = userDetails.name;
            setIsLoading(true);
            assignTask(name, details, DueDate, memberId, imageUri, assignedBy).then((success) => {
                alert(success);
            }).catch((error) => {
                alert(error);
            }).finally(() => {
                setImageUri(null);
                setName('');
                setDetails('');
                setDate(new Date());
                setError(null);
                setError(memberId);
                setImage(null);
                setIsLoading(false);
            })

        }
    }

    return (
        <AppThemeProvider>
            <ScrollView>
                <View flex={1} padding={2} mt={5}>
                    <HStack bg={"amber.300"} mt={1} borderRadius={15} h={20}
                        bottom={4} w="100%" px={4} alignItems="center" justifyContent="space-between">
                        <Stack>
                            <Center>
                                <Heading color={"white"} fontWeight={"bold"} fontFamily={"mono"} size="sm" >
                                    Assign Task
                                </Heading>

                            </Center>
                        </Stack>

                        <TouchableOpacity >
                            <Icon as={<Feather name="plus" />} color="white" size={25} />
                        </TouchableOpacity>
                    </HStack>
                    <View >

                        {image ? (
                            <Center> <Image alt={"task image"} rounded={5} size={280} source={{ uri: image }} /></Center>
                        ) : (

                            <Center> <Image alt={"task image"} rounded={5} size={280} source={require("../../../assets/images/task.jpg")} /></Center>
                        )}
                        <Box mt={1}>
                            <HStack justifyContent="space-around">


                                <HStack space={3}>
                                    {!imageUri && (
                                        <>
                                            {image && (<TouchableOpacity onPress={() => { handleUpload(image) }}>
                                                <Icon as={<Feather name="upload" />} color="success.400" size={10} />
                                            </TouchableOpacity>
                                            )}
                                        </>
                                    )}

                                    <TouchableOpacity onPress={() => handleSelectImage()}>
                                        {image ? (
                                            <Icon as={<Feather name="x" />} color="error.500" size={10} />
                                        ) : (
                                            <Icon as={<Feather name="camera" />} color="muted.900" size={10} />
                                        )}
                                    </TouchableOpacity>

                                </HStack>
                            </HStack>
                            {progress && (<Stack padding={2}>

                                <Progress colorScheme={"success"} size="xl" mb="4" value={progress}>
                                    <Text color="white" bold>
                                        {progress}%
                                    </Text>
                                </Progress>
                            </Stack>)}

                        </Box>

                    </View>

                    <VStack padding={2}>
                        <FormControl mb="5">
                            <FormControl.Label>Task Name</FormControl.Label>
                            <Input value={name} placeholder='Name' onChangeText={(value) => {
                                setName(value)
                            }} />

                            <FormControl.Label>Task Details</FormControl.Label>
                            <Input value={details} placeholder='Details' onChangeText={(value) => {
                                setDetails(value)
                            }} />

                            <FormControl.Label>Select Member</FormControl.Label>
                            <Select minWidth="200" accessibilityLabel="Select Member" placeholder="Select Member"
                                selectedValue={memberId}
                                onValueChange={
                                    (value) => setMemberId(value)
                                }>
                                {members.map(member => (
                                    <Select.Item key={member.id} label={member.name} value={member.id} />
                                ))}
                            </Select>
                            {visible && (
                                <DateTimePicker
                                    testID="dateTimePicker"
                                    value={date}
                                    mode={'date'}
                                    display="default"
                                    onChange={onChange}
                                />
                            )}
                            <Button colorScheme="indigo" mt={2} mb={1} onPress={() => setVisible(true)}><Text color={"white"}>Pick due date</Text></Button>
                            <Input value={date.toLocaleString()} />





                            {/* {error && (<Text color={"error.500"}>{error}</Text>)} */}
                            {isLoading ? (
                                <Button mt="2" colorScheme="indigo" disabled>
                                    <Spinner color="white" size="sm" />
                                </Button>
                            ) : (
                                <Button mt="2" colorScheme="indigo" onPress={() => handleAssignTask()}>
                                    Assign Task
                                </Button>
                            )}

                        </FormControl>
                    </VStack>


                </View>
            </ScrollView>
        </AppThemeProvider >
    );
};

export default AssignTask;