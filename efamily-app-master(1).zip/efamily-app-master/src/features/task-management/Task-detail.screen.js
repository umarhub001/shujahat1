import React, { useContext, useState } from 'react';
import { Box, Stack, Heading, Icon, Text, HStack, Avatar, View, ScrollView, Center, VStack, FormControl, Input, Select, CheckIcon, Button, Spinner, Progress, Image, TextArea, Divider, Accordion } from 'native-base';
import { Feather } from '@expo/vector-icons';
import { AppThemeProvider } from '../../components/ThemeProvider';
import { StyleSheet, TouchableOpacity } from 'react-native';
import { TaskContext } from "../../services/task/task.context"
import { AuthContext } from '../../services/account/auth.context';
const TaskDetail = ({ route, navigation }) => {
    const { rateTask } = useContext(TaskContext);
    const { isAdmin } = useContext(AuthContext);
    const [isLoading, setIsLoading] = useState(false);
    // const { rateTask } = useContext(TaskContext);
    const {
        userId,
        taskId,
        name,
        details,
        image,
        assignedTo,
        assignedBy,
        rating,
        dueDate,
        createdAt,
        completed,
        completedAt } = route.params;

    const [defaultRating, setDefaultRating] = useState(0);
    // To set the max number of Stars
    const [maxRating, setMaxRating] = useState([1, 2, 3, 4, 5]);

    // Filled Star. You can also give the path from local
    const starImageFilled =
        'https://raw.githubusercontent.com/AboutReact/sampleresource/master/star_filled.png';
    // // Empty Star. You can also give the path from local
    const starImageCorner =
        'https://raw.githubusercontent.com/AboutReact/sampleresource/master/star_corner.png';
    //const starImageFilled = require('./../../../assets/images/star_filled.png');
    //const starImageCorner = require('./../../../assets/images/star_corner.png');



    const handleRating = () => {
        setIsLoading(true);
        rateTask(taskId, defaultRating).then((msg) => {
            alert(msg);
            navigation.navigate("task");
        }).catch((error) => {
            alert(error)
        }).finally(() => {
            setIsLoading(false);
        })
    }

    const CustomRatingBar = () => {
        return (
            <View style={styles.customRatingBarStyle}>
                {maxRating.map((item, key) => {
                    return (
                        <TouchableOpacity
                            activeOpacity={0.7}
                            key={item}
                            onPress={() => setDefaultRating(item)}>
                            <Image alt={"stars"}
                                style={styles.starImageStyle}
                                source={
                                    item <= defaultRating
                                        ? { uri: starImageFilled }
                                        : { uri: starImageCorner }
                                }


                            />
                        </TouchableOpacity>
                    );
                })}
            </View>
        );
    };

    return (
        <AppThemeProvider>
            <ScrollView>
                <View flex={1} padding={2} mt={5}>
                    <HStack bg={"amber.300"} mt={1} borderRadius={15} h={20}
                        bottom={4} w="100%" px={4} alignItems="center" justifyContent="space-between">
                        <Stack>
                            <Center>
                                <Heading color={"white"} fontWeight={"bold"} fontFamily={"mono"} size="sm" >
                                    Task Details
                                </Heading>

                            </Center>
                        </Stack>

                        <TouchableOpacity >
                            <Icon as={<Feather name="plus" />} color="white" size={25} />
                        </TouchableOpacity>
                    </HStack>
                    <View >

                        {image ? (
                            <Center> <Image alt={"task image"} size={250} source={{ uri: image }} /></Center>
                        ) : (
                            <Center> <Image alt={"task image"} size={250} source={{ uri: "https://randomuser.me/api/portraits/men/35.jpg" }} /></Center>
                        )}

                    </View>
                    <View margin={5} w={"90%"}>
                        <Accordion >
                            <Accordion.Item>
                                <Accordion.Summary>
                                    {name}
                                    <Accordion.Icon />
                                </Accordion.Summary>
                                <Accordion.Details>
                                    <Stack>
                                        <VStack padding={5} bgColor={"muted.50"} shadow={3} >
                                            <Text bold fontSize="sm" >Name </Text>
                                            <Text fontFamily={"mono"} fontSize={12} color={"gray.600"}>{name}</Text>
                                            <Divider />
                                            <Text bold fontSize="sm" >Details </Text>
                                            <Text fontFamily={"mono"} fontSize={12} color={"gray.600"}>{details}</Text>
                                            <Divider />
                                            <Text bold fontSize="sm" >Assigned to</Text>
                                            <Text fontFamily={"mono"} fontSize={12} color={"gray.600"}>{assignedTo}</Text>
                                            <Divider />
                                            <Text bold fontSize="sm" >Assigned By</Text>
                                            <Text fontFamily={"mono"} fontSize={12} color={"gray.600"}>{assignedBy}</Text>
                                            <Divider />
                                            <Text bold fontSize="sm" >Completed </Text>
                                            {completed ? (
                                                <Text fontFamily={"mono"} fontSize={12} color={"gray.600"}>Yes </Text>
                                            ) : (
                                                <Text fontFamily={"mono"} fontSize={12} color={"gray.600"}>No</Text>
                                            )}
                                            <Divider />
                                            <Text bold fontSize="sm" >Created At</Text>
                                            {createdAt ? (
                                                <Text fontFamily={"mono"} fontSize={12} color={"gray.600"}>{createdAt}</Text>
                                            ) : (
                                                <Text> </Text>
                                            )}
                                            <Divider />
                                            {completed && (
                                                <>
                                                    <Text bold fontSize="sm" >Completed At</Text>
                                                    {createdAt ? (
                                                        <Text fontFamily={"mono"} fontSize={12} color={"gray.600"}>{completedAt}</Text>
                                                    ) : (
                                                        <Text> </Text>
                                                    )}
                                                    <Divider />
                                                </>
                                            )}
                                            <Text bold fontSize="sm" >Due Date</Text>
                                            <Text fontFamily={"mono"} fontSize={12} color={"gray.600"}>{dueDate}</Text>
                                            <Divider />
                                            {isAdmin && (
                                                <>
                                                    {completed && (
                                                        <>
                                                            {!rating && (
                                                                <>
                                                                    <CustomRatingBar />
                                                                    <Text style={styles.textStyle}>
                                                                        {/*To show the rating selected*/}
                                                                        {defaultRating} / {Math.max.apply(null, maxRating)}
                                                                    </Text>
                                                                    {isLoading ? (
                                                                        <Button mt="2" colorScheme="indigo" disabled>
                                                                            <Spinner color="white" size="sm" />
                                                                        </Button>
                                                                    ) : (
                                                                        <Button mt="2" colorScheme="indigo" onPress={handleRating}>
                                                                            rate this task
                                                                        </Button>
                                                                    )}
                                                                    {rating && (
                                                                        <></>
                                                                    )}
                                                                </>
                                                            )}
                                                        </>
                                                    )}
                                                </>
                                            )}
                                            {rating && (
                                                <>
                                                    <Text bold fontSize="sm" >Rating</Text>
                                                    <Text fontFamily={"mono"} fontSize={12} color={"gray.600"}>{rating}/5</Text>
                                                    <Divider />
                                                </>
                                            )}
                                        </VStack>
                                    </Stack>
                                </Accordion.Details>
                            </Accordion.Item>
                        </Accordion>
                    </View>



                </View>
            </ScrollView>
        </AppThemeProvider >
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: 'white',
        padding: 10,
        justifyContent: 'center',
        textAlign: 'center',
    },
    titleText: {
        padding: 8,
        fontSize: 16,
        textAlign: 'center',
        fontWeight: 'bold',
    },
    textStyle: {
        textAlign: 'center',
        fontSize: 23,
        color: '#000',
        marginTop: 15,
    },
    textStyleSmall: {
        textAlign: 'center',
        fontSize: 16,
        color: '#000',
        marginTop: 15,
    },
    buttonStyle: {
        justifyContent: 'center',
        flexDirection: 'row',
        marginTop: 30,
        padding: 15,
        backgroundColor: '#8ad24e',
    },
    buttonTextStyle: {
        color: '#fff',
        textAlign: 'center',
    },
    customRatingBarStyle: {
        justifyContent: 'center',
        flexDirection: 'row',
        marginTop: 30,
    },
    starImageStyle: {
        width: 40,
        height: 40,
        resizeMode: 'cover',
    },
});

export default TaskDetail;