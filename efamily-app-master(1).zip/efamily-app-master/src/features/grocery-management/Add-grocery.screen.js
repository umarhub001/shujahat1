import React, { useContext, useState } from 'react';
import { Box, Stack, Heading, Icon, Text, HStack, Avatar, View, ScrollView, Center, VStack, FormControl, Input, Select, CheckIcon, Button, Spinner, Progress, Image } from 'native-base';
import {
    MaterialCommunityIcons,
    SimpleLineIcons,
    MaterialIcons,
    Feather
} from '@expo/vector-icons';


import { AppThemeProvider } from '../../components/ThemeProvider';
import { TouchableOpacity } from 'react-native';
import { AccountContext } from '../../services/account/account.context';
import { UploadImageContext } from '../../services/firebase-storage/imageUpload.context';
import { GroceryContext } from '../../services/grocery/grocery.context';
const MemberDetail = () => {

    const [name, setName] = useState('');
    const [quantity, setQuantity] = useState(1);
    const [details, setDetails] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState(null);

    // services apis
    const { addGroceryItem } = useContext(GroceryContext);

    ///Firestorage image service
    const {
        uploading,
        progress,
        setProgress,
        selectImage, setUploading,
        uploadInFirebaseStorage
    } = useContext(UploadImageContext);
    const [image, setImage] = useState(null);
    const [imageUri, setImageUri] = useState(null);

    const handleSelectImage = async () => {
        if (image) {
            setImage(null);
            setImageUri(null);
        } else {
            const uri = await selectImage()
            setImage(uri);
        }
    }

    const handleUpload = async (image) => {
        const uri = await uploadInFirebaseStorage(image);
        if (uri) {
            setImageUri(uri);

        }
    }



    const handleAddGrocery = () => {
        if (!quantity || !name || !details) {
            setError("All fields are required");
            return
        }
        setIsLoading(true);
        addGroceryItem(name, quantity, details, imageUri).then((success) => {
            alert(success);
        }).catch((error) => {
            alert(error);
        }).finally(() => {
            setError(null);
            setImage(null);
            setImageUri(null);
            setName('');
            setDetails('');
            setQuantity(1);
            setIsLoading(false);
        })
    }

    return (
        <AppThemeProvider>
            <ScrollView>
                <View flex={1} padding={2} mt={5}>
                    <HStack bg={"amber.300"} mt={1} borderRadius={15} h={20}
                        bottom={4} w="100%" px={4} alignItems="center" justifyContent="space-between">
                        <Stack>
                            <Center>
                                <Heading color={"white"} fontWeight={"bold"} fontFamily={"mono"} size="sm" >
                                    Add Grocer Item
                                </Heading>

                            </Center>
                        </Stack>

                        <TouchableOpacity >
                            <Icon as={<Feather name="plus" />} color="white" size={25} />
                        </TouchableOpacity>
                    </HStack>
                    <View >

                        {image ? (
                            <Center> <Image alt={"grocery image"} size={240} source={{ uri: image }} /></Center>
                        ) : (
                            <Center>  <Image size={240} rounded={5} alt={"grocery"} source={require("../../../assets/images/grocery.jpg")} /></Center>
                        )}


                        <Box mt={1}>
                            <HStack justifyContent="space-around">


                                <HStack space={3}>
                                    {!imageUri && (
                                        <>
                                            {image && (<TouchableOpacity onPress={() => { handleUpload(image) }}>
                                                <Icon as={<Feather name="upload" />} color="success.400" size={10} />
                                            </TouchableOpacity>
                                            )}

                                        </>

                                    )}
                                    <TouchableOpacity onPress={() => handleSelectImage()}>
                                        {image ? (
                                            <Icon as={<Feather name="x" />} color="error.500" size={10} />
                                        ) : (
                                            <Icon as={<Feather name="camera" />} color="muted.900" size={10} />
                                        )}
                                    </TouchableOpacity>

                                </HStack>
                            </HStack>
                            {progress && (<Stack padding={2}>

                                <Progress colorScheme={"success"} size="xl" mb="4" value={progress}>
                                    <Text color="white" bold>
                                        {progress}%
                                    </Text>
                                </Progress>
                            </Stack>)}

                        </Box>

                    </View>

                    <VStack padding={2}>
                        <FormControl mb="5">
                            <FormControl.Label>Grocery  Name</FormControl.Label>
                            <Input value={name} placeholder='Name' onChangeText={(value) => {
                                setName(value)
                            }} />

                            <FormControl.Label>Grocery Details</FormControl.Label>
                            <Input value={details} placeholder='Details' onChangeText={(value) => {
                                setDetails(value)
                            }} />

                            <FormControl.Label>Quantity</FormControl.Label>
                            <HStack justifyContent={"space-around"} padding={5}>
                                <MaterialCommunityIcons size={30} name='minus' onPress={() => {
                                    if (quantity > 1) {
                                        setQuantity(quantity - 1)
                                    } {

                                    }
                                }} />
                                <Text>{quantity}</Text>
                                <MaterialCommunityIcons size={30} name='plus' onPress={() => { setQuantity(quantity + 1) }} />
                            </HStack>


                            {error && (<Text color={"error.500"}>{error}</Text>)}
                            {isLoading ? (
                                <Button mt="2" colorScheme="indigo" disabled>
                                    <Spinner color="white" size="sm" />
                                </Button>
                            ) : (
                                <Button mt="2" colorScheme="indigo" onPress={() => handleAddGrocery()}>
                                    Add Grocery Item
                                </Button>
                            )}

                        </FormControl>
                    </VStack>


                </View>
            </ScrollView>
        </AppThemeProvider >
    );
};



export default MemberDetail;