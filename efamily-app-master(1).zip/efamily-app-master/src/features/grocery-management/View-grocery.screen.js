import React from 'react';
import { Box, Stack, Heading, Icon, Text, HStack, Avatar, View, ScrollView, Center, VStack, FormControl, Input, Select, CheckIcon, Button, Spinner, Progress, Image, TextArea, Divider, Accordion } from 'native-base';
import { Feather } from '@expo/vector-icons';
import { AppThemeProvider } from '../../components/ThemeProvider';
import { TouchableOpacity } from 'react-native';

const ViewGrocery = ({ route }) => {
    const { id, name, details, quantity, image, status, addedBy, createdAt, completedBy } = route.params;
    return (
        <AppThemeProvider>
            <ScrollView>
                <View flex={1} padding={2} mt={5}>
                    <HStack bg={"amber.300"} mt={1} borderRadius={15} h={20}
                        bottom={4} w="100%" px={4} alignItems="center" justifyContent="space-between">
                        <Stack>
                            <Center>
                                <Heading color={"white"} fontWeight={"bold"} fontFamily={"mono"} size="sm" >
                                    Grocery Item
                                </Heading>

                            </Center>
                        </Stack>

                        <TouchableOpacity >
                            <Icon as={<Feather name="plus" />} color="white" size={25} />
                        </TouchableOpacity>
                    </HStack>
                    <View >

                        {image ? (
                            <Center> <Image alt={"grocery image"} size={240} source={{ uri: image }} /></Center>
                        ) : (
                            <Center> <Image alt={"grocery image"} size={280} rounded={8} source={require("../../../assets/images/grocery.jpg")} /></Center>
                        )}

                    </View>

                    <View margin={5} w={"90%"}>
                        <Accordion >
                            <Accordion.Item>
                                <Accordion.Summary>
                                    {name}
                                    <Accordion.Icon />
                                </Accordion.Summary>
                                <Accordion.Details>
                                    <Stack>
                                        <VStack padding={5} bgColor={"muted.50"} shadow={3} >
                                            <Text bold fontSize="sm" >Name </Text>
                                            <Text fontFamily={"mono"} fontSize={12} color={"gray.600"}>{name}</Text>
                                            <Divider />
                                            <Text bold fontSize="sm" >Details </Text>
                                            <Text fontFamily={"mono"} fontSize={12} color={"gray.600"}>{details}</Text>
                                            <Divider />
                                            <Text bold fontSize="sm" >Quantity</Text>
                                            <Text fontFamily={"mono"} fontSize={12} color={"gray.600"}>{quantity}</Text>
                                            <Divider />
                                            <Text bold fontSize="sm" >Added By</Text>
                                            {addedBy ? (
                                                <Text fontFamily={"mono"} fontSize={12} color={"gray.600"}>{addedBy}</Text>
                                            ) : (
                                                <Text></Text>
                                            )}
                                            <Divider />
                                            <Text bold fontSize="sm" >Status </Text>
                                            {status ? (
                                                <Text fontFamily={"mono"} fontSize={12} color={"gray.600"}>Approved</Text>
                                            ) : (
                                                <Text fontFamily={"mono"} fontSize={12} color={"gray.600"}>Not Approved</Text>
                                            )}
                                            <Divider />
                                            <Text bold fontSize="sm" >Completed By</Text>
                                            {completedBy ? (
                                                <Text fontFamily={"mono"} fontSize={12} color={"gray.600"}>{completedBy}</Text>
                                            ) : (
                                                <Text fontFamily={"mono"} fontSize={12} color={"gray.600"}>Nobody</Text>
                                            )}
                                            <Divider />
                                            <Text bold fontSize="sm" >Created At</Text>
                                            {createdAt ? (
                                                <Text fontFamily={"mono"} fontSize={12} color={"gray.600"}>{createdAt}</Text>
                                            ) : (
                                                <Text> </Text>
                                            )}
                                            <Divider />
                                        </VStack>
                                    </Stack>
                                </Accordion.Details>
                            </Accordion.Item>
                        </Accordion>
                    </View>



                </View>
            </ScrollView>
        </AppThemeProvider >
    );
};

export default ViewGrocery;