
import React, { useContext, useEffect, useState } from 'react';
import {
    Center, Stack, HStack, Heading, Icon, View, Spacer, VStack,
    Text,
    Box,

    Pressable, Avatar, Select, CheckIcon, Image,
} from 'native-base'
import { SwipeListView } from 'react-native-swipe-list-view';
import { FAB } from 'react-native-paper';

import { Path } from 'react-native-svg';
import { AntDesign, Ionicons, MaterialIcons, Entypo } from '@expo/vector-icons'
import { StyleSheet, TouchableOpacity } from 'react-native'
import { AppThemeProvider } from '../../components/ThemeProvider';
import { GroceryContext } from '../../services/grocery/grocery.context';
import AuthContext from '../../services/account/auth.context';

const Grocery = ({ navigation }) => {
    const [filter, setFilter] = useState("unCompleted")
    const { groceries, deleteGroceryItem, approveGroceryItem, completeGroceryItem, } = useContext(GroceryContext);
    const { isAdmin } = useContext(AuthContext);
    const [groceriesItems, setGroceriesItems] = useState([]);
    useEffect(() => {
        if (filter === "all") {
            setGroceriesItems(groceries);
        } else if (filter === "completed") {
            const completeGroceries = groceries.filter(grocery => grocery.completed === true);
            console.log("am in completed");
            setGroceriesItems(completeGroceries);
            console.log(completeGroceries);
        } else if (filter === "unCompleted") {
            const approvedGroceries = groceries.filter(grocery => grocery.status === true);
            const uncompleteGroceries = approvedGroceries.filter(grocery => grocery.completed === false);
            setGroceriesItems(uncompleteGroceries);
        } else if (filter === "approvedPending") {
            const approvedPendingGroceries = groceries.filter(grocery => grocery.status === false);
            setGroceriesItems(approvedPendingGroceries);
        }
    }, [groceries, filter])

    const deleteAction = (id) => {
        deleteGroceryItem(id).then((success) => {
            alert(success)
        });
    };
    const completeAction = (id) => {
        completeGroceryItem(id).then((success) => {
            alert(success);
        })
    }
    const approvedAction = (id) => {
        approveGroceryItem(id).then((success) => {
            alert(success)
        });
    }

    const CurrentFilters = () => {
        if (filter === "approvedPending") {
            return <Text color={"gray.600"} fontSize={11}> Not approved</Text>
        } else if (filter === "unCompleted") {
            return <Text color={"gray.600"} fontSize={11}> Not Completed</Text>
        } else if (filter === "completed") {
            return <Text color={"gray.600"} fontSize={11}> Completed</Text>
        } else if (filter === "all") {
            return <Text color={"gray.600"} fontSize={11}> All Items</Text>
        }
    }

    const renderItem = ({ item }) => {

        return (
            <Box>
                <Pressable onPress={() => navigation.navigate("viewGrocery", {
                    id: item.id,
                    name: item.name,
                    quantity: item.quantity,
                    addedBy: item.addedBy,
                    createdAt: item.createdAt,
                    completedBy: item.completedBy,
                    image: item.image,
                    completed: item.completed,
                    status: item.status,
                    details: item.details,
                })}
                    _light={{ bg: 'white' }}>
                    <Box pl="4" pr="5" py="2"   >
                        <HStack alignItems="center" space={5} padding={3} bgColor={"#F6F6F7"} borderRadius={8}>
                            {item.image ? (
                                <Image alt="grocery" rounded={5} size="68px" source={{ uri: item.image }} />
                            ) : (
                                <Image size="68px" rounded={5} alt={"grocery"} source={require("../../../assets/images/grocery.jpg")} />
                            )}
                            <VStack>
                                <Text color="coolGray.600" fontWeight={"bold"}>{item.name} </Text>
                                <Text fontSize={11} color="coolGray.600">quantity: {item.quantity}</Text>
                            </VStack>
                            <Spacer />
                            <Text fontSize={7} color="coolGray.800" alignSelf="flex-start">{item.createdAt}</Text>
                        </HStack>
                    </Box>
                </Pressable>
            </Box>
        );
    };

    const renderHiddenItem = (data) => {
        const item = data.item;

        const Action = () => {
            if (filter === "unCompleted") {
                return (
                    <Pressable w="50" cursor="pointer" bg="#FFD54F" justifyContent="center"
                        onPress={() => { completeAction(item.id) }} _pressed={{ opacity: 0.5 }}>
                        <VStack alignItems="center" space={2}>
                            <Icon as={<AntDesign name="checkcircle" />} color="white" size="xs" />
                            <Text color="white" fontSize="xs" fontWeight="medium">Complete</Text>
                        </VStack>
                    </Pressable>
                )
            } else if (filter === "approvedPending") {
                return (
                    <Pressable w="50" cursor="pointer" bg="success.400" justifyContent="center"
                        onPress={() => { approvedAction(item.id) }} _pressed={{ opacity: 0.5 }}>
                        <VStack alignItems="center" space={2}>
                            <Icon as={<MaterialIcons name="add-task" />} color="white" size="xs" />
                            <Text color="white" fontSize="xs" fontWeight="medium">Add</Text>
                        </VStack>
                    </Pressable>
                )
            } else if (filter === "all") {
                return (
                    <Pressable w="50" cursor="pointer" bg="red.500" justifyContent="center"
                        onPress={() => { deleteAction(item.id) }} _pressed={{ opacity: 0.5 }}>
                        <VStack alignItems="center" space={2}>
                            <Icon as={<MaterialIcons name="delete" />} color="white" size="xs" />
                            <Text color="white" fontSize="xs" fontWeight="medium">Delete</Text>
                        </VStack>
                    </Pressable>
                )
            } else if (filter === "completed") {
                if (isAdmin) {
                    return (
                        <Pressable w="50" cursor="pointer" bg="red.500" justifyContent="center"
                            onPress={() => {
                                deleteAction(item.id)
                            }} _pressed={{ opacity: 0.5 }}>
                            <VStack alignItems="center" space={2}>

                                <Icon as={<MaterialIcons name="delete" />} color="white" size="xs" />
                                <Text color="white" fontSize="xs" fontWeight="medium">Delete</Text>


                            </VStack>
                        </Pressable>
                    )
                } else {
                    return (
                        <Pressable w="50" cursor="pointer" bg="success.400" justifyContent="center"
                            onPress={() => {

                            }} _pressed={{ opacity: 0.5 }}>
                            <VStack alignItems="center" space={2}>

                                <Icon as={<AntDesign name="check" />} color="white" size="xs" />
                                <Text color="white" fontSize="xs" fontWeight="medium">Done</Text>


                            </VStack>
                        </Pressable>
                    )
                }
            }
        }

        return (
            <HStack flex="1" pl="2" marginTop={5} marginRight={5}>
                <Pressable w="50" ml="auto" cursor="pointer" bg="coolGray.200" justifyContent="center"
                    onPress={() => navigation.navigate("viewGrocery", {
                        id: item.id,
                        name: item.name,
                        quantity: item.quantity,
                        addedBy: item.addedBy,
                        createdAt: item.createdAt,
                        completedBy: item.completedBy,
                        imgae: item.image,
                        completed: item.completed,
                        status: item.status,
                    })} _pressed={{ opacity: 0.5 }}>
                    <VStack alignItems="center" space={2}>
                        <Icon as={<Entypo name="eye" />} size="xs" color="coolGray.800" />
                        <Text fontSize="xs" fontWeight="medium" color="coolGray.800">View</Text>
                    </VStack>
                </Pressable>
                <Action />
            </HStack>
        );
    };

    return (
        <AppThemeProvider>

            <View flex={1} padding={1}>
                <HStack bg={"amber.300"} mt={1} borderRadius={15} h={20}
                    bottom={1} w="100%" px={4} alignItems="center" justifyContent="space-between">
                    <Stack>
                        <Center>
                            <Heading color={"white"} fontWeight={"bold"} fontFamily={"mono"} size="sm" >
                                Grocery Items
                            </Heading>
                        </Center>
                        {/* <Text color={"gray.400"}>{filter}</Text> */}
                        <CurrentFilters />
                    </Stack>
                    <Stack>
                        <HStack space={3}>
                            {isAdmin ? (
                                <Select
                                    selectedValue={filter}
                                    mx={{ base: 0, md: 'auto' }}
                                    onValueChange={(value) => setFilter(value)}
                                    _selectedItem={{ bg: 'coolGray.100', endIcon: <CheckIcon color="black" size={4} />, }}
                                    accessibilityLabel="Groceries" >
                                    <Select.Item label="All" value="all" onPress={() => { setFilter("all") }} />
                                    <Select.Item label="Not Approved" value="approvedPending" onPress={() => { setFilter("approvedPending") }} />
                                    <Select.Item label="Completed" value="completed" onPress={() => { setFilter("completed") }} />
                                    <Select.Item label="Not Completed" value="unCompleted" onPress={() => { setFilter("unCompleted") }} />
                                </Select>
                            ) : (
                                <Select
                                    selectedValue={filter}
                                    mx={{ base: 0, md: 'auto' }}
                                    onValueChange={(value) => setFilter(value)}
                                    _selectedItem={{ bg: 'coolGray.100', endIcon: <CheckIcon color="black" size={4} />, }}
                                    accessibilityLabel="Groceries">
                                    <Select.Item label="Completed" value="completed" onPress={() => { setFilter("completed") }} />
                                    <Select.Item label="Not Completed" value="unCompleted" onPress={() => { setFilter("unCompleted") }} />
                                </Select>
                            )}
                        </HStack>
                    </Stack>
                </HStack>
                <View flex={1}>
                    <SwipeListView data={groceriesItems}
                        renderItem={renderItem}
                        renderHiddenItem={
                            (data) => renderHiddenItem(data)
                        }
                        rightOpenValue={-130}
                        previewRowKey={'0'}
                        previewOpenValue={-40}
                        previewOpenDelay={3000} />
                </View>
                <FAB
                    style={styles.fab}
                    small
                    icon="plus"
                    onPress={() => navigation.navigate("addGrocery")}
                />


            </View>

        </AppThemeProvider>
    )
}
// padding={1} bgColor={"#F6F6F7"}



const styles = StyleSheet.create({
    fab: {
        position: 'absolute',
        margin: 16,
        right: 0,
        bottom: 0,
        borderRadius: 35,
        backgroundColor: "#FFD54F"
    },
})

export default Grocery
