import React, { useContext, useEffect, useState } from 'react'
import { Box, Heading, View, Image, Text, HStack, Stack, Button, ScrollView, Center, Menu, } from 'native-base';
import { AppThemeProvider } from '../../components/ThemeProvider'
import { Icon, IconButton, Stagger, useDisclose } from "native-base";
import { MaterialCommunityIcons, MaterialIcons } from "@expo/vector-icons";
import { StyleSheet, TouchableOpacity } from 'react-native';
import { FAB } from 'react-native-paper';
import { WeeklyMenuContext } from '../../services/weekly-menu/weekly.menu.context';
import AuthContext from '../../services/account/auth.context';


const ViewMenu = ({ navigation }) => {
    const { isOpen, onToggle } = useDisclose();
    const daysOfWeek = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
    const today = new Date();
    const dayOfWeek = daysOfWeek[today.getDay()];
    const [selectedDay, setSelectedDay] = useState(dayOfWeek);
    const { weeklyMenu } = useContext(WeeklyMenuContext);
    const [breakfastData, setBreakfastData] = useState({});
    const [lunchData, setLunchData] = useState({});
    const [dinnerData, setDinnerData] = useState({});
    const { isAdmin } = useContext(AuthContext);


    useEffect(() => {

        setBreakfastData(weeklyMenu[selectedDay]?.breakfast);
        setLunchData(weeklyMenu[selectedDay]?.lunch);
        setDinnerData(weeklyMenu[selectedDay]?.dinner);

    }, [selectedDay, weeklyMenu])


    const dayColors = {
        Mon: selectedDay === 'Monday' ? 'white' : 'gray.400',
        Tue: selectedDay === 'Tuesday' ? 'white' : 'gray.400',
        Wed: selectedDay === 'Wednesday' ? 'white' : 'gray.400',
        Thu: selectedDay === 'Thursday' ? 'white' : 'gray.400',
        Fri: selectedDay === 'Friday' ? 'white' : 'gray.400',
        Sat: selectedDay === 'Saturday' ? 'white' : 'gray.400',
        Sun: selectedDay === 'Sunday' ? 'white' : 'gray.400',
    };
    return (
        <AppThemeProvider>
            <View margin={1} >
                <HStack bg={"amber.300"} borderRadius={15} h={20} mt={1}
                    bottom={1} w="100%" px={4} alignItems="center" justifyContent="center">
                    <Stack >
                        <Center>
                            <Heading color={"white"} fontWeight={"bold"} fontFamily={"mono"} size="sm" >
                                Weekly Menu
                            </Heading>
                        </Center>
                        <HStack space={5} mt={4}>
                            <TouchableOpacity onPress={() => setSelectedDay('Monday')}>
                                <Text bold color={dayColors['Mon']}>{'Mon'}</Text>
                            </TouchableOpacity>
                            <TouchableOpacity onPress={() => setSelectedDay('Tuesday')}>
                                <Text bold color={dayColors['Tue']}>{'Tue'}</Text>
                            </TouchableOpacity>
                            <TouchableOpacity onPress={() => setSelectedDay('Wednesday')}>
                                <Text bold color={dayColors['Wed']}>{'Wed'}</Text>
                            </TouchableOpacity>
                            <TouchableOpacity onPress={() => setSelectedDay('Thursday')}>
                                <Text bold color={dayColors['Thu']}>{'Thu'}</Text>
                            </TouchableOpacity>
                            <TouchableOpacity onPress={() => setSelectedDay('Friday')}>
                                <Text bold color={dayColors['Fri']}>{'Fri'}</Text>
                            </TouchableOpacity>
                            <TouchableOpacity onPress={() => setSelectedDay('Saturday')}>
                                <Text bold color={dayColors['Sat']}>{'Sat'}</Text>
                            </TouchableOpacity>
                            <TouchableOpacity onPress={() => setSelectedDay('Sunday')}>
                                <Text bold color={dayColors['Sun']}>{'Sun'}</Text>
                            </TouchableOpacity>
                        </HStack>
                    </Stack>
                </HStack>
            </View>

            <ScrollView>
                <View flex={1} padding={5}>
                    {breakfastData && (
                        <Box mt={5} rounded="25"
                            w="100%"
                            _ios={{ shadow: 4 }} _android={{ borderWidth: 1 }} _light={{ borderColor: 'gray.300' }} _dark={{ borderColor: 'gray.400' }} mx={{ base: 'auto', md: 0 }}>
                            {breakfastData.image ? (
                                <Image
                                    roundedTop="25"
                                    h={56}
                                    source={{
                                        uri: breakfastData.image,
                                    }}
                                    alt="Meal Image"
                                />
                            ) : (
                                <Image
                                    roundedTop="25"
                                    h={56}
                                    source={require("../../../assets/images/breakfast.jpg")}
                                    alt="Meal Image"
                                />

                            )}
                            <Stack p={4} space={3}>
                                <Heading _dark={{ color: 'blueGray.100' }} _light={{ color: 'blueGray.700' }}>
                                    Breakfast
                                </Heading>

                                <Text bold fontSize={15} color={"gray.500"}>{breakfastData.name}</Text>
                                {breakfastData.extra && (
                                    <Text fontSize={11} _light={{ color: 'blueGray.600' }}>
                                        {breakfastData.extra}
                                    </Text>
                                )}
                                <Text _light={{ color: 'blueGray.500' }}>
                                    {breakfastData.description}
                                </Text>
                            </Stack>
                        </Box>
                    )}

                    {lunchData && (
                        <Box mt={5} rounded="25"
                            w="100%"
                            _ios={{ shadow: 4 }} _android={{ borderWidth: 1 }} _light={{ borderColor: 'gray.300' }} _dark={{ borderColor: 'gray.400' }} mx={{ base: 'auto', md: 0 }}>

                            {lunchData.image ? (
                                <Image
                                    roundedTop="25"
                                    h={56}
                                    source={{
                                        uri: lunchData.image
                                    }}
                                    alt="Meal Image"
                                />
                            ) : (
                                <Image
                                    roundedTop="25"
                                    h={56}
                                    source={require("../../../assets/images/lunch.jpg")}
                                    alt="Meal Image"
                                />
                            )}

                            <Stack p={4} space={3}>
                                <Heading _dark={{ color: 'blueGray.100' }} _light={{ color: 'blueGray.700' }}>
                                    Lunch
                                </Heading>
                                <Text bold fontSize={15} color={"gray.500"}>{lunchData.name}</Text>
                                {lunchData.extra && (
                                    <Text fontSize={11} _light={{ color: 'blueGray.600' }}>
                                        {lunchData.extra}
                                    </Text>
                                )}
                                <Text _light={{ color: 'blueGray.500' }}>
                                    {lunchData.description}
                                </Text>

                            </Stack>
                        </Box>
                    )}

                    {dinnerData && (
                        <Box mt={5} rounded="25"
                            w="100%"
                            _ios={{ shadow: 4 }} _android={{ borderWidth: 1 }} _light={{ borderColor: 'gray.300' }} _dark={{ borderColor: 'gray.400' }} mx={{ base: 'auto', md: 0 }}>
                            {dinnerData.image ? (
                                <Image
                                    roundedTop="25"
                                    h={56}
                                    source={{
                                        uri: dinnerData.image
                                    }}
                                    alt="Meal Image"
                                />
                            ) : (
                                <Image
                                    roundedTop="25"
                                    h={56}
                                    source={require("../../../assets/images/dinner.jpg")}
                                    alt="Meal Image"
                                />
                            )}
                            <Stack p={4} space={3}>
                                <Heading _dark={{ color: 'blueGray.100' }} _light={{ color: 'blueGray.700' }}>
                                    Dinner
                                </Heading>
                                <Text bold fontSize={15} color={"gray.500"}>{dinnerData.name}</Text>

                                {dinnerData.extra && (
                                    <Text fontSize={11} _light={{ color: 'blueGray.600' }}>
                                        {dinnerData.extra}
                                    </Text>
                                )}
                                <Text _light={{ color: 'blueGray.500' }}>
                                    {dinnerData.description}
                                </Text>


                            </Stack>
                        </Box>
                    )}
                </View>

            </ScrollView>

            <Box position={"absolute"} style={styles.fab}>
                <Stagger visible={isOpen} initial={{ opacity: 0, scale: 0, translateY: 34 }} animate={{
                    translateY: 0, scale: 1, opacity: 1, transition: { type: 'spring', mass: 0.8, stagger: { offset: 30, reverse: true } }
                }} exit={{
                    translateY: 34, scale: 0.5, opacity: 0,
                    transition: { duration: 100, stagger: { offset: 30, reverse: true } }
                }}>
                    {isAdmin ? (
                        <>
                            <Box>
                                <IconButton onPress={() => {
                                    navigation.navigate("addMenu")
                                }}
                                    mb="4" variant="solid" bg="red.500" colorScheme="teal" borderRadius="full" icon={<Icon as={MaterialCommunityIcons} _dark={{
                                        color: 'warmGray.50'
                                    }} size="6" name="plus" color="warmGray.50" />} />

                            </Box>
                            <Box>
                                <IconButton
                                    onPress={() => {
                                        navigation.navigate("addMenu", {
                                            selectedDay,
                                            breakfastData,
                                            lunchData,
                                            dinnerData,
                                        })
                                    }}
                                    mb="4" variant="solid" bg="green.500" colorScheme="red" borderRadius="full" icon={<Icon as={MaterialIcons} size="6" name="edit" _dark={{
                                        color: 'warmGray.50'
                                    }} color="warmGray.50" />} />
                            </Box>
                            <Box>
                                <IconButton
                                    onPress={() => {
                                        navigation.navigate("addPreference");
                                    }}
                                    mb="4" variant="solid" bg="warning.400" borderRadius="full" icon={<Icon as={MaterialIcons} size="6" name="book" _dark={{
                                        color: 'warmGray.50'
                                    }} color="warmGray.50" />} />
                            </Box>

                        </>
                    ) : (
                        <>
                            <Box>
                                <IconButton
                                    onPress={() => {
                                        navigation.navigate("addPreference");
                                    }}
                                    mb="4" variant="solid" bg="warning.400" borderRadius="full" icon={<Icon as={MaterialIcons} size="6" name="book" _dark={{
                                        color: 'warmGray.50'
                                    }} color="warmGray.50" />} />
                            </Box>
                        </>
                    )}


                </Stagger>
                <HStack justifyContent="center">
                    <IconButton variant="solid" borderRadius="full" size="lg" onPress={onToggle} bg="amber.300" icon={<Icon as={MaterialCommunityIcons} size="6" name="dots-horizontal" _dark={{
                        color: 'amber.300'
                    }} />} />
                </HStack>
            </Box>




        </AppThemeProvider >
    )
}


const styles = StyleSheet.create({
    fab: {
        position: 'absolute',
        margin: 16,
        right: 0,
        bottom: 0,
        borderRadius: 35,
    },
})
export default ViewMenu