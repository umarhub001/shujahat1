
import {
    Skeleton, VStack, Box, View, Heading, Image, Text, Icon, HStack, Stack, Center, FormControl, Input, Spinner, Button, Accordion, ScrollView, Progress, Select, CheckIcon
} from 'native-base'
// import { Skeleton, VStack, } from 'native-base';
import React, { useState, useContext, useEffect } from 'react'
import { UploadImageContext } from '../../services/firebase-storage/imageUpload.context';
import { Feather, AntDesign } from '@expo/vector-icons';
import { AppThemeProvider } from '../../components/ThemeProvider'
import { TouchableOpacity } from 'react-native';
import { WeeklyMenuContext } from '../../services/weekly-menu/weekly.menu.context';

const AddMenu = ({ route }) => {
    const [day, setDay] = useState();
    const [breakFastImage, setBreakFastImage] = useState(null);
    const [lunchImage, setLunchImage] = useState(null);
    const [dinnerImage, setDinnerImage] = useState(null);
    const [BreakFastMealPref, setBreakFastMealPref] = useState([]);
    const [LunchMealPref, setLunchMealPref] = useState([]);
    const [DinnerMealPref, setDinnerMealPref] = useState([]);
    const [isLoading, setIsLoading] = useState(false);
    const [isSplash, setIsSplash] = useState(true);
    const { addDailyMenuData, preferences } = useContext(WeeklyMenuContext);


    const [breakfastData, setBreakfastData] = useState({ name: '', description: '', image: '', extra: '' });
    const [lunchData, setLunchData] = useState({ name: '', description: '', image: '', extra: '' });
    const [dinnerData, setDinnerData] = useState({ name: '', description: '', image: '', extra: '' });
    ///Firestorage image service
    const { uploading, progress, setProgress, selectImage, setUploading, uploadInFirebaseStorage } = useContext(UploadImageContext);

    useEffect(() => {
        setTimeout(() => {
            setIsSplash(false)
        }, 2500);
    }, [])




    useEffect(() => {
        if (route.params) {
            const { selectedDay, breakfastData, lunchData, dinnerData } = route.params;
            setDay(selectedDay);
            if (breakfastData || lunchData || dinnerData) {
                setBreakFastImage(breakfastData.image)
                setLunchImage(lunchData.image);
                setDinnerImage(dinnerData.image);
                setBreakfastData({ name: breakfastData.name, description: breakfastData.description, extra: breakfastData.extra });
                setLunchData({ name: lunchData.name, description: lunchData.description, extra: lunchData.extra });
                setDinnerData({ name: dinnerData.name, description: dinnerData.description, extra: dinnerData.extra });

                if (breakfastData.image) {
                    setDinnerData((prevData) => ({ ...prevData, image: breakfastData.image }))
                }
                if (lunchData.image) {
                    setDinnerData((prevData) => ({ ...prevData, image: lunchData.image }))
                }
                if (dinnerData.image) {
                    setDinnerData((prevData) => ({ ...prevData, image: dinnerData.image }))
                }
            }
        }
    }, [])

    //preferences logic 
    useEffect(() => {


        // const BreakFastMealPref = [...new Set(preferences.filter(preference => preference.type === "Breakfast").map(preference => preference.name))];
        // const LunchMealPref = [...new Set(preferences.filter(preference => preference.type === "Lunch").map(preference => preference.name))];
        // const DinnerMealPref = [...new Set(preferences.filter(preference => preference.type === "Dinner").map(preference => preference.name))];
        const BreakFastMealPref = preferences.filter(preference => preference.type === "Breakfast");
        const LunchMealPref = preferences.filter(preference => preference.type === "Lunch");
        const DinnerMealPref = preferences.filter(preference => preference.type === "Dinner");
        setBreakFastMealPref(BreakFastMealPref);
        setLunchMealPref(LunchMealPref);
        setDinnerMealPref(DinnerMealPref)
    }, [preferences])


    //breakfast
    const handleBreakFastSelectImage = async (image) => {
        if (image) {
            setBreakFastImage(null);
            setBreakfastData((prevData) => ({ ...prevData, name: '', extra: '' }));
        } else {
            const image = await selectImage();
            const uri = await uploadInFirebaseStorage(image);
            if (uri) {
                setBreakfastData((prevData) => ({ ...prevData, image: uri }))
                setBreakFastImage(uri);
            }

        }
    }

    const handleLunchSelectImage = async (image) => {
        if (image) {
            setLunchImage(null);
            setLunchData((prevData) => ({ ...prevData, name: '', extra: '' }))
        } else {
            const image = await selectImage();
            const uri = await uploadInFirebaseStorage(image);
            if (uri) {
                setLunchData((prevData) => ({ ...prevData, image: uri }))
                setLunchImage(uri);
            }

        }
    }
    const handleDinnerSelectImage = async (image) => {
        if (image) {
            setDinnerImage(null); setDinnerData((prevData) => ({ ...prevData, name: '', extra: '' }));
        } else {
            const image = await selectImage();
            const uri = await uploadInFirebaseStorage(image);
            if (uri) {
                setDinnerData((prevData) => ({ ...prevData, image: uri }))
                setDinnerImage(uri);
            }
        }
    }

    const handleAddMenu = () => {
        if (!breakfastData.name || !breakfastData.description) {
            alert('All Breakfast fields are required');
            return;
        }

        if (!lunchData.name || !lunchData.description) {
            alert('All Lunch felds are required');
            return;
        }

        if (!dinnerData.name || !dinnerData.description) {
            alert('All Dinner fields are required');
            return;
        }

        setIsLoading(true);
        addDailyMenuData(day, breakfastData, lunchData, dinnerData)
            .then((message) => {
                alert(message);

            })
            .catch((error) => {
                alert(error)
            })
            .finally(() => {
                setIsLoading(false);
            });

    };



    if (isSplash) {
        return (
            <AppThemeProvider>
                <View w="100%" flex={1} top={15} margin={5} >
                    <HStack
                        w="90%"
                        maxW="400"
                        space={8}
                        rounded="md"
                        _dark={{ borderColor: 'coolGray.500' }}
                        _light={{ borderColor: 'coolGray.200' }}
                        p="4"
                    >

                        <VStack flex="3" space="4">

                            <Skeleton h={55} rounded={8} startColor="amber.300" />
                            <Skeleton size="9" w="100%" />
                            <Skeleton.Text />
                            <Skeleton size="9" w="100%" />
                            <Skeleton.Text />
                            <Skeleton size="9" w="100%" />
                            <Skeleton.Text />
                            <HStack space="2" alignItems="center">
                                <Skeleton h="7" flex="1" rounded="8" startColor="indigo.300" />
                            </HStack>
                        </VStack>
                    </HStack>
                </View>
            </AppThemeProvider>
        )

    }
    else {
        return (
            <AppThemeProvider>
                <View flex={1} padding={2} >
                    <HStack bg={"amber.300"} borderRadius={15} h={20}
                        bottom={1} w="100%" px={4} alignItems="center" justifyContent="space-between">
                        <Stack>
                            <Center>
                                <Heading color={"white"} fontWeight={"bold"} fontFamily={"mono"} size="sm" >
                                    Add Menu
                                </Heading>

                            </Center>
                        </Stack>

                        <TouchableOpacity >
                            <Icon as={<Feather name="plus" />} color="white" size={25} />
                        </TouchableOpacity>
                    </HStack>

                    <ScrollView>
                        <Box m={3}>
                            <Box mt={3} >
                                <FormControl>
                                    <FormControl.Label>Day</FormControl.Label>
                                    <Select
                                        selectedValue={day}
                                        mx={{ base: 0, md: 'auto' }}
                                        onValueChange={(value) => setDay(value)}
                                        _selectedItem={{
                                            bg: 'coolGray.100',
                                            endIcon: <CheckIcon size={4} />,
                                        }}
                                        accessibilityLabel="Select Day for Menu">
                                        <Select.Item label="Monday" value="Monday" />
                                        <Select.Item label="Tuesday" value="Tuesday" />
                                        <Select.Item label="Wednesday" value="Wednesday" />
                                        <Select.Item label="Thursday" value="Thursday" />
                                        <Select.Item label="Friday" value="Friday" />
                                        <Select.Item label="Saturday" value="Saturday" />
                                        <Select.Item label="Sunday" value="Sunday" />
                                    </Select>
                                </FormControl>



                                <Accordion mt={5}>
                                    <Accordion.Item>
                                        <Accordion.Summary>Breakfast<Accordion.Icon />
                                        </Accordion.Summary>
                                        <Accordion.Details>
                                            <FormControl mb="5">
                                                {breakFastImage ? (
                                                    <Center> <Image alt={"menu image"} size={240} source={{ uri: breakFastImage }} /></Center>
                                                ) : (
                                                    <Center> <Image alt={"menu image"} size={240} source={require("../../../assets/images/breakfast.jpg")} /></Center>
                                                )}


                                                {progress && (<Stack padding={2}>
                                                    <Progress colorScheme={"success"} size="xl" mb="4" value={progress}>
                                                        <Text color="white" bold>
                                                            {progress}%
                                                        </Text>
                                                    </Progress>
                                                </Stack>)}

                                                <Box mt={1}>
                                                    <HStack justifyContent="space-around">

                                                        <HStack space={3}>

                                                            <TouchableOpacity onPress={() => handleBreakFastSelectImage(breakFastImage)}>
                                                                {breakFastImage ? (
                                                                    <Icon as={<Feather name="x" />} color="error.500" size={10} />
                                                                ) : (
                                                                    <Icon as={<Feather name="camera" />} color="muted.900" size={10} />
                                                                )}
                                                            </TouchableOpacity>

                                                        </HStack>
                                                    </HStack>

                                                </Box>

                                                <FormControl.Label>Meal Name</FormControl.Label>
                                                <Input
                                                    value={breakfastData.name}
                                                    onChangeText={(value) => {
                                                        setBreakfastData((prevData) => ({ ...prevData, name: value }))

                                                    }} />

                                                <Accordion mt={5} >
                                                    <Accordion.Item>
                                                        <Accordion.Summary>Breakfast Preferences<Accordion.Icon />
                                                        </Accordion.Summary>
                                                        <Accordion.Details>
                                                            {BreakFastMealPref.map((value, index) => (
                                                                <TouchableOpacity key={index} onPress={() => {
                                                                    setBreakfastData((prevData) => ({ ...prevData, name: value.name, image: value.image }))
                                                                    setBreakFastImage(value.image)
                                                                }}>

                                                                    <HStack space={7} justifyContent={"space-around"} margin={2}>
                                                                        <Text>{value.name}</Text>
                                                                        <Image alt={"image"} size={49} source={{ uri: value.image }} />
                                                                    </HStack>

                                                                </TouchableOpacity>
                                                            ))}
                                                        </Accordion.Details>
                                                    </Accordion.Item>
                                                </Accordion>

                                                <FormControl.Label>Meal Description</FormControl.Label>
                                                <Input value={breakfastData.description} onChangeText={(value) => {
                                                    setBreakfastData((prevData) => ({ ...prevData, description: value }))
                                                }} />

                                                <FormControl.Label>Extra</FormControl.Label>
                                                <Input value={breakfastData.extra} onChangeText={(value) => {
                                                    setBreakfastData((prevData) => ({ ...prevData, extra: value }))
                                                }} />
                                            </FormControl>
                                        </Accordion.Details>
                                    </Accordion.Item>
                                </Accordion>
                            </Box>
                            <Box mt={3}>
                                <Accordion>
                                    <Accordion.Item>
                                        <Accordion.Summary>Lunch<Accordion.Icon />
                                        </Accordion.Summary>
                                        <Accordion.Details>
                                            <Stack space={2.5} alignSelf="center" px="4" safeArea mt="4" w={{ base: '100%', md: '25%' }}>
                                                <Box>
                                                    <Text>Lunch Details</Text>
                                                    <FormControl mb="5">
                                                        {lunchImage ? (
                                                            <Center> <Image alt={"menu image"} size={240} source={{ uri: lunchImage }} /></Center>
                                                        ) : (
                                                            <Center> <Image alt={"menu image"} size={240} source={require("../../../assets/images/lunch.jpg")} /></Center>
                                                        )}

                                                        {uploading && (
                                                            <>
                                                                {progress && (<Stack padding={2}>
                                                                    <Progress colorScheme={"success"} size="xl" mb="4" value={progress}>
                                                                        <Text color="white" bold>
                                                                            {progress}%
                                                                        </Text>
                                                                    </Progress>
                                                                </Stack>)}
                                                            </>
                                                        )}
                                                        <Box mt={1}>
                                                            <HStack justifyContent="space-around">

                                                                <HStack space={3}>
                                                                    <TouchableOpacity onPress={() => handleLunchSelectImage(lunchImage)}>
                                                                        {lunchImage ? (
                                                                            <Icon as={<Feather name="x" />} color="error.500" size={10} />
                                                                        ) : (
                                                                            <Icon as={<Feather name="camera" />} color="muted.900" size={10} />
                                                                        )}
                                                                    </TouchableOpacity>

                                                                </HStack>
                                                            </HStack>
                                                            {progress && (<Stack padding={2}>

                                                                <Progress colorScheme={"success"} size="xl" mb="4" value={progress}>
                                                                    <Text color="white" bold>
                                                                        {progress}%
                                                                    </Text>
                                                                </Progress>
                                                            </Stack>)}

                                                        </Box>

                                                        <FormControl.Label>Meal Name</FormControl.Label>
                                                        <Input
                                                            value={lunchData.name}
                                                            onChangeText={(value) => {
                                                                setLunchData((prevData) => ({ ...prevData, name: value }))

                                                            }} />

                                                        <Accordion mt={5} >
                                                            <Accordion.Item>
                                                                <Accordion.Summary>Lunch Preferences<Accordion.Icon />
                                                                </Accordion.Summary>
                                                                <Accordion.Details>
                                                                    {LunchMealPref.map((value, index) => (
                                                                        <TouchableOpacity key={index} onPress={() => {
                                                                            setLunchData((prevData) => ({ ...prevData, name: value.name, image: value.image }))
                                                                            setLunchImage(value.image)
                                                                        }}>

                                                                            <HStack space={7} justifyContent={"space-around"} margin={2}>
                                                                                <Text>{value.name}</Text>
                                                                                <Image alt={"image"} size={49} source={{ uri: value.image }} />
                                                                            </HStack>

                                                                        </TouchableOpacity>
                                                                    ))}


                                                                </Accordion.Details>
                                                            </Accordion.Item>
                                                        </Accordion>

                                                        <FormControl.Label>Meal Description</FormControl.Label>
                                                        <Input
                                                            value={lunchData.description}
                                                            onChangeText={(value) => {
                                                                setLunchData((prevData) => ({ ...prevData, description: value }))
                                                            }} />

                                                        <FormControl.Label>Extra</FormControl.Label>
                                                        <Input value={lunchData.extra} onChangeText={(value) => {
                                                            setLunchData((prevData) => ({ ...prevData, extra: value }))
                                                        }} />
                                                    </FormControl>
                                                </Box>
                                            </Stack>
                                        </Accordion.Details>
                                    </Accordion.Item>
                                </Accordion>
                            </Box>
                            <Box mt={3}>
                                <Accordion >
                                    <Accordion.Item>
                                        <Accordion.Summary>Dinner<Accordion.Icon />
                                        </Accordion.Summary>
                                        <Accordion.Details>
                                            <Stack space={2.5} alignSelf="center" px="4" safeArea mt="4" w={{ base: '100%', md: '25%' }}>
                                                <Box>
                                                    <Text>Dinner Details</Text>
                                                    <FormControl mb="5">
                                                        {dinnerImage ? (
                                                            <Center> <Image alt={"menu image"} size={240} source={{ uri: dinnerImage }} /></Center>
                                                        ) : (
                                                            <Center> <Image alt={"menu image"} size={240} source={require("../../../assets/images/dinner.jpg")} /></Center>
                                                        )}
                                                        {uploading && (
                                                            <>
                                                                {progress && (<Stack padding={2}>
                                                                    <Progress colorScheme={"success"} size="xl" mb="4" value={progress}>
                                                                        <Text color="white" bold>
                                                                            {progress}%
                                                                        </Text>
                                                                    </Progress>
                                                                </Stack>)}
                                                            </>
                                                        )}
                                                        <Box mt={1}>
                                                            <HStack justifyContent="space-around">
                                                                <HStack space={3}>

                                                                    <TouchableOpacity onPress={() => handleDinnerSelectImage(dinnerImage)}>
                                                                        {dinnerImage ? (
                                                                            <Icon as={<Feather name="x" />} color="error.500" size={10} />
                                                                        ) : (
                                                                            <Icon as={<Feather name="camera" />} color="muted.900" size={10} />
                                                                        )}
                                                                    </TouchableOpacity>

                                                                </HStack>
                                                            </HStack>
                                                            {progress && (<Stack padding={2}>

                                                                <Progress colorScheme={"success"} size="xl" mb="4" value={progress}>
                                                                    <Text color="white" bold>
                                                                        {progress}%
                                                                    </Text>
                                                                </Progress>
                                                            </Stack>)}

                                                        </Box>

                                                        <FormControl.Label>Meal Name</FormControl.Label>
                                                        <Input
                                                            value={dinnerData.name}
                                                            onChangeText={(value) => {
                                                                setDinnerData((prevData) => ({ ...prevData, name: value }))

                                                            }} />

                                                        <Accordion mt={5} >
                                                            <Accordion.Item>
                                                                <Accordion.Summary>Dinner Preferences<Accordion.Icon />
                                                                </Accordion.Summary>
                                                                <Accordion.Details>
                                                                    {DinnerMealPref.map((value, index) => (
                                                                        <TouchableOpacity key={index} onPress={() => {
                                                                            setDinnerData((prevData) => ({ ...prevData, name: value.name, image: value.image }))
                                                                            setDinnerImage(value.image)
                                                                        }}>

                                                                            <HStack space={7} justifyContent={"space-around"} margin={2}>
                                                                                <Text>{value.name}</Text>
                                                                                <Image alt={"image"} size={49} source={{ uri: value.image }} />
                                                                            </HStack>

                                                                        </TouchableOpacity>
                                                                    ))}


                                                                </Accordion.Details>
                                                            </Accordion.Item>
                                                        </Accordion>

                                                        <FormControl.Label>Meal Description</FormControl.Label>
                                                        <Input value={dinnerData.description} onChangeText={(value) => {
                                                            setDinnerData((prevData) => ({ ...prevData, description: value }))
                                                        }} />

                                                        <FormControl.Label>Extra</FormControl.Label>
                                                        <Input
                                                            value={dinnerData.extra}
                                                            onChangeText={(value) => {
                                                                setDinnerData((prevData) => ({ ...prevData, extra: value }))
                                                            }} />
                                                    </FormControl>
                                                </Box>
                                            </Stack>
                                        </Accordion.Details>
                                    </Accordion.Item>
                                </Accordion>
                            </Box>
                            <Stack mt={4}>

                                {isLoading ? (
                                    <Button mt="2" colorScheme="indigo" disabled>
                                        <Spinner color="white" size="sm" />
                                    </Button>
                                ) : (
                                    <Button mt="2" colorScheme="indigo" onPress={() => {
                                        handleAddMenu()
                                    }}>
                                        Save
                                    </Button>
                                )}


                            </Stack>
                        </Box>
                    </ScrollView>
                </View>

            </AppThemeProvider >
        );
    }
};

export default AddMenu;
