import React, { useContext, useEffect, useState } from 'react';
import { Box, Stack, Heading, Icon, Text, HStack, Avatar, View, ScrollView, Center, VStack, FormControl, Input, Select, CheckIcon, Button, Spinner, Progress, Image } from 'native-base';
import {

    Feather
} from '@expo/vector-icons';


import { AppThemeProvider } from '../../components/ThemeProvider';
import { TouchableOpacity } from 'react-native';
import { AccountContext } from '../../services/account/account.context';
import { UploadImageContext } from '../../services/firebase-storage/imageUpload.context';
import { WeeklyMenuContext } from '../../services/weekly-menu/weekly.menu.context';




const AddPreference = () => {

    const [name, setName] = useState('');
    const [mealType, setMealType] = useState('Breakfast');
    const [imageUri, setImageUri] = useState(null);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState(null);

    // services apis
    const { addPreference } = useContext(WeeklyMenuContext);
    ///Firestorage image service
    const {
        uploading,
        progress,
        setProgress,
        selectImage, setUploading,
        uploadInFirebaseStorage
    } = useContext(UploadImageContext);
    const [image, setImage] = useState(null);
    const [defaultImage, setDefaultImage] = useState(null);

    useEffect(() => {
        if (mealType == "Lunch") {
            setDefaultImage(require("../../../assets/images/lunch.jpg"))
        } else if (mealType == "Dinner") {
            setDefaultImage(require("../../../assets/images/dinner.jpg"))
        } else if (mealType == "Breakfast") {
            setDefaultImage(require("../../../assets/images/breakfast.jpg"))
        }
    }, [mealType])


    const DefaultImage = () => {
        return (
            <Center> <Image alt={"image"} size={240} source={defaultImage} /></Center>
        )
    }


    const handleSelectImage = async () => {
        if (image) {
            setImage(null);
            setImageUri(null);
        } else {
            const uri = await selectImage()
            setImage(uri);
        }
    }

    const handleUpload = async (image) => {
        const uri = await uploadInFirebaseStorage(image);
        if (uri) {
            setImageUri(uri);
        }
    }



    const handleAddPrefrence = () => {
        if (!mealType || !name) {
            setError("All fields are required");
            return
        }
        if (!imageUri) {
            setImageUri("dummy");
        }
        setIsLoading(true);
        addPreference(mealType, name, imageUri).then((success) => {
            alert(success);
        }).catch((error) => {
            alert(error);
        }).finally(() => {
            setImage(null);
            setImageUri(null);
            setMealType(null);
            setName(null);
            setError(null);
            setIsLoading(false);
        })
    }

    return (
        <AppThemeProvider>
            <ScrollView>
                <View flex={1} padding={2} mt={5}>
                    <HStack bg={"amber.300"} mt={1} borderRadius={15} h={20}
                        bottom={4} w="100%" px={4} alignItems="center" justifyContent="space-between">
                        <Stack>
                            <Center>
                                <Heading color={"white"} fontWeight={"bold"} fontFamily={"mono"} size="sm" >
                                    Add Meal Preferences
                                </Heading>

                            </Center>
                        </Stack>

                        <TouchableOpacity >
                            <Icon as={<Feather name="plus" />} color="white" size={25} />
                        </TouchableOpacity>
                    </HStack>
                    <View >

                        {image ? (
                            <Center> <Image alt={"image"} size={240} source={{ uri: image }} /></Center>
                        ) : (
                            <DefaultImage />
                        )}
                        <Box mt={1}>
                            <HStack justifyContent="space-around">


                                <HStack space={3}>
                                    {image && (<TouchableOpacity onPress={() => { handleUpload(image) }}>
                                        <Icon as={<Feather name="upload" />} color="success.400" size={10} />
                                    </TouchableOpacity>
                                    )}

                                    <TouchableOpacity onPress={() => handleSelectImage()}>
                                        {image ? (
                                            <Icon as={<Feather name="x" />} color="error.500" size={10} />
                                        ) : (
                                            <Icon as={<Feather name="camera" />} color="muted.900" size={10} />
                                        )}
                                    </TouchableOpacity>

                                </HStack>
                            </HStack>
                            {progress && (<Stack padding={2}>

                                <Progress colorScheme={"success"} size="xl" mb="4" value={progress}>
                                    <Text color="white" bold>
                                        {progress}%
                                    </Text>
                                </Progress>
                            </Stack>)}

                        </Box>

                    </View>

                    <VStack padding={2}>
                        <FormControl mb="5">
                            <FormControl.Label>Meal Name</FormControl.Label>
                            <Input value={name} placeholder='Name' onChangeText={(value) => {
                                setName(value)
                            }} />

                            <FormControl.Label>Meal Preference For</FormControl.Label>
                            <Select
                                selectedValue={mealType}
                                mx={{ base: 0, md: 'auto' }}
                                onValueChange={(value) => setMealType(value)}
                                _selectedItem={{
                                    bg: 'coolGray.100',
                                    endIcon: <CheckIcon size={4} />,
                                }}
                                accessibilityLabel="Select Day for Menu">
                                <Select.Item label="Breakfast" value="Breakfast" />
                                <Select.Item label="Lunch" value="Lunch" />
                                <Select.Item label="Dinner" value="Dinner" />
                            </Select>


                            {error && (<Text color={"error.500"}>{error}</Text>)}
                            {isLoading ? (
                                <Button mt="2" colorScheme="indigo" disabled>
                                    <Spinner color="white" size="sm" />
                                </Button>
                            ) : (
                                <Button mt="2" colorScheme="indigo" onPress={() => handleAddPrefrence()}>
                                    Add Meal Preference
                                </Button>
                            )}

                        </FormControl>
                    </VStack>


                </View>
            </ScrollView>
        </AppThemeProvider >
    );
};



export default AddPreference;