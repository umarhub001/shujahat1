import React, { useContext, useState, useEffect } from 'react'
import { ActivityIndicator, View, Text } from 'react-native';
import { Ionicons, MaterialIcons } from '@expo/vector-icons';

//navigations content
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { NavigationContainer } from '@react-navigation/native';

//context apis
import AuthContext from '../services/account/auth.context';
import { UploadImageContextProvider } from '../services/firebase-storage/imageUpload.context';


//admin module screens
import { AdminFamilyStack, AdminGroceryStack, AdminTaskStack, AdminWeeklyMenuStack } from './admin.navigations.js.js';

//member module screens
import { MemberFamilyStack, MemberGroceryStack, MemberTaskStack, MemberWeeklyMenuStack } from './member.navigations.js';
import { AppThemeProvider } from '../components/ThemeProvider';

const AppNavigation = () => {
    const { isAdmin, isStateLoading, } = useContext(AuthContext);
    const [isLoading, setIsLoading] = useState(true);

    const setTabOptions = (title, iconName) => ({
        title,
        tabBarIcon: ({ color, size }) => (
            <MaterialIcons name={iconName} size={size} color={color} />
        ),


    });

    useEffect(() => {
        setTimeout(() => {
            setIsLoading(false);
        }, 3000);
    }, []);

    if (isLoading) {
        return (
            <AppThemeProvider>
                <View style={{ flex: 1, justifyContent: "center", alignItems: "center" }}>
                    <ActivityIndicator size="large" color="orange" />
                </View>
            </AppThemeProvider>
        );
    }

    if (isStateLoading) {

        return (
            <AppThemeProvider>
                <View style={{ flex: 1, justifyContent: "center", alignItems: "center" }}>
                    <ActivityIndicator size="large" color="orange" />
                </View>
            </AppThemeProvider>
        );
    }

    if (isAdmin) {
        const Tab = createBottomTabNavigator();
        return (
            <UploadImageContextProvider>
                <NavigationContainer >
                    <Tab.Navigator screenOptions={{ headerShown: false, tabBarActiveTintColor: "#ffc400", tabBarShowLabel: false, tabBarInactiveTintColor: "gray", tabBarActiveBackgroundColor: "#FFFFFF", tabBarInactiveBackgroundColor: "#FFFFFF" }}>
                        <Tab.Screen name="Family" component={AdminFamilyStack}
                            options={setTabOptions('Family', 'family-restroom')} />
                        <Tab.Screen
                            name="Groceries" component={AdminGroceryStack}
                            options={setTabOptions('Groceries', 'shopping-basket')} />
                        <Tab.Screen name="Tasks" component={AdminTaskStack}
                            options={setTabOptions('Tasks', 'add-task')} />
                        <Tab.Screen name="Menu" component={AdminWeeklyMenuStack}
                            options={setTabOptions('Menu', 'restaurant-menu')} />
                    </Tab.Navigator>
                </NavigationContainer >
            </UploadImageContextProvider>
        )
    }
    else {
        const Tab = createBottomTabNavigator();
        return (
            <UploadImageContextProvider>
                <NavigationContainer >
                    <Tab.Navigator screenOptions={{ headerShown: false, tabBarActiveTintColor: "#ffc400", tabBarShowLabel: false, tabBarInactiveTintColor: "gray", tabBarActiveBackgroundColor: "#FFFFFF", tabBarInactiveBackgroundColor: "#FFFFFF", tabBarStyle: { bottom: 1, } }}>
                        <Tab.Screen name="Member Home" component={MemberFamilyStack}
                            options={setTabOptions('Family', 'family-restroom')} />
                        <Tab.Screen name="Member Grocery" component={MemberGroceryStack}
                            options={setTabOptions('Groceries', 'shopping-basket')} />
                        <Tab.Screen name="Member Task" component={MemberTaskStack}
                            options={setTabOptions('Tasks', 'add-task')} />
                        <Tab.Screen name="Menu" component={MemberWeeklyMenuStack}
                            options={setTabOptions('Menu', 'restaurant-menu')} />
                    </Tab.Navigator>
                </NavigationContainer >
            </UploadImageContextProvider>
        )
    }
}

export default AppNavigation