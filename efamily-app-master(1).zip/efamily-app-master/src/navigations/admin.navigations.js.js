import React from 'react'

import { createNativeStackNavigator } from '@react-navigation/native-stack';

//Screens for  Admin 


//Account-management module
import Family from '../features/account-management/Family.screen';
import Profile from '../features/account-management/Profile.screen';
import ManageFamily from '../features/account-management/Manage-family.screen';
import AddMember from '../features/account-management/Add-member.screen';
import MemberDetail from '../features/account-management/Member-detail.screen';
import EditMember from '../features/account-management/Edit-member.screen';

//Grocery management module 
import Grocery from '../features/grocery-management/Grocery-items.screen';
import AddGrocery from '../features/grocery-management/Add-grocery.screen';
import ViewGrocery from '../features/grocery-management/View-grocery.screen';

//Task management module
import ViewTasks from '../features/task-management/View-tasks.screen';
import AssignTask from '../features/task-management/Assign-task.screen';
import TaskDetail from '../features/task-management/Task-detail.screen';

//Weekly-menu management module
import AddMenu from '../features/weeklyMenu-management/Add-menu.screen';
import ViewMenu from '../features/weeklyMenu-management/View-menu.screen';
import AddPreference from '../features/weeklyMenu-management/Add-preference';


//Account management
export const AdminFamilyStack = () => {
    const Stack = createNativeStackNavigator();
    return (
        <Stack.Navigator screenOptions={{ headerShown: false }}>
            <Stack.Screen name="family" component={Family} />
            <Stack.Screen name="profile" component={Profile} />
            <Stack.Screen name="memberDetail" component={MemberDetail} />
            <Stack.Screen name="addMember" component={AddMember} />
            <Stack.Screen name="manageFamily" component={ManageFamily} />
            <Stack.Screen name="editMember" component={EditMember} />
        </Stack.Navigator>
    )
}


//Grocery management
export const AdminGroceryStack = () => {
    const Stack = createNativeStackNavigator();
    return (
        <Stack.Navigator screenOptions={{ headerShown: false }}>
            <Stack.Screen name="grocery" component={Grocery} />
            <Stack.Screen name="addGrocery" component={AddGrocery} />
            <Stack.Screen name="viewGrocery" component={ViewGrocery} />
        </Stack.Navigator>
    )
}


//Task management
export const AdminTaskStack = () => {
    const Stack = createNativeStackNavigator();
    return (
        <Stack.Navigator screenOptions={{ headerShown: false }}>
            <Stack.Screen name="task" component={ViewTasks} />
            <Stack.Screen name="assignTask" component={AssignTask} />
            <Stack.Screen name="taskDetail" component={TaskDetail} />
        </Stack.Navigator>
    )

}

//Weekly-menu management
export const AdminWeeklyMenuStack = () => {
    const Stack = createNativeStackNavigator();
    return (
        <Stack.Navigator screenOptions={{ headerShown: false }}>
            <Stack.Screen name='viewMenu' component={ViewMenu} />
            <Stack.Screen name='addMenu' component={AddMenu} />
            <Stack.Screen name='addPreference' component={AddPreference} />
        </Stack.Navigator>
    )
}



