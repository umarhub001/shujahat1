import React, { useContext } from 'react'
import { createNativeStackNavigator } from '@react-navigation/native-stack';


//Screens for member
//Screen Stack of Family


//Account-management module
import Family from '../features/account-management/Family.screen';
import Profile from '../features/account-management/Profile.screen';
import MemberDetail from '../features/account-management/Member-detail.screen';

//Grocery management module 
import Grocery from '../features/grocery-management/Grocery-items.screen';
import AddGrocery from '../features/grocery-management/Add-grocery.screen';
import ViewGrocery from '../features/grocery-management/View-grocery.screen';

//Task management module
import ViewTasks from '../features/task-management/View-tasks.screen';
import TaskDetail from '../features/task-management/Task-detail.screen';

//Weekly-menu management module
import ViewMenu from '../features/weeklyMenu-management/View-menu.screen';
import AddPreference from '../features/weeklyMenu-management/Add-preference';




//Screen Stacks

//Account management
export const MemberFamilyStack = () => {
    const Stack = createNativeStackNavigator();
    return (
        <Stack.Navigator screenOptions={{ headerShown: false }}>
            <Stack.Screen name="family" component={Family} />
            <Stack.Screen name="profile" component={Profile} />
            <Stack.Screen name="memberDetail" component={MemberDetail} />
        </Stack.Navigator>
    )
}


//Grocery management
export const MemberGroceryStack = () => {
    const Stack = createNativeStackNavigator();
    return (
        <Stack.Navigator screenOptions={{ headerShown: false }}>
            <Stack.Screen name="grocery" component={Grocery} />
            <Stack.Screen name="addGrocery" component={AddGrocery} />
            <Stack.Screen name="viewGrocery" component={ViewGrocery} />
        </Stack.Navigator>
    )

}


export const MemberTaskStack = () => {
    const Stack = createNativeStackNavigator();
    return (
        <Stack.Navigator screenOptions={{ headerShown: false }}>
            <Stack.Screen name="task" component={ViewTasks} />
            <Stack.Screen name="taskDetail" component={TaskDetail} />
        </Stack.Navigator>
    )

}



//Weekly-menu management
export const MemberWeeklyMenuStack = () => {
    const Stack = createNativeStackNavigator();
    return (
        <Stack.Navigator screenOptions={{ headerShown: false }}>
            <Stack.Screen name='viewMenu' component={ViewMenu} />
            <Stack.Screen name='addPreference' component={AddPreference} />
        </Stack.Navigator>
    )
}
