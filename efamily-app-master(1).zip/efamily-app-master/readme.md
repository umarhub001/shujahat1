
1- for drawer navigation issues

install
npm install --save-dev @babel/plugin-proposal-export-namespace-from
plugins: ['react-native-reanimated/plugin', "@babel/plugin-proposal-export-namespace-from"]

2- 