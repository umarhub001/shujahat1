// Import the functions you need from the SDKs you need
import { getAnalytics } from "firebase/analytics";
import { initializeApp } from 'firebase/app';
import { getFirestore } from 'firebase/firestore';
import { getAuth, } from "firebase/auth";



// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
    apiKey: "AIzaSyAHORPALayUPVEwMb7T8fy9FSCp1AUoh0s",
    authDomain: "efamily-cadd4.firebaseapp.com",
    projectId: "efamily-cadd4",
    storageBucket: "efamily-cadd4.appspot.com",
    messagingSenderId: "182130149921",
    appId: "1:182130149921:web:575afa3c3fedef39c87160",
    measurementId: "G-TXDCPKRCVR"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig, {
    persistence: 'none',
});
const db = getFirestore(app);

// Get the Auth instance for the current Firebase app
const auth = getAuth(app);
// Disable auth state persistence


export { db, auth };


